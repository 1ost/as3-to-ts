# Whole timing lexical and ancestry prerequisites

The three reported guards have two distinct causes. PropTween has no nonpublic
source members and does not need a new private/protected bridge. Its full-map
failure is an eager cross-class validation limitation. TweenLite and
SimpleTimeline are actual derived declarations whose compiler metadata and
lexical integration remain explicitly unimplemented.

## Exact reproduction

Fresh isolated compiler1ebbed38900ed88c5c0bfa4723de61f408a86b9a and
engine6aba63414d3e63db6ebe120af9c396741759e5cc were used. The original five
maintained files and complete Class/instance reflection were authenticated by
the existing verifier (receipt cb460fd363a4f277b2dc31d436c7257a43c3a0896f8bd5aac05d9fe05253e2a6).
All five exact source strings and all five metadata records remain in every
emission attempt. No method substitution, source alteration or metadata
invention was used. trace.cjs only wraps validation to record its real arguments
and rethrows errors unchanged; its declaration inventory filters parser null
placeholders only in the separate analysis AST.

The full typed-local mode reproduces these failures:

| Emitted source | Actual first failure |
| --- | --- |
| TweenPlugin | Foreign local reference identity held |
| PropTween | TweenPlugin's nonpublic member metadata validation, using PropTween's lexical plan |
| TweenLite | Object-root declaration required |
| TweenCore | Foreign local reference identity held |
| SimpleTimeline | Object-root declaration required |

NativeCallableClasses (native-callable-classes.ts:33-37) eagerly iterates the
complete source map and calls validateNativeClassMetadata for each entry.
Emitter creates only one NativeLexicalMembers instance for its current source
(emitter.ts:307-310). The validator correctly requires a lexical proof matching
both the exact source and qname before accepting nonpublic declarations
(native-class-metadata.ts:32-35). Source-map order begins with TweenPlugin;
its protected _tweens:Array declaration at source line31 cannot be proved by
PropTween's empty lexical plan. The trace records qname=TweenPlugin,
lexicalQname=PropTween and sourceEqualsLexical=false.

A diagnostic order control puts PropTween first while retaining all five source
and metadata entries. PropTween validates, then TweenPlugin fails identically.
This proves the group error is not an unimplemented PropTween member. It does
not admit the group or propose reordering as a fix. Removing the exact qname or
source condition, trusting another class's source offsets, skipping sibling
validation or dropping map entries would erase the missing authority.

The independently retained standalone generated PropTween run-guFOiw report
uses the same commits and unchanged maintained source. Its existing dedicated
leaf harness supplies PropTween alone, publishes its complete own public
metadata, and passes33 construction plus64 property observations (97), with
zero actual provider type diagnostics. This research authenticated that retained
report and its harness; it did not prune the whole-map probe to create a new
leaf success or claim another runtime replay of those97 rows.

## Derived class boundary and current providers

TweenLite and SimpleTimeline explicitly extend TweenCore. NativeLexicalMembers
rejects EXTENDS/IMPLEMENTS before building their source plans (line44). Even
without invoking that plan, the unchanged metadata validator separately rejects
source ancestry and metadata base != Object (line26), and rejects unvalidated
inherited reflected traits (line69). Their projected reflection retains actual
inherited declarations and declaredBy identities; it must not be flattened or
rewritten into an Object-root surface.

The current compiler's lexicalPublication always registers a null base scope
(native-callable-classes.ts:516). In contrast, common registerAS3LexicalMembers
requires its supplied base scope to match the sealed source declaration base
(AS3LexicalMembers.ts:71-76). Runtime protected lookup walks source scope bases,
virtual dispatch selects the entered generation and explicit super selects the
source ancestor; native prototype spelling cannot substitute for that chain.
Thus the missing compiler integration is real even though engine primitives
already exist.

Both unchanged current-engine fixtures were executed here in Node and Chromium:

| Common provider fixture | Compared original rows | Guards | Explicit held rows |
| --- | ---: | ---: | ---: |
| Native lexical fields/methods | 39 | 49 | 11 |
| Native lexical accessor protocol | 57 | 87 | 4 |

These are actual closed-source provider fixtures, not generated timing classes.
The accessor fixture additionally retains22 original getter-return-order rows
as boundary evidence with no native return admission. It supports complete
private/protected accessor pairs; it does not establish standalone getter-only
source lowering or arbitrary method signatures. The older field/method README
still lists accessor holds that the separate accessor fixture now covers; the
combined current evidence, not that older list alone, defines the available
provider slice.

Existing compiler direct-super evidence covers53 compared observations from55
retained originals, with two detached-super holds and15 rejection controls. Its
scope is exact public/protected zero-argument or Boolean-argument direct calls,
including literal Boolean defaults. The maintained TweenLite super.setEnabled
call is within that bounded direct-call prerequisite. That compiler fixture
uses its retained older engine pin and does not supply full native metadata or
prove derived lexical/metadata publication. It was inspected here, not relabeled
or rerun as current-engine/full-class admission.

Additional source requirements are visible without disabling a guard:

- SimpleTimeline has protected TweenCore references _firstChild/_lastChild,
  typed TweenCore method parameters/returns, override renderTime(Number,
  Boolean=false, Boolean=false):void, and getter-only rawTime:Number.
- TweenLite has a private static Shape reference, protected typed fields,
  typed/optional Event and Number methods, overrides, and direct super use.
- The compiler still explicitly holds overrides/custom/internal namespaces,
  accessors, typed/void ordinary method returns, typed/optional/rest ordinary
  method entry and lexical foreign-reference declarations. Public foreign
  storage publication also only binds self and Array in its current emitter.
- The engine accepts reference storage through authenticated declaration tokens;
  a type-name String is not sufficient. This connects to the separately owned
  foreign-reference research, not a new local substitute.

## Prerequisite ordering

1. Preserve the exact whole-group inventory and improve planning around per-class
   source/metadata/lexical proof ownership. A complete map needs proof for each
   qname, with exact hashes, source declaration identities and unresolved states.
   The one current-file plan cannot prove its siblings. This plumbing must keep
   unsupported sibling classes held; it does not imply all plans can already be
   built by the present single-class implementation.
2. Establish the root classes' required foreign reference bindings, ordinary
   method entry/default/return semantics and accessor source lowering. Foreign
   typed-local work is independent and remains assigned separately. Existing
   public metadata must remain complete and private traits must come from source.
3. Add authenticated derived metadata validation and compiler source-base scope
   linkage together: inherited public surfaces/declaredBy, exact source base,
   private separation, protected virtual/super lookup, override compatibility,
   reference storage, and constructor/initialization generation order. Do not
   remove Object-root restrictions before these outputs have actual authority.
4. Exercise complete generated base/derived classes against original observations,
   including early/failed construction, retry/identity, inherited field access,
   method/default/return coercion and getter control flow. Then re-run the intact
   five-class timing probe and original timing runtime suite. Other unresolved
   arithmetic, references, static cycles and module prerequisites keep their own
   status; no full timing or game readiness follows from this investigation.

Only research files and isolated test outputs were written. Main checkouts,
pins, source implementations and the current whole timing probe remain unchanged.
