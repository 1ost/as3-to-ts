# Native lexical accessor protocol

This fixture exercises common provider selection and setter conversion for
complete private/protected accessor pairs. It uses actual maintained getter and
setter bodies in handwritten native fixtures. It does not establish compiler
lowering, arbitrary source method signatures, or TweenLite module readiness.

The only production change is `AS3LexicalMembers.ts`, based on engine commit
`9fd3c0ab0480e09907da5974c484a1db3875570e`. Exact entered declaration generations,
source scope identity, and immutable captured ancestor chains remain the proof
route. Source names and native prototype mutation cannot create a capability.

The new registration member has `kind: 'accessor'`, explicit native descriptor
`key`, source `type`, and both `getter: true` and `setter: true`. Registration
captures the exact own getter and setter, validates their presence and the
supplied source type, and rejects partial pairs. Retry generations must preserve
the source schema, including both halves and type. Compatible complete protected
overrides dispatch virtually; `super` selects the exact source base; private
accessors and private static accessors retain their declaring scope. Setters
reuse `coerceAS3PropertyValue` before invoking the captured body and return the
original assignment RHS. Getter bodies return their already-lowered source
result without any additional provider return conversion.

## Original observations and boundaries

- Original lexical capture: 44 rows, 40 executed here. Seven previously held
  accessor-dependent rows now run their actual bodies. The four method signature
  rows remain held: coercion and too few/many arguments to method closures.
- Original lexical addendum: all 6 rows retained and executed.
- Fresh private accessor capture: all 11 rows executed, independently repeated.
  These cover base/child private separation, peer access, dynamic source keys,
  static private access, conversion/throw ordering, failed-write state, raw RHS,
  and outside-class sealed-property errors. Public metadata is projected from
  the two original complete XML documents; private traits come from AS3 source.
- Total native comparison: **57 original observations in each runtime**.
- Three retained original return-order captures have 22 equal behavior rows.
  These are authenticated boundary evidence only. They show why a universal
  getter wrapper that coerces after the body cannot implement source catch,
  finally, failed conversion, and return ordering. No native pass is claimed for
  those 22 rows. Their optimized/no-opt metadata member order differs; the runner
  compares the behavior rows, without asserting globally stable reflection order.

Standalone getter-only/setter-only declarations, partial accessor overrides,
source method signature lowering, source getter/method return conversion, and
whole-class admission remain unimplemented. Unsupported halves are rejected at
registration. This does not claim that those source declarations are invalid.

`guards.ts` contains synthetic protocol guards, not original observations. Its
deliberately unconverted getter result verifies that the provider does not add a
return wrapper; source compiler return correctness is a separate obligation.
The combined 87 guards cover exact descriptors, retry generation behavior,
prototype/descriptor mutation, conversion and body error identity, source type
and override conflicts, capability forgery, and atomic failed registration.
Nine comparison mutations independently detect changed ordering, RHS, dispatch,
errors, and missing observations.

## Reproduce

From the engine root, use the repository dependencies and installed Playwright:

```powershell
$env:PYTHON = '<python executable>'
$env:PLAYWRIGHT_MODULE = '<path to playwright package>'
node tests/nativeAS3LexicalAccessors/run.mjs
node tests/nativeAS3LexicalAccessors/check-types.mjs
node tests/nativeAS3LexicalAccessors/check-declarations.mjs
node tests/nativeAS3LexicalAccessors/check-baseline.mjs
node tests/nativeAS3LexicalMembers/run.mjs
node tests/nativeAS3Property/run.mjs
node tests/nativeAS3Property/run.mjs tests/nativeAS3Property/flash-evidence.json --browser '<package directory containing playwright>'
```

`run.mjs` authenticates every original capture file and derives source traits and
metadata anew before comparing Node and Chromium. Optional `--tools` on each
Python verifier also checks locally installed original tool hashes. Capture
scripts, original AS3, SWFs, commands, and receipts are retained byte-for-byte.
Browser profiles are excluded. `check-declarations.mjs` emits real provider
declarations with `stripInternal`, compiles two valid consumers and six rejected
consumers, and authenticates the complete input graph. No adapted declaration
stub is used. `check-baseline.mjs` substitutes the exact committed baseline of
the single changed production file and proves the two new fixtures fail at
registration in both runtimes. It requires that baseline Git object locally.

The untouched existing suites retain their own coverage boundaries: lexical
39 observations/49 guards and public properties 244 observations/38 guards per
runtime. They are regression evidence, not additional new accessor observations.
