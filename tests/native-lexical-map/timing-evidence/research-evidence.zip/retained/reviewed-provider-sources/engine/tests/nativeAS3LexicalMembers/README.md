# Closed-source lexical field and method provider

This is a common-engine provider fixture, not compiler emission, whole-class
admission, or a completed GreenSock module. It admits 33 of the 44 retained
original observations plus six original protected-access addendum observations.
Both captures of each source fixture agree. All original rows and complete
public reflection remain in `evidence`; no private/protected traits are invented
in reflection and no missing accessor result is substituted.

Run from the engine root:

```
python tests/nativeAS3LexicalMembers/verify-evidence.py --tools
node tests/nativeAS3LexicalMembers/check-types.mjs
node tests/nativeAS3LexicalMembers/run.mjs PATH_TO_PLAYWRIGHT_PACKAGE_PARENT
```

Omit `--tools` on machines without the recorded original Flash tools. Source,
SWF, result and command hashes are still checked. The browser runner uses its
own headless browser and unique output directory. Type checking includes the
actual common provider dependency graph, with no substitute declarations.

`metadata.json` preserves the complete original public surface and order.
`verify-evidence.py` reconstructs it from the retained Flash XML and resolves
unattributed reflected variables to their unique original public AS3 field.
`source-lexical-traits.json` separately retains the original private/protected
declarations, including the unadmitted getter/setter declarations. The fixture
binds their source methods to explicit native descriptor keys. The provider
captures those descriptors at publication and allocates distinct private Symbols
for storage and method caching. A native spelling cannot grant lexical access.

Declaration scopes are reused only for the identical authenticated source token;
native generation bindings and storage are distinct. Receivers are selected by
the frozen entered-constructor chain, including retry generations, not by the
current native prototype. Protected virtual lookup selects the most-derived
declaration, while private and `super` lookup select the declaring generation.
Common method closure authority preserves receiver and callback identity.

The original static callback identity and transfer rows include property calls,
`call`, and `apply`. The original instance cases cover private and protected
closures, virtual dispatch, explicit `super`, same-spelled public/private fields
and methods, and dynamic String versus explicit public QName access. The six-row
addendum establishes rejection of child-scope access on a base receiver and
selection of base-private versus public slots during dynamic writes.

The following eleven original rows remain individually held:

| Original row | Remaining prerequisite |
| --- | --- |
| `protected-peer-child-typed` | Its setup invokes the unadmitted protected setter. |
| `protected-accessor-override` | Protected getter/setter virtual dispatch. |
| `protected-accessor-super` | Protected getter/setter `super` dispatch. |
| `protected-accessor-coercion` | Protected setter signature coercion. |
| `protected-accessor-throw` | Protected setter signature coercion and abrupt completion. |
| `public-accessor-protected-override` | Complete typed public-accessor body/binding and source emission are outside this field/method fixture. |
| `public-accessor-assignment-rhs` | Complete public accessor body and signature admission. |
| `protected-closure-number-coercion` | Ordinary protected method parameter coercion. |
| `protected-closure-too-few` | Ordinary method argument-count enforcement. |
| `protected-closure-too-many` | Ordinary method argument-count enforcement and hook ordering. |
| `private-closure-too-many` | Ordinary private method argument-count enforcement. |

The native fixture's accessor-dependent entry points explicitly throw a test
hold error if reached. Its public reflection remains complete; these guards are
not source implementations or successful accessor observations. Public attempts
to read or write the hidden accessor name are included because ordinary sealed
visibility rejection does not execute its body.

Further boundaries: source hierarchies must be closed and fully registered,
rooted at Object. Canonical native bases, arbitrary interface implementers,
accessors, method signature conversion/arity, custom/wildcard namespaces and
dynamic private/protected lookup on unentered receivers are not admitted here.
Protected inherited static fields use the exact declaring Class receiver supplied
by source binding. No source Classes are eagerly constructed by registration.
