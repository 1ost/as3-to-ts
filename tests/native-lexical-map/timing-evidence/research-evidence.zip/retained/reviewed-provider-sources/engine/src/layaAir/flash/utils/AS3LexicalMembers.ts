import { AS3DeclarationType, getAS3DeclarationType, getAS3SourceBase,
    getAS3EnteredSourceConstructors, isCanonicalAS3DeclarationConstructor } from './AS3DeclarationType';
import { AS3PropertyType, validateAS3PropertyType, coerceAS3PropertyValue,
    as3GetProperty, as3SetProperty, as3HasProperty } from './AS3Property';
import { getBoundAS3Method, registerAS3FunctionParameterCounts } from './AS3MethodBinding';
import { as3CallValue } from './AS3Invocation';
import { as3String } from './AS3String';
import { QName } from './QName';
import { describeRegisteredFlashType } from './FlashTypeMetadata';

declare const scopeBrand: unique symbol;
declare const accessBrand: unique symbol;
/** Compiler-held lexical capability. A source name or QName cannot create one. */
export interface AS3LexicalScope { readonly [scopeBrand]: true; }
export interface AS3LexicalAccess { readonly [accessBrand]: true; }
export type AS3LexicalMember = {
    readonly name: string;
    readonly visibility: 'private' | 'protected';
    readonly static?: boolean;
} & ({readonly kind: 'variable'; readonly type: AS3PropertyType}
    | {readonly kind: 'method'; readonly key: string | symbol; readonly parameterCount: number}
    | {readonly kind: 'accessor'; readonly key: string | symbol; readonly type: AS3PropertyType;
        readonly getter: true; readonly setter: true});
interface Trait {
    readonly name: string; readonly visibility: 'private' | 'protected'; readonly static: boolean;
    readonly kind: 'variable' | 'method' | 'accessor'; readonly type?: AS3PropertyType; readonly parameterCount?: number;
    readonly getter?: boolean; readonly setter?: boolean;
}
interface Scope {
    readonly value: AS3LexicalScope; readonly type: AS3DeclarationType<unknown>;
    readonly base: Scope | null; readonly traits: ReadonlyMap<string, Trait>;
}
interface Binding {
    readonly trait: Trait; readonly key: string | symbol; readonly source?: Function;
    readonly get?: (this: object) => unknown; readonly set?: (this: object, value: unknown) => void;
}
interface Generation {
    readonly constructor: Function; readonly scope: Scope; readonly bindings: ReadonlyMap<string, Binding>;
}
interface Access { readonly scope: Scope; readonly owner: Scope; readonly trait: Trait; readonly super: boolean; }
const scopes = new WeakMap<object, Scope>();
const declarations = new WeakMap<object, Scope>();
const generations = new WeakMap<Function, Generation>();
const accesses = new WeakMap<object, Access>();
function unsupported(reason: string): never { throw new TypeError('AS3_LEXICAL_UNSUPPORTED: ' + reason); }
function error(id: number): never {
    const e = new ReferenceError('Error #' + id); Object.defineProperty(e, 'errorID', {value:id}); throw e;
}
function scope(value: AS3LexicalScope): Scope {
    return value && scopes.get(value) || unsupported('unknown lexical capability');
}
function key(name: string, visibility: string, isStatic: boolean): string {
    return JSON.stringify([isStatic, visibility, name]);
}
function sameType(a: AS3PropertyType | undefined, b: AS3PropertyType | undefined): boolean {
    return a === b || !!a && !!b && typeof a === 'object' && typeof b === 'object'
        && a.name === b.name && a.reference === b.reference;
}
function sameTrait(a: Trait, b: Trait): boolean {
    return a.name === b.name && a.visibility === b.visibility && a.static === b.static
        && a.kind === b.kind && a.parameterCount === b.parameterCount && sameType(a.type,b.type)
        && a.getter === b.getter && a.setter === b.setter;
}
/**
 * Register compiler/source-owned private/protected fields, methods and complete
 * accessor pairs after the
 * existing exact declaration generation has been published. Public reflection
 * is neither replaced nor extended with invented private members. Partial
 * accessor overrides and arbitrary method signatures remain unadmitted.
 */
export function registerAS3LexicalMembers(constructor: Function, base: AS3LexicalScope | null,
    members: readonly AS3LexicalMember[]): AS3LexicalScope {
    const type = getAS3DeclarationType(constructor);
    if (!type || isCanonicalAS3DeclarationConstructor(constructor)) unsupported('entered source declaration required');
    const parent = base === null ? null : scope(base);
    if (getAS3SourceBase(constructor) !== (parent?.type ?? null)) unsupported('sealed lexical source base mismatch');
    if (generations.has(constructor)) unsupported('generation already registered');
    if (!Array.isArray(members)) unsupported('complete supplied lexical member list required');
    const traits = new Map<string,Trait>(), bindings = new Map<string,Binding>(), storage = new Set<string|symbol>();
    const counts: Array<readonly [Function,number]> = [];
    for (const member of members) {
        if (!member || typeof member.name !== 'string' || !member.name
            || !['private','protected'].includes(member.visibility)
            || member.static !== undefined && typeof member.static !== 'boolean') unsupported('lexical member identity');
        const id = key(member.name,member.visibility,!!member.static);
        if (traits.has(id)) unsupported('duplicate lexical declaration');
        const trait: Trait = {name:member.name,visibility:member.visibility,static:!!member.static,kind:member.kind};
        let binding: Binding;
        if (member.kind === 'variable') {
            validateAS3PropertyType(member.type);
            const type = typeof member.type === 'object' ? Object.freeze({...member.type}) : member.type;
            Object.assign(trait,{type});
            binding = {trait,key:Symbol(member.name)};
        } else if (member.kind === 'method') {
            if (typeof member.key !== 'string' && typeof member.key !== 'symbol'
                || !Number.isSafeInteger(member.parameterCount) || member.parameterCount < 0) unsupported('method declaration');
            const owner = member.static ? constructor : Object.getOwnPropertyDescriptor(constructor,'prototype')?.value;
            const descriptor = Object.getOwnPropertyDescriptor(owner,member.key);
            if (!descriptor || !('value' in descriptor) || typeof descriptor.value !== 'function') unsupported('exact own source method required');
            Object.assign(trait,{parameterCount:member.parameterCount});
            // A declaration's cache key is independent of its native descriptor
            // key: base/private/super methods may share source and native names.
            if (storage.has(member.key)) unsupported('distinct lexical methods share native storage');
            storage.add(member.key);
            binding = {trait,key:Symbol(member.name),source:descriptor.value};
            counts.push([descriptor.value,member.parameterCount]);
        } else if (member.kind === 'accessor') {
            // Both source halves must be supplied. Inheriting or combining a
            // missing native half would claim unproven partial-override rules.
            if (member.getter !== true || member.setter !== true)
                unsupported('accessor/signature admission pending: complete source accessor pair required');
            if (typeof member.key !== 'string' && typeof member.key !== 'symbol') unsupported('accessor native key');
            validateAS3PropertyType(member.type);
            const owner = member.static ? constructor : Object.getOwnPropertyDescriptor(constructor,'prototype')?.value;
            const descriptor = owner && Object.getOwnPropertyDescriptor(owner,member.key);
            if (!descriptor || 'value' in descriptor || typeof descriptor.get !== 'function' || typeof descriptor.set !== 'function')
                unsupported('exact own source accessor pair required');
            if (storage.has(member.key)) unsupported('distinct lexical members share native storage');
            storage.add(member.key);
            const type = typeof member.type === 'object' ? Object.freeze({...member.type}) : member.type;
            Object.assign(trait,{type,getter:true,setter:true});
            binding = {trait,key:Symbol(member.name),get:descriptor.get,set:descriptor.set};
        } else unsupported('accessor/signature admission pending');
        Object.freeze(trait); Object.freeze(binding);
        traits.set(id,trait); bindings.set(id,binding);
    }
    const previous = declarations.get(type!);
    if (previous && (previous.base !== parent || previous.traits.size !== traits.size
        || [...traits].some(([id,trait]) => !previous.traits.has(id) || !sameTrait(previous.traits.get(id)!,trait))))
        unsupported('source declaration changed between generations');
    for (const trait of traits.values()) if (trait.visibility === 'protected') {
        for (let current = parent; current; current = current.base) {
            const inherited = current.traits.get(key(trait.name,'protected',trait.static));
            if (inherited && !(trait.kind === 'method' && inherited.kind === 'method'
                && trait.parameterCount === inherited.parameterCount
                || trait.kind === 'accessor' && inherited.kind === 'accessor' && sameTrait(trait,inherited)))
                unsupported('protected override/field conflict');
        }
    }
    const reflection = describeRegisteredFlashType(constructor)!;
    for (const [surface,isStatic] of [[reflection.factory!,false],[reflection,true]] as const) {
        for (const member of [...surface.variables,...surface.accessors,...surface.methods,...surface.constants ?? []]) {
            if (member.uri || member.declaredBy !== type!.name) continue;
            if (traits.has(key(member.name,'protected',isStatic))) unsupported('public/protected declaration conflict');
            for (let current = parent; current; current = current.base)
                if (current.traits.has(key(member.name,'protected',isStatic))) unsupported('public override of protected declaration');
        }
    }
    if ([...traits.values()].some(trait => trait.static && trait.kind === 'variable') && !Object.isExtensible(constructor))
        unsupported('static lexical storage requires extensible native constructor');
    // Validate all declarations and counts before publishing any new capability.
    registerAS3FunctionParameterCounts(counts);
    const record = previous ?? {value:Object.freeze({}) as AS3LexicalScope,type:type!,base:parent,traits};
    const generation = {constructor,scope:record,bindings};
    declarations.set(type!,record); scopes.set(record.value,record); generations.set(constructor,generation);
    initializeFields(generation,constructor,true);
    return record.value;
}
function defaultValue(type: AS3PropertyType): unknown {
    return type === '*' ? undefined : type === 'Number' ? NaN : type === 'int' || type === 'uint' ? 0
        : type === 'Boolean' ? false : null;
}
function initializeFields(generation: Generation, target: object, isStatic: boolean): void {
    for (const binding of generation.bindings.values()) if (binding.trait.static === isStatic && binding.trait.kind === 'variable') {
        if (!Object.getOwnPropertyDescriptor(target,binding.key))
            Object.defineProperty(target,binding.key,{value:defaultValue(binding.trait.type!),writable:true,enumerable:false,configurable:false});
    }
}
function entered(value: unknown): readonly Generation[] | undefined {
    const constructors = getAS3EnteredSourceConstructors(value);
    if (!constructors) return undefined;
    const chain = constructors.map(constructor => generations.get(constructor));
    if (chain.some(generation => !generation)) unsupported('entered source chain has unregistered lexical generation');
    return chain as Generation[];
}
/** Called after the ordinary compiler constructor-entry authority, before authored effects. */
export function initializeAS3LexicalInstance(lexical: AS3LexicalScope, target: object): void {
    const current = scope(lexical), chain = entered(target);
    if (!chain || !chain.some(generation => generation.scope === current)) unsupported('lexical initialization requires genuine source entry');
    for (const generation of [...chain].reverse()) initializeFields(generation,target,false);
}
/** Resolve a compile-time private/protected declaration in a sealed lexical scope. */
export function resolveAS3LexicalMember(lexical: AS3LexicalScope, name: string,
    visibility: 'private' | 'protected', isStatic: boolean = false, superAccess: boolean = false): AS3LexicalAccess {
    const current = scope(lexical);
    if (typeof name !== 'string' || !name || !['private','protected'].includes(visibility)
        || typeof isStatic !== 'boolean' || typeof superAccess !== 'boolean'
        || superAccess && (visibility !== 'protected' || isStatic)) unsupported('source lexical lookup');
    let owner: Scope | null = superAccess ? current.base : current;
    for (; owner; owner = visibility === 'private' ? null : owner.base) {
        const trait = owner.traits.get(key(name,visibility,isStatic));
        if (trait) {
            const value = Object.freeze({}) as AS3LexicalAccess;
            accesses.set(value,{scope:current,owner,trait,super:superAccess}); return value;
        }
    }
    return unsupported('source lexical declaration not found');
}
function access(value: AS3LexicalAccess): Access { return value && accesses.get(value) || unsupported('unknown lexical access'); }
function select(request: Access, target: unknown): {generation:Generation;binding:Binding;target:object} | undefined {
    let chain: readonly Generation[] | undefined;
    if (request.trait.static) {
        const generation = typeof target === 'function' ? generations.get(target) : undefined;
        if (!generation || generation.scope !== request.owner) return undefined;
        const binding = generation.bindings.get(key(request.trait.name,request.trait.visibility,true));
        return binding ? {generation,binding,target:target as object} : undefined;
    } else chain = entered(target);
    if (!chain || !chain.some(generation => generation.scope === request.scope)) return undefined;
    const virtual = request.trait.kind !== 'variable' && request.trait.visibility === 'protected' && !request.super;
    const id = key(request.trait.name,request.trait.visibility,request.trait.static);
    for (const generation of chain) {
        if (!virtual && generation.scope !== request.owner) continue;
        const binding = generation.bindings.get(id);
        if (binding) return {generation,binding,target:target as object};
    }
    return undefined;
}
export function as3GetLexicalMember(target: unknown, capability: AS3LexicalAccess): unknown {
    const request = access(capability);
    if (target == null) return as3GetProperty(target,request.trait.name);
    const found = select(request,target);
    if (!found) return error(1069);
    const {binding} = found;
    if (binding.trait.kind === 'method') return getBoundAS3Method(found.target,binding.key,binding.source!);
    // Return conversion belongs inside the lowered source body: adding it here
    // would reorder source catch/finally effects and cannot emulate AS3 returns.
    if (binding.trait.kind === 'accessor') return Reflect.apply(binding.get!,found.target,[]);
    const stored = Object.getOwnPropertyDescriptor(found.target,binding.key);
    if (!stored || !('value' in stored)) return unsupported('lexical fields must be initialized before source access');
    return stored.value;
}
export function as3SetLexicalMember<T>(target: unknown, capability: AS3LexicalAccess, value: T): T {
    const request = access(capability);
    if (target == null) {as3SetProperty(target,request.trait.name,value); return value;}
    const found = select(request,target);
    if (!found) return error(1056);
    if (found.binding.trait.kind === 'accessor') {
        const converted = coerceAS3PropertyValue(value,found.binding.trait.type!);
        Reflect.apply(found.binding.set!,found.target,[converted]);
        return value;
    }
    if (found.binding.trait.kind !== 'variable') return unsupported('source method assignment not admitted');
    if (!Object.getOwnPropertyDescriptor(found.target,found.binding.key)) return unsupported('lexical fields must be initialized before source access');
    const converted = coerceAS3PropertyValue(value,found.binding.trait.type!);
    Object.defineProperty(found.target,found.binding.key,{value:converted}); return value;
}
export function as3CallLexicalMember(target: unknown, capability: AS3LexicalAccess, argumentsThunk:()=>unknown[]): unknown {
    const fn = as3GetLexicalMember(target,capability);
    return as3CallValue(fn,argumentsThunk,target);
}
function dynamicAccess(current: Scope, name: string): AS3LexicalAccess | undefined {
    if (current.traits.has(key(name,'private',false))) return resolveAS3LexicalMember(current.value,name,'private');
    for (let owner: Scope | null = current; owner; owner = owner.base)
        if (owner.traits.has(key(name,'protected',false))) return resolveAS3LexicalMember(current.value,name,'protected');
    return undefined;
}
/** Dynamic multiname lookup; an explicit QName retains the public helper's namespace policy. */
export function as3GetLexicalProperty(lexical: AS3LexicalScope, target: unknown, property: unknown): unknown {
    const current = scope(lexical);
    if (property instanceof QName) return property.uri === ''
        ? as3GetProperty(target,property.localName,'public') : as3GetProperty(target,property);
    const name = as3String(property);
    if (as3HasProperty(name,target)) return as3GetProperty(target,name,'public');
    const capability = dynamicAccess(current,name);
    if (capability && !getAS3EnteredSourceConstructors(target)) unsupported('dynamic lexical lookup requires entered source receiver');
    return capability ? as3GetLexicalMember(target,capability) : as3GetProperty(target,name);
}
export function as3SetLexicalProperty<T>(lexical: AS3LexicalScope, target: unknown, property: unknown, value:T): T {
    const current = scope(lexical);
    if (property instanceof QName) return property.uri === ''
        ? as3SetProperty(target,property.localName,value,'public') : as3SetProperty(target,property,value);
    const name = as3String(property);
    if (as3HasProperty(name,target)) return as3SetProperty(target,name,value,'public');
    const capability = dynamicAccess(current,name);
    if (capability && !getAS3EnteredSourceConstructors(target)) unsupported('dynamic lexical lookup requires entered source receiver');
    return capability ? as3SetLexicalMember(target,capability,value) : as3SetProperty(target,name,value);
}
