import { as3CreateArray } from "./AS3ArrayCreation";
import { AS3Int, AS3Uint, isAS3Interface, as3CoerceReference } from "./AS3Type";
import { as3CoerceInt, as3CoerceUint, as3CoerceNumber } from "./AS3Coercion";
import { as3String } from "./AS3String";
import { as3CreateDynamicObject } from "./AS3DynamicObject";
import type { AS3Class, AS3Interface } from "./AS3Type";
import { describeRegisteredFlashType } from "./FlashTypeMetadata";

declare const classTypeBrand: unique symbol;
/** Exact operand representing the source Class class itself. */
export interface AS3ClassTypeToken { readonly [classTypeBrand]: true; }
export const AS3ClassType = Object.freeze({ name: "Class" }) as unknown as AS3ClassTypeToken;
export type AS3ClassValue = AS3Class<unknown> | AS3Interface<unknown> | AS3ClassTypeToken;

const builtinClasses: ReadonlySet<unknown> = new Set([
    Object, Array, Number, String, Boolean, Function, AS3Int, AS3Uint, AS3ClassType,
]);

/** Exact canonical builtin identity; diagnostic names on other values grant no authority. */
export function getAS3BuiltinClassName(value: unknown): string | undefined {
    if (value === AS3ClassType) return "Class";
    if (value === AS3Int) return "int";
    if (value === AS3Uint) return "uint";
    if (value === Object) return "Object";
    if (value === Function) return "Function";
    if (value === Number) return "Number";
    if (value === String) return "String";
    if (value === Boolean) return "Boolean";
    if (value === Array) return "Array";
    return undefined;
}

/**
 * Compiler/source constructor prefix, applied before native allocation/fields.
 * Only supplied arguments are coerced. Preserve their count and order; omitted
 * defaults and source arguments.length semantics belong to the native signature.
 * Source use of rest or arguments uses maximum=Infinity; an ordinary signature
 * retains its finite maximum. The callback uses existing common
 * coercion primitives and must not repeat those effects in the constructor body.
 */
export interface AS3ConstructorContext {
    readonly minimum: number;
    readonly maximum: number;
    readonly coerceArguments: (arguments_: readonly unknown[]) => readonly unknown[];
}
const constructors = new WeakMap<Function, Readonly<AS3ConstructorContext>>();

function unsupported(reason: string): never {
    throw new TypeError("AS3_CLASS_UNSUPPORTED: " + reason);
}

function sourceError(name: "TypeError" | "ArgumentError" | "VerifyError" | "EvalError", errorID: number): never {
    const error = name === "TypeError" ? new TypeError("Error #" + errorID) : new Error("Error #" + errorID);
    error.name = name;
    Object.defineProperty(error, "errorID", { value: errorID });
    throw error;
}

/**
 * Call a Class value after argument evaluation. Source classes/interfaces cast
 * exactly one argument; this never invokes their constructor. Builtin scalar
 * calls have their own defaults and ignore already evaluated extra arguments.
 * Array calls allocate through the common source creation provider.
 */
export function as3CallClass(value: unknown, arguments_: readonly unknown[] = []): unknown {
    const target = as3AsClass(value);
    if (target === null) return sourceError("TypeError", 1006);
    const args = suppliedArguments(arguments_);
    if (target === Array) return as3CreateArray(args);
    if (target === Object) return args[0] == null ? as3CreateDynamicObject() : args[0];
    if (target === Number) return args.length === 0 ? 0 : as3CoerceNumber(args[0]);
    if (target === String) return args.length === 0 ? "" : as3String(args[0]);
    if (target === Boolean) return args.length === 0 ? false : Boolean(args[0]);
    if (target === AS3Int) return args.length === 0 ? 0 : as3CoerceInt(args[0]);
    if (target === AS3Uint) return args.length === 0 ? 0 : as3CoerceUint(args[0]);
    if (target === Function) {
        if (args.length) return sourceError("EvalError", 1066);
        return function(): void {};
    }
    if (args.length !== 1) return sourceError("ArgumentError", 1112);
    if (target === AS3ClassType) return as3CoerceClass(args[0]);
    return as3CoerceReference(args[0], target as AS3Class<unknown> | AS3Interface<unknown>);
}

/**
 * Source `value as Class`. Native source class identity requires exact existing
 * FlashTypeMetadata; implements registration or mutable names grant no identity.
 * Resolve lazy compiler handles with readNativeClass at the source access point
 * before calling this helper. Proxies and ES5 constructor-role impersonation are
 * outside its source representation contract.
 */
export function as3AsClass(value: unknown): AS3ClassValue | null {
    if (builtinClasses.has(value) || isAS3Interface(value)) return value as AS3ClassValue;
    if (typeof value === "symbol" || typeof value === "bigint") return unsupported("host-only primitive");
    if (typeof value !== "function") return null;
    const description = describeRegisteredFlashType(value);
    if (description?.isStatic) return value as AS3ClassValue;
    const descriptor = Object.getOwnPropertyDescriptor(value, "prototype");
    if (descriptor && !descriptor.writable) return unsupported("native class lacks exact source metadata");
    return null;
}

/** Source typed Class argument/assignment coercion. */
export function as3CoerceClass(value: unknown): AS3ClassValue | null {
    if (value === null || value === undefined) return null;
    const result = as3AsClass(value);
    return result === null ? sourceError("TypeError", 1034) : result;
}

/**
 * Publish a proven native source constructor signature. This supplements exact
 * reflected class identity and does not publish definitions, initialize classes,
 * register aliases, or interpret source method bodies.
 */
export function registerAS3Constructor(constructor: AS3Class<unknown>, context: AS3ConstructorContext): void {
    if (typeof constructor !== "function" || !describeRegisteredFlashType(constructor)?.isStatic)
        return unsupported("constructor registration requires exact source class metadata");
    if (!context || !Number.isSafeInteger(context.minimum) || context.minimum < 0
        || (context.maximum !== Infinity && (!Number.isSafeInteger(context.maximum) || context.maximum < context.minimum))
        || typeof context.coerceArguments !== "function")
        throw new TypeError("Invalid source constructor signature");
    const previous = constructors.get(constructor);
    if (previous) {
        if (previous.minimum !== context.minimum || previous.maximum !== context.maximum
            || previous.coerceArguments !== context.coerceArguments)
            throw new TypeError("Conflicting source constructor signature");
        return;
    }
    constructors.set(constructor, Object.freeze({ minimum: context.minimum, maximum: context.maximum,
        coerceArguments: context.coerceArguments }));
}

function suppliedArguments(value: readonly unknown[]): unknown[] {
    if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype)
        return unsupported("constructor arguments require an ordinary compiler argument list");
    const result: unknown[] = [];
    for (let index = 0; index < value.length; index++) {
        const item = Object.getOwnPropertyDescriptor(value, String(index));
        if (!item || !("value" in item)) return unsupported("constructor argument list must contain dense data slots");
        result.push(item.value);
    }
    return result;
}

/**
 * Construct a source Class value with an already evaluated argument list.
 * Registered source constructor arity/coercion precedes native instance fields;
 * bodies, base calls and allocation remain ordinary native class execution.
 * This does not repair derived field-before-super compiler ordering.
 */
export function as3ConstructClass(value: unknown, arguments_: readonly unknown[] = []): unknown {
    const constructor = as3AsClass(value);
    if (constructor === null) return sourceError("TypeError", 1007);
    if (constructor === AS3ClassType) return sourceError("TypeError", 1115);
    if (isAS3Interface(constructor)) return sourceError("VerifyError", 1001);
    if (constructor === Array) return as3CreateArray(suppliedArguments(arguments_));
    // Builtin construction has distinct allocation/default/coercion semantics;
    // Class identity alone does not authorize Reflect.construct on a host builtin.
    if (typeof constructor !== "function" || builtinClasses.has(constructor))
        return unsupported("builtin constructor requires its own construction provider");
    const context = constructors.get(constructor);
    if (!context) return unsupported("source class lacks a proven constructor context");
    const supplied = suppliedArguments(arguments_);
    if (supplied.length < context.minimum || supplied.length > context.maximum)
        return sourceError("ArgumentError", 1063);
    const coerced = suppliedArguments(context.coerceArguments(Object.freeze(supplied)));
    if (coerced.length !== supplied.length) return unsupported("constructor prefix changed source argument count");
    return Reflect.construct(constructor, coerced);
}
