import { isAS3DeclarationType } from "./AS3DeclarationType";
import { AS3ScriptPrivateScope, validateAS3ScriptPrivateScope, isAS3ScriptGlobal, getAS3BuiltinScriptGlobal, readAS3ScriptGlobalDeclaration, hasAS3ScriptGlobalDeclaration, setAS3ScriptGlobalProperty, deleteAS3ScriptGlobalProperty } from './AS3ScriptGlobal';
import { installAS3SourcePublicConversionResolver } from "./AS3ConversionMethodResolver";
import { isAS3MethodClosure, getBoundAS3Method, getAS3MethodSource, registerAS3BoundMethodClosure, registerAS3FunctionParameterCount, registerAS3FunctionParameterCounts } from "./AS3MethodBinding";
import { as3CoerceInt, as3CoerceNumber, as3CoerceObject, as3CoerceUint } from "./AS3Coercion";
import { as3SetDynamicProperty, as3DefineDynamicProperty } from "./AS3DynamicObject";
import { as3CoerceString, as3InvokeToStringMethod, as3String } from "./AS3String";
import { as3CoerceReference, as3CheckArgumentCount, isAS3Interface, AS3Type } from "./AS3Type";
import { AS3ClassType, getAS3BuiltinClassName } from "./AS3Class";
import { registerAS3Function, as3CallValue, getAS3FunctionIntrinsic, getAS3FunctionPrototype, setAS3FunctionPrototype, getAS3FunctionLength, getAS3FunctionPrototypeIntrinsic } from "./AS3Invocation";
import { as3ObjectPrototype, as3PrototypeOf, as3PrototypeContains, isAS3Prototype,
    getRegisteredAS3ClassPrototype, registerAS3BuiltinObjectDelegate, registerAS3ClassPrototype, getAS3RegisteredPrototypeConstructor, registerAS3ClassValueParent } from "./AS3ObjectModel";
import { as3Is } from "./AS3Type";
import { QName } from "./QName";
import { describeRegisteredFlashType } from "./FlashTypeMetadata";
import { Dictionary, isFlashDictionary, getDictionarySourcePrototype } from "./Dictionary";
import { isAS3SourceError, sourceErrorField, setSourceErrorField, sourceErrorDynamic,
    setSourceErrorDynamic, deleteSourceErrorDynamic, sourceErrorParent,
    sourceErrorEnumerable, setSourceErrorEnumerable } from "../errors/AS3SourceError";

export type AS3DynamicPropertyNamespaces = "public" | "public-and-AS3";
export type AS3PropertyType = "*" | "int" | "uint" | "Number" | "Boolean" | "String" | "Object" | "Function"
    | { readonly name: string; readonly reference: AS3Type<any> };
export interface AS3PropertyTrait {
    readonly name: string;
    readonly kind: "variable" | "constant" | "accessor" | "method";
    /** Exact native storage key, permitting private/public names to coexist. */
    readonly key?: string | symbol;
    readonly type?: AS3PropertyType;
}
interface Trait extends AS3PropertyTrait { readonly key: string | symbol; readonly descriptor?: PropertyDescriptor; readonly parameterCount?: number; }
interface Record {
    readonly constructor: Function | typeof AS3ClassType;
    readonly function?: boolean;
    readonly conversionOnly?: boolean;
    readonly dynamic: boolean;
    readonly static: boolean;
    readonly traits: ReadonlyMap<string, Trait>;
}
const instances = new WeakMap<object, Record>();
const constructors = new WeakMap<Function, Record>();
const functionRecord: Record = {constructor:Function,dynamic:true,static:false,function:true,traits:new Map()};
const methodClosureRecord: Record = {...functionRecord,dynamic:false};
const builtinClassRecords = new Map<object, Record>([Object,Function,AS3ClassType].map(constructor =>
    [constructor,{constructor,dynamic:true,static:true,traits:new Map()}]));
// Dynamic source slots are distinct from private/protected native storage.
const dynamicSlots = new WeakMap<object, Map<string, unknown>>();
const nonEnumerableSlots = new WeakMap<object, Set<string>>();
let functionPrototypeInitialized = false;
function initializeFunctionPrototype(): void {
    if (functionPrototypeInitialized) return;
    dynamicSlots.set(Function.prototype,new Map<string,unknown>([
        ["constructor",Function],["call",getAS3FunctionPrototypeIntrinsic("call")!],
        ["apply",getAS3FunctionPrototypeIntrinsic("apply")!],
    ]));
    nonEnumerableSlots.set(Function.prototype,new Set(["constructor","call","apply"]));
    functionPrototypeInitialized = true;
}
const as3Methods = new Set(["hasOwnProperty", "propertyIsEnumerable", "isPrototypeOf"]);
function dictionaryAS3Method(key: QName): boolean {
    return key.uri === "http://adobe.com/AS3/2006/builtin" && as3Methods.has(key.localName);
}
const intrinsicNames = new Set(["constructor", ...as3Methods, "toString", "toLocaleString", "valueOf", "setPropertyIsEnumerable"]);

function failure(name: "TypeError" | "ReferenceError", errorID: number): never {
    const error = name === "TypeError" ? new TypeError(`Error #${errorID}`) : new ReferenceError(`Error #${errorID}`);
    Object.defineProperty(error, "errorID", { value: errorID });
    throw error;
}
function unsupported(reason: string): never { throw new TypeError("Unsupported source property representation: " + reason); }
function receiver(value: unknown): object {
    if (value === null) return failure("TypeError", 1009);
    if (value === undefined) return failure("TypeError", 1010);
    if (typeof value !== "object" && typeof value !== "function") return unsupported("primitive receiver");
    return value;
}
function propertyName(value: unknown): string {
    if (value instanceof QName) unsupported("namespaced property keys are unsupported");
    return as3String(value);
}
function namespace(value: AS3DynamicPropertyNamespaces): void {
    if (value !== "public" && value !== "public-and-AS3") unsupported("namespace set");
}
/** @internal Shared validation for compiler-owned public and lexical trait tables. */
export function validateAS3PropertyType(type: AS3PropertyType | undefined): string {
    if (typeof type === "string" && ["*", "int", "uint", "Number", "Boolean", "String", "Object", "Function"].includes(type)) return type;
    if (type && typeof type === "object" && typeof type.name === "string" && type.name.length
        && (isAS3DeclarationType(type.reference) && type.reference.name === type.name || isAS3Interface(type.reference) || typeof type.reference === "function" && typeof Object.getOwnPropertyDescriptor(type.reference, "prototype")?.value === "object"))
        return type.name;
    return unsupported("missing or invalid declared type");
}
/** @internal The same source coercion applies to public and lexical storage. */
export function coerceAS3PropertyValue(value: unknown, type: AS3PropertyType): unknown {
    switch (type) {
        case "*": return value;
        case "int": return as3CoerceInt(value);
        case "uint": return as3CoerceUint(value);
        case "Number": return as3CoerceNumber(value);
        case "Boolean": return Boolean(value);
        case "String": return as3CoerceString(value);
        case "Object": return as3CoerceObject(value);
        case "Function": return as3CoerceReference(value, Function);
        default: return as3CoerceReference(value, type.reference);
    }
}
function descriptor(prototype: object, key: string | symbol): PropertyDescriptor | undefined {
    for (let current: object | null = prototype; current && current !== Object.prototype; current = Object.getPrototypeOf(current)) {
        const found = Object.getOwnPropertyDescriptor(current, key);
        if (found) return found;
    }
    return undefined;
}

/**
 * Publish the complete public dispatch surface from source/compiler authority.
 * Reflection alone cannot infer accessor types. Legacy reflection without a
 * constants list permits supplemental source constants; an explicit constants
 * list requires exhaustive matching like the other source trait categories.
 */
export function registerAS3PropertyTraits(constructor: Function, input: readonly AS3PropertyTrait[],
    statics: readonly AS3PropertyTrait[] = []): void {
    const reflection = describeRegisteredFlashType(constructor);
    if (!reflection?.isStatic || !reflection.factory) unsupported("class needs exact reflection metadata");
    if (constructors.has(constructor)) unsupported("dispatch metadata already registered");
    const prototype = Object.getOwnPropertyDescriptor(constructor, "prototype")?.value;
    const instance = describeRegisteredFlashType(Object.create(prototype));
    if (!instance) unsupported("instance metadata");
    const traits = buildTraits(input, instance, prototype, false);
    const staticTraits = buildTraits(statics, reflection, constructor, true);
    registerAS3ClassValueParent(constructor);
    sourceClassPrototype(constructor, false);
    registerAS3FunctionParameterCounts([...traits.values(),...staticTraits.values()]
        .filter(trait => trait.kind === "method").map(trait => [trait.descriptor!.value,trait.parameterCount!] as const));
    instances.set(prototype, Object.freeze({ constructor, dynamic: instance.isDynamic, static: false, traits }));
    constructors.set(constructor, Object.freeze({ constructor, dynamic: true, static: true, traits: staticTraits }));
}
function buildTraits(input: readonly AS3PropertyTrait[], surface: NonNullable<ReturnType<typeof describeRegisteredFlashType>>,
    prototype: object, statics: boolean): ReadonlyMap<string, Trait> {
    const expected = new Map<string, { kind: string; type?: string; access?: string; parameterCount?: number }>();
    for (const [kind, list] of [["variable", surface.variables], ["accessor", surface.accessors],
        ["method", surface.methods], ["constant", surface.constants ?? []]] as const)
        for (const item of list) if (!item.uri && (!statics || item.declaredBy === surface.name)) expected.set(item.name, { kind, ...item });
    const traits = new Map<string, Trait>();
    const storage = new Set<string | symbol>();
    if (!Array.isArray(input)) unsupported("dense trait list required");
    for (const item of input) {
        if (!item || typeof item.name !== "string" || !item.name || traits.has(item.name)) unsupported("duplicate/invalid trait");
        const match = expected.get(item.name);
        if (match ? match.kind !== item.kind : item.kind !== "constant" || surface.constants !== undefined)
            unsupported("trait does not match reflected public authority");
        const key = item.key ?? item.name;
        if (typeof key !== "string" && typeof key !== "symbol") unsupported("native storage key");
        if (storage.has(key)) unsupported("distinct source traits share native storage");
        storage.add(key);
        let captured: PropertyDescriptor | undefined;
        let type = item.type;
        if (item.kind !== "method") {
            const name = validateAS3PropertyType(type);
            if (match?.type && name !== match.type) unsupported("variable type differs from reflection");
            if (type && typeof type === "object") type = Object.freeze({ name: type.name, reference: type.reference });
        }
        if (item.kind === "accessor" || item.kind === "method") {
            captured = statics ? Object.getOwnPropertyDescriptor(prototype, key) : descriptor(prototype, key);
            if (!captured) unsupported("declared prototype trait missing");
            if (item.kind === "method" && typeof captured.value !== "function") unsupported("method descriptor");
            if (item.kind === "method" && typeof key !== "string") unsupported("symbol method closure binding");
            if (item.kind === "accessor" && (Boolean(captured.get) !== (match!.access !== "writeonly")
                || Boolean(captured.set) !== (match!.access !== "readonly"))) unsupported("accessor descriptor differs from reflection");
            if (item.kind === "method" && statics) captured = { ...captured, value: getAS3MethodSource(prototype, key as string, captured.value) };
            captured = Object.freeze({ ...captured });
        }
        traits.set(item.name, Object.freeze({ name: item.name, kind: item.kind, key, type, descriptor: captured, parameterCount: match?.parameterCount }));
        expected.delete(item.name);
    }
    if (expected.size) unsupported("incomplete public trait surface");
    return traits;
}

function context(target: object): Record | null {
    initializeObjectPrototype();
    if (target === Dictionary) getDictionarySourcePrototype();
    if (isAS3ScriptGlobal(target)) return null;
    if (Array.isArray(target)) { initializeArrayPrototype(target); return null; }
    const record = typeof target === "function" ? constructors.get(target) : instances.get(Object.getPrototypeOf(target));
    if (record) {
        if (!record.static && record.constructor === Dictionary)
            return unsupported("Dictionary instances require private storage identity");
        sourceClassPrototype(record.constructor, false);
        return record;
    }
    if (builtinClassRecords.has(target)) return builtinClassRecords.get(target)!;
    if (getAS3BuiltinClassName(target) !== undefined) {
        registerAS3ClassValueParent(target);
        const builtin: Record = {constructor:target as typeof AS3ClassType, dynamic:true,
            static:true, conversionOnly:true, traits:new Map()};
        builtinClassRecords.set(target,builtin);
        return builtin;
    }
    if (typeof target === "function" && as3Is(target, Function)) {initializeFunctionPrototype(); return isAS3MethodClosure(target) ? methodClosureRecord : functionRecord;}
    // A source Class without dispatch traits must not fall through its native
    // Function prototype and expose raw constructor/prototype implementation data.
    if (typeof target === "function") return unsupported("Class property dispatch requires registered source properties");
    if (Object.getPrototypeOf(target) === Object.prototype || isAS3Prototype(Object.getPrototypeOf(target))) return null;
    return unsupported("unregistered class, Class, Array, Dictionary, Proxy, or custom prototype");
}
// Ordinary native Arrays preserve sparse element storage. Never read the host
// Array prototype: source delegates and namespace traits own method lookup.
const arrayClosures = new WeakMap<object, Function>();
const remainingArrayMethods = new Set(["concat","every","filter","forEach","indexOf","lastIndexOf","join","map","pop","reverse","shift","slice","some","sort","sortOn","splice","unshift","toString","toLocaleString"]);
let arrayPrototypeInitialized = false;
function initializeArrayPrototype(target: object): void {
    if (Object.getPrototypeOf(target) !== Array.prototype) unsupported("Array subclass or host prototype mutation");
    const length = Object.getOwnPropertyDescriptor(target,"length");
    if (!length || !("value" in length) || !length.writable || length.configurable || length.enumerable)
        unsupported("host Array length descriptor");
    if (arrayPrototypeInitialized) return;
    const prototype = registerAS3BuiltinObjectDelegate(Array);
    const push = function(this: unknown, ...values: unknown[]): number { return pushArrayValues(receiver(this),values); };
    registerAS3Function(push,getAS3BuiltinScriptGlobal(),0);
    Object.defineProperty(prototype,"push",{value:push,writable:true,configurable:true,enumerable:false});
    arrayPrototypeInitialized = true;
}
function arrayIndex(name: string): boolean {
    const value = Number(name);
    return Number.isInteger(value) && value >= 0 && value < 4294967295 && String(value) === name;
}
function pushArrayValues(target: object, values: readonly unknown[]): number {
    if (Array.isArray(target)) {
        initializeArrayPrototype(target);
        for (const value of values) as3DefineDynamicProperty(target,String(target.length),value);
        return target.length;
    }
    let length = as3CoerceUint(as3GetProperty(target,"length"));
    for (const value of values) { as3SetProperty(target,String(length),value); length = (length + 1) >>> 0; }
    as3SetProperty(target,"length",length);
    return length;
}
function arrayPush(target: object): Function {
    let closure = arrayClosures.get(target);
    if (!closure) {
        closure = (...values: unknown[]) => pushArrayValues(target,values);
        registerAS3BoundMethodClosure(closure,0); arrayClosures.set(target,closure);
    }
    return closure;
}
function setArrayLength(target: unknown[], value: unknown): void {
    const length = as3CoerceUint(value);
    // Reject host restrictions before truncation can partially modify storage.
    if (length < target.length) for (const key of Object.getOwnPropertyNames(target)) {
        if (arrayIndex(key) && Number(key) >= length && !Object.getOwnPropertyDescriptor(target,key)!.configurable)
            unsupported("host restricted Array element");
    }
    Object.defineProperty(target,"length",{value:length});
}
function arrayPublicName(key: QName): string {
    if (key.uri !== "") return unsupported("non-public Array key namespace");
    return key.localName;
}

function ownData(target: object, key: string | symbol): PropertyDescriptor | undefined {
    const found = Object.getOwnPropertyDescriptor(target, key);
    if (found && !("value" in found)) unsupported("dynamic/native slot is an accessor");
    return found;
}
// Builtin conversion delivery does not invent an exhaustive static trait surface.
const classConversionProperties = new Set(["toString","toLocaleString","valueOf","constructor",
    "hasOwnProperty","propertyIsEnumerable","isPrototypeOf","setPropertyIsEnumerable"]);
function validateClassProperty(record: Record | null, name: string): void {
    if (record?.conversionOnly && !classConversionProperties.has(name))
        unsupported("builtin Class property requires its own source metadata");
}
function own(target: object, name: string, record: Record | null): boolean {
    validateClassProperty(record,name);
    if (isAS3ScriptGlobal(target) && hasAS3ScriptGlobalDeclaration(target, name)) return true;
    return record ? (record.static || record.function) && name === "prototype" || record.function && name === "length" || record.traits.has(name) || !!dynamicSlots.get(target)?.has(name) : !!ownData(target, name);
}

/** Dictionary can supply its own key semantics without duplicating Object methods. */
export interface AS3ObjectIntrinsicOperations {
    hasOwnProperty(key: unknown): boolean;
    propertyIsEnumerable(key: unknown): boolean;
    isPrototypeOf(value: unknown): boolean;
    setPropertyIsEnumerable(key: unknown, enumerable: unknown): void;
    toString?(): unknown;
}
const intrinsicClosures = new WeakMap<object, Map<string, Function>>();
const intrinsicOperations = new WeakMap<object, AS3ObjectIntrinsicOperations>();
const publicWrappers = new Map<string, Function>();
function invokeIntrinsic(target: unknown, name: string, args: unknown[]): unknown {
    const object = receiver(target);
    const ops = intrinsicOperations.get(object) ?? operations(object, context(object));
    if (name === "setPropertyIsEnumerable") as3CheckArgumentCount(args.length, 2, 2);
    else if (as3Methods.has(name)) as3CheckArgumentCount(args.length, 0, 1);
    switch (name) {
        case "hasOwnProperty": return ops.hasOwnProperty(args[0]);
        case "propertyIsEnumerable": return ops.propertyIsEnumerable(args[0]);
        case "isPrototypeOf": return ops.isPrototypeOf(args[0]);
        case "setPropertyIsEnumerable": return ops.setPropertyIsEnumerable(args[0], args[1]);
        case "valueOf": return object;
        case "toString": return Object.prototype.hasOwnProperty.call(ops, "toString") ? ops.toString!() : as3InvokeToStringMethod(object, Object.prototype.toString);
        case "toLocaleString": return Object.prototype.hasOwnProperty.call(ops, "toString") ? ops.toString!() : as3InvokeToStringMethod(object, Object.prototype.toString);
    }
    return undefined;
}
/**
 * Resolve an Object intrinsic with a provider's key semantics. Public wrappers
 * are shared functions and use their call receiver. The three AS3 methods are
 * stable receiver-bound closures. Constructor/toJSON belong to the provider.
 */
export function getAS3ObjectIntrinsic(target: object, name: string,
    namespaces: AS3DynamicPropertyNamespaces, provider: AS3ObjectIntrinsicOperations): Function | undefined {
    namespace(namespaces);
    if (!intrinsicNames.has(name) || name === "constructor") return undefined;
    for (const name of ["hasOwnProperty", "propertyIsEnumerable", "isPrototypeOf", "setPropertyIsEnumerable"] as const)
        if (typeof provider[name] !== "function") unsupported("Object intrinsic provider operations");
    intrinsicOperations.set(target, Object.freeze({
        hasOwnProperty: provider.hasOwnProperty, propertyIsEnumerable: provider.propertyIsEnumerable,
        isPrototypeOf: provider.isPrototypeOf, setPropertyIsEnumerable: provider.setPropertyIsEnumerable,
        ...(Object.prototype.hasOwnProperty.call(provider, "toString") ? { toString: provider.toString } : {}),
    }));
    if (namespaces === "public-and-AS3" && as3Methods.has(name)) {
        let cache = intrinsicClosures.get(target);
        if (!cache) intrinsicClosures.set(target, cache = new Map());
        let fn = cache.get(name);
        if (!fn) { fn = (...args: unknown[]) => invokeIntrinsic(target, name, args); registerAS3BoundMethodClosure(fn,1); cache.set(name, fn); }
        return fn;
    }
    return publicWrapper(name);
}
function publicWrapper(name: string): Function {
    if (name === "toLocaleString") name = "toString";
    let fn = publicWrappers.get(name);
    if (!fn) {
        fn = function(this: object, ...args: unknown[]) { return invokeIntrinsic(this, name, args); };
        registerAS3Function(fn, getAS3BuiltinScriptGlobal(), name === "setPropertyIsEnumerable" ? 2 : as3Methods.has(name) ? 1 : 0);
        publicWrappers.set(name, fn);
    }
    return fn;
}
let objectPrototypeInitialized = false;
function initializeObjectPrototype(): void {
    if (objectPrototypeInitialized) return;
    for (const name of intrinsicNames) if (name !== "constructor")
        Object.defineProperty(as3ObjectPrototype,name,{value:publicWrapper(name),writable:true,configurable:true,enumerable:false});
    objectPrototypeInitialized = true;
}
/**
 * Builtin Object-derived providers supply exact receiver operations without
 * inventing class reflection. Stored undefined differs from an absent delegate
 * slot. Public values remain mutable; AS3 methods retain bound precedence.
 */
export function getAS3ObjectDelegateProperty(target: object, name: string,
    namespaces: AS3DynamicPropertyNamespaces, provider: AS3ObjectIntrinsicOperations): {value:unknown} | undefined {
    namespace(namespaces); initializeObjectPrototype();
    // Publish operations even for public nonfunction values: a subsequently
    // called shared wrapper may reenter another Object method on this receiver.
    getAS3ObjectIntrinsic(target,"valueOf","public",provider);
    if (namespaces === "public-and-AS3" && as3Methods.has(name))
        return {value:getAS3ObjectIntrinsic(target,name,namespaces,provider)};
    return delegateValue(target,name);
}

function sourceClassPrototype(constructor: Function | typeof AS3ClassType, required: boolean = true): object | undefined {
    const known = getRegisteredAS3ClassPrototype(constructor);
    if (known) return known;
    if (typeof constructor !== "function") unsupported("source Class prototype identity");
    const native = Object.getOwnPropertyDescriptor(constructor, "prototype")?.value;
    const parent = Object.getPrototypeOf(native);
    let base: Function | null = null;
    if (parent !== Object.prototype) {
        const record = instances.get(parent);
        const authority = getAS3RegisteredPrototypeConstructor(parent) ?? record?.constructor;
        if (typeof authority !== "function") {
            if (required) unsupported("source base delegate requires its own registered class or builtin delegate authority");
            return undefined;
        }
        base = authority;
        if (!sourceClassPrototype(base,required)) return undefined;
    }
    return registerAS3ClassPrototype(constructor, base);
}
function delegateValue(target: object, name: string): {value:unknown} | undefined {
    for (let parent = as3PrototypeOf(target); parent; parent = as3PrototypeOf(parent)) {
        const record = typeof parent === "function" ? context(parent) : null;
        if (record) {
            if (dynamicSlots.get(parent)?.has(name)) return {value:dynamicSlots.get(parent)!.get(name)};

        } else {
            const data = ownData(parent, name);
            if (data) return {value:data.value};
        }
    }
    return undefined;
}
function operations(target: object, record: Record | null): AS3ObjectIntrinsicOperations {
    return {
        hasOwnProperty: key => own(target, as3String(as3CoerceString(key)), record),
        propertyIsEnumerable: key => {
            const name = as3String(as3CoerceString(key));
            return record ? !!dynamicSlots.get(target)?.has(name) && !nonEnumerableSlots.get(target)?.has(name) : !!ownData(target, name)?.enumerable;
        },
        isPrototypeOf: value => {
            if (record?.static) sourceClassPrototype(record.constructor);
            return as3PrototypeContains(target, value);
        },
        ...(!record && isAS3Prototype(Object.getPrototypeOf(target)) ? {toString: () => "[object Object]"} : {}),
        ...(record?.static || record?.function ? { toString: () => as3InvokeToStringMethod(target, Function.prototype.toString) } : {}),
        setPropertyIsEnumerable: (key, flag) => {
            if (record) unsupported("dynamic class enumerable flags");
            const name = as3String(as3CoerceString(key));
            if (Array.isArray(target) && (name === "length" || arrayIndex(name))) return;
            const found = ownData(target, name);
            if (found) Object.defineProperty(target, name, { ...found, enumerable: Boolean(flag) });
        },
    };
}
function read(target: object, name: string, record: Record | null, namespaces: AS3DynamicPropertyNamespaces, scope?: AS3ScriptPrivateScope): unknown {
    validateClassProperty(record,name);
    if (isAS3ScriptGlobal(target)) { const binding = readAS3ScriptGlobalDeclaration(target, name, "", scope); if (binding) return binding.value; }
    if (Array.isArray(target)) {
        if (namespaces === "public-and-AS3" && name === "push") return arrayPush(target);
        if (remainingArrayMethods.has(name) && (namespaces === "public-and-AS3" || !ownData(target,name))) unsupported("Array method " + name);
    }
    if (record?.function) {
        if (name === "prototype") return getAS3FunctionPrototype(target as Function);
        if (name === "length") return getAS3FunctionLength(target as Function);
        const method = namespaces === "public-and-AS3" ? getAS3FunctionIntrinsic(target as Function, name) : undefined;
        if (method) return method;
    }
    const trait = record?.traits.get(name);
    if (trait) {
        if (trait.kind === "method") return getBoundAS3Method(target, trait.key as string, trait.descriptor!.value);
        if (trait.kind === "accessor") {
            if (!trait.descriptor!.get) return failure("ReferenceError", 1077);
            return trait.descriptor!.get.call(target);
        }
        const stored = ownData(target, trait.key);
        if (!stored) unsupported("declared slot has not been initialized");
        return stored.value;
    }
    if (namespaces === "public-and-AS3" && as3Methods.has(name))
        return getAS3ObjectIntrinsic(target, name, namespaces, operations(target, record));
    if (record ? dynamicSlots.get(target)?.has(name) : ownData(target, name))
        return record ? dynamicSlots.get(target)!.get(name) : ownData(target, name)!.value;
    if (record?.static && name === "prototype") return sourceClassPrototype(record.constructor);
    const delegated = delegateValue(target, name);
    if (delegated) return delegated.value;
    // Every authored Class has its own instance-delegate constructor. Its exact
    // identity remains known even while an unrelated base delegate is unavailable.
    if (name === "constructor" && record && !record.static && !record.function
        && !getRegisteredAS3ClassPrototype(record.constructor)) return record.constructor;
    if (record && !record.dynamic) return failure("ReferenceError", 1069);
    return undefined;
}
export function as3GetProperty(target: unknown, key: unknown,
    namespaces: AS3DynamicPropertyNamespaces = "public-and-AS3", scope?: AS3ScriptPrivateScope): unknown {
    const object = receiver(target); namespace(namespaces); validateAS3ScriptPrivateScope(scope);
    if (isAS3SourceError(object)) return readSourceError(object,propertyName(key),namespaces);
    if (isFlashDictionary(object)) {
        if (key instanceof QName) {
            if (key.uri !== "" && !dictionaryAS3Method(key)) return failure("ReferenceError", 1069);
            namespaces = dictionaryAS3Method(key) ? "public-and-AS3" : "public";
            key = key.localName;
        }
        return object.get(key, namespaces);
    }
    if (Array.isArray(object) && key instanceof QName) { key = arrayPublicName(key); namespaces = "public"; }
    if (isAS3ScriptGlobal(object) && key instanceof QName) {
        if (key.uri === null) return unsupported("wildcard global namespace");
        if (key.uri) return readAS3ScriptGlobalDeclaration(object, key.localName, key.uri)?.value;
        key = key.localName; namespaces = "public"; scope = undefined;
    }
    const record = context(object), name = propertyName(key);
    return read(object, name, record, namespaces, scope);
}
/** Source assignment returns the original RHS, after storing its typed coercion. */
export function as3SetProperty<T>(target: unknown, key: unknown, value: T,
    namespaces: AS3DynamicPropertyNamespaces = "public-and-AS3", scope?: AS3ScriptPrivateScope): T {
    const object = receiver(target); namespace(namespaces); validateAS3ScriptPrivateScope(scope);
    if (isAS3SourceError(object)) {
        const name = propertyName(key);
        if (setSourceErrorField(object,name,value)) return value;
        if (name === "getStackTrace" || name === "constructor") return unsupported("Error method/Class field");
        if (namespaces === "public-and-AS3" && as3Methods.has(name)) return failure("ReferenceError",1037);
        setSourceErrorDynamic(object,name,value);return value;
    }
    if (isFlashDictionary(object)) {
        if (key instanceof QName) {
            if (key.uri !== "" && !dictionaryAS3Method(key)) return failure("ReferenceError", 1056);
            namespaces = dictionaryAS3Method(key) ? "public-and-AS3" : "public";
            key = key.localName;
        }
        object.set(key, value, namespaces); return value;
    }
    if (Array.isArray(object) && key instanceof QName) { key = arrayPublicName(key); namespaces = "public"; }
    if (isAS3ScriptGlobal(object) && key instanceof QName) {
        if (key.uri === null) return unsupported("wildcard global namespace");
        setAS3ScriptGlobalProperty(object, key.localName, value, key.uri); return value;
    }
    const record = context(object), name = propertyName(key), trait = record?.traits.get(name);
    validateClassProperty(record,name);
    if (Array.isArray(object)) {
        if (name === "length") {setArrayLength(object,value);return value;}
        if (namespaces === "public-and-AS3" && name === "push") return failure("ReferenceError",1037);
        if (namespaces === "public-and-AS3" && remainingArrayMethods.has(name)) unsupported("Array method " + name);
    }
    if (record?.function) {
        if (name === "prototype") {setAS3FunctionPrototype(object as Function, value);return value;}
        if (name === "length") return failure("ReferenceError",1074);
        if (namespaces === "public-and-AS3" && (name === "call" || name === "apply")) return failure("ReferenceError",1037);
    }
    if (trait) {
        if (trait.kind === "method") return failure("ReferenceError", 1037);
        if (trait.kind === "constant" || trait.kind === "accessor" && !trait.descriptor!.set) return failure("ReferenceError", 1074);
        const converted = coerceAS3PropertyValue(value, trait.type!);
        if (trait.kind === "accessor") trait.descriptor!.set!.call(object, converted);
        else {
            const stored = ownData(object, trait.key);
            if (!stored || !stored.writable) unsupported("declared writable native slot");
            Object.defineProperty(object, trait.key, { ...stored, value: converted });
        }
        return value;
    }
    // Select the authored namespace trait without reading variable storage.
    // A private/public source declaration precedes inherited AS3 Object methods.
    if (isAS3ScriptGlobal(object) && hasAS3ScriptGlobalDeclaration(object, name, scope)) {
        setAS3ScriptGlobalProperty(object, name, value, "", scope); return value;
    }
    if (namespaces === "public-and-AS3" && as3Methods.has(name)) return failure("ReferenceError", 1037);
    if (isAS3ScriptGlobal(object)) { setAS3ScriptGlobalProperty(object, name, value, "", scope); return value; }
    if (record) {
        if (record.static && name === "prototype") return failure("ReferenceError", 1074);
        if (!record.dynamic) return failure("ReferenceError", 1056);
        let slots = dynamicSlots.get(object);
        if (!slots) dynamicSlots.set(object, slots = new Map());
        slots.set(name, value);
        return value;
    }
    if (Array.isArray(object) || isAS3Prototype(Object.getPrototypeOf(object))) return as3DefineDynamicProperty(object, name, value, namespaces);
    return as3SetDynamicProperty(object, name, value, namespaces);
}
export function as3HasProperty(key: unknown, target: unknown): boolean {
    const object = receiver(target);
    if (isAS3SourceError(object)) {
        const name = propertyName(key);
        if (name === "constructor" || name === "getStackTrace") return unsupported("Error method/Class identity");
        if (sourceErrorOwn(object,name) || ["toString","toLocaleString"].includes(name)) return true;
        for(let parent=sourceErrorParent(object);parent;parent=sourceErrorParent(parent))
            if(sourceErrorDynamic(parent,name))return true;
        return as3HasProperty(name,as3ObjectPrototype);
    }
    if (isFlashDictionary(object)) return key instanceof QName
        ? key.uri === "" && object.hasPrototypeProperty(key.localName) : object.has(key);
    const record = context(object), name = Array.isArray(object) && key instanceof QName ? arrayPublicName(key) : isAS3ScriptGlobal(object) && key instanceof QName ? as3String(key) : propertyName(key);
    // Flash's nonnegative signed-int numeric `in` path checks Array storage,
    // while String/QName and larger numeric keys consult source delegates.
    if (Array.isArray(object) && typeof key === "number" && Number.isInteger(key) && key >= 0 && key <= 2147483647)
        return own(object,name,record);
    if (Array.isArray(object) && remainingArrayMethods.has(name) && !ownData(object,name)) unsupported("Array method " + name);
    return own(object, name, record) || !!delegateValue(object,name)
        || !!record && !record.static && !record.function && name === "constructor" && !getRegisteredAS3ClassPrototype(record.constructor)
        || !!record?.function && name === "length";
}
export function as3HasOwnProperty(target: unknown, key: unknown): boolean {
    if (isFlashDictionary(target)) return as3CallProperty(target, "hasOwnProperty", () => [key]) as boolean;
    if (isAS3SourceError(target)) return sourceErrorOwn(target,as3String(as3CoerceString(key)));
    const object = receiver(target), record = context(object);
    return own(object, as3String(as3CoerceString(key)), record);
}
/**
 * Arguments are a thunk: getproperty precedes argument effects, while the
 * callable check follows them. Do not lower source calls to eager argument arrays.
 */
export function as3CallProperty(target: unknown, key: unknown, arguments_: () => readonly unknown[],
    namespaces: AS3DynamicPropertyNamespaces = "public-and-AS3", scope?: AS3ScriptPrivateScope): unknown {
    const method = as3GetProperty(target, key, namespaces, scope);
    return as3CallValue(method, arguments_, target);
}
export function as3DeleteProperty(target: unknown, key: unknown,
    namespaces: AS3DynamicPropertyNamespaces = "public-and-AS3", scope?: AS3ScriptPrivateScope): boolean {
    const object = receiver(target); namespace(namespaces); validateAS3ScriptPrivateScope(scope);
    if (isAS3SourceError(object)) {
        const name=propertyName(key);
        if(name==="constructor" || name==="getStackTrace")return unsupported("Error method/Class identity");
        if(namespaces==="public-and-AS3" && as3Methods.has(name))return false;
        return deleteSourceErrorDynamic(object,name);
    }
    if (isFlashDictionary(object)) {
        if (key instanceof QName) {
            if (key.uri !== "") return false;
            key = key.localName; namespaces = "public";
        }
        return object.delete(key, namespaces);
    }
    if (Array.isArray(object) && key instanceof QName) { key = arrayPublicName(key); namespaces = "public"; }
    if (isAS3ScriptGlobal(object) && key instanceof QName) {
        if (key.uri !== "") return unsupported("non-public global delete namespace");
        key = key.localName; scope = undefined; namespaces = "public";
    }
    const record = context(object), name = propertyName(key);
    validateClassProperty(record,name);
    if (Array.isArray(object) && namespaces === "public-and-AS3") {
        if (name === "push") return false;
        if (remainingArrayMethods.has(name)) unsupported("Array method " + name);
    }
    if (record && !record.dynamic) return false;
    if (record?.traits.has(name) || (record?.static || record?.function) && name === "prototype" || record?.function && (name === "length" || namespaces === "public-and-AS3" && (name === "call" || name === "apply")) || namespaces === "public-and-AS3" && as3Methods.has(name)) return false;
    if (isAS3ScriptGlobal(object)) return deleteAS3ScriptGlobalProperty(object, name, scope);
    if (record) { dynamicSlots.get(object)?.delete(name); nonEnumerableSlots.get(object)?.delete(name); return true; }
    return Reflect.deleteProperty(object, name);
}

/**
 * Source public conversion lookup for the common String provider. Undefined
 * delegates to its existing host-accessor path only when no source property
 * authority covers that own property/representation. A selected undefined
 * method is explicit and must retain the source noncallable error.
 */
export function resolveAS3SourcePublicConversionMethod(value: unknown, name: "toString" | "valueOf"):
    {readonly method:unknown} | undefined {
    if (value === null || typeof value !== "object" && typeof value !== "function") return undefined;
    if (name !== "toString" && name !== "valueOf") unsupported("conversion property name");
    if (isAS3SourceError(value)) return {method:as3GetProperty(value,name,"public")};
    if (getAS3BuiltinClassName(value) !== undefined) return {method:as3GetProperty(value,name,"public")};
    if (isFlashDictionary(value)) return {method:as3GetProperty(value,name,"public")};
    const prototype = Object.getPrototypeOf(value);
    const record = typeof value === "function" ? constructors.get(value) : instances.get(prototype);
    const sourceOwn = record?.traits.has(name) || dynamicSlots.get(value)?.has(name);
    if (!sourceOwn && Object.getOwnPropertyDescriptor(value,name)) return undefined;
    if (!record) {
        if (typeof value === "function") {
            if (!as3Is(value,Function)) return undefined;
        } else if (prototype !== Object.prototype && !isAS3Prototype(prototype) && !isAS3ScriptGlobal(value)) return undefined;
    }
    return {method:as3GetProperty(value,name,"public")};
}
installAS3SourcePublicConversionResolver(resolveAS3SourcePublicConversionMethod);
// Publish the source delegate before Object.isPrototypeOf observes an Array.
// Its result must not depend on whether an earlier Array property was read.
initializeArrayPrototype([]);

function sourceErrorOwn(target: object,name: string): boolean {
    if(name==="constructor" || name==="getStackTrace")return unsupported("Error method/Class identity");
    return !!sourceErrorField(target,name) || !!sourceErrorDynamic(target,name);
}
function sourceErrorOperations(target: object): AS3ObjectIntrinsicOperations {
    const key=(value:unknown)=>as3String(as3CoerceString(value));
    return {
        hasOwnProperty:value=>sourceErrorOwn(target,key(value)),
        propertyIsEnumerable:value=>sourceErrorEnumerable(target,key(value)),
        setPropertyIsEnumerable:(value,flag)=>setSourceErrorEnumerable(target,key(value),Boolean(flag)),
        isPrototypeOf:value=>{
            if(!isAS3SourceError(value))return false;
            for(let parent=sourceErrorParent(value);parent;parent=sourceErrorParent(parent))if(parent===target)return true;
            return false;
        },
        toString:()=>unsupported("Error toString/stack lowering is not admitted"),
    };
}
function readSourceError(target: object,name: string,namespaces: AS3DynamicPropertyNamespaces): unknown {
    const field=sourceErrorField(target,name);if(field)return field.value;
    if(name==="constructor" || name==="getStackTrace")return unsupported("Error method/Class field");
    const ops=sourceErrorOperations(target);
    getAS3ObjectIntrinsic(target,"valueOf","public",ops);
    if(namespaces==="public-and-AS3" && as3Methods.has(name))return getAS3ObjectIntrinsic(target,name,namespaces,ops);
    for(let current:object|null=target;current;current=sourceErrorParent(current)){
        const dynamic=sourceErrorDynamic(current,name);if(dynamic)return dynamic.value;
    }
    if(name==="toString" || name==="toLocaleString")return unsupported("Error toString/stack lowering is not admitted");
    return as3GetProperty(as3ObjectPrototype,name,"public");
}
