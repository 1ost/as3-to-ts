# Original maintained timing-group reflection

This capture compiles the five unchanged maintained sources, constructs each
class in Adobe Flash 26, and records both Class and instance `describeType`
surfaces. The original files, SWF, commands, capture scripts, tool hashes and
raw result are retained. A second independent acquisition produced identical
rows and reflection. It does not run native timing classes or admit their graph.

PropTween, TweenPlugin and TweenCore have Object as source base. SimpleTimeline
and TweenLite derive from TweenCore. The surfaces retain the inherited members
and Flash order. PropTween is final; protected/private lexical members are not
made public merely because this is a reflection-based capture.

Run from the OP2 root:

```powershell
python as3-to-layaair-porting-kit/tools/verify_timing_metadata.py
```

The verifier authenticates every retained artifact and all five current maintained
source hashes, then writes a fresh ignored projection in the existing native
metadata input shape. Projection is not an admission: inherited reference types,
nonpublic dispatch, source Class bindings and method coercion remain compiler/
provider requirements. The raw reflection remains authoritative if additional
metadata fields are needed; the projection preserves only the current schema.

Variable XML omits `declaredBy` even for inherited fields. The verifier reconciles
ownership against the exact source ancestry using the pinned parser. The 19 public
TweenCore fields remain in each derived reflection surface with TweenCore as owner;
SimpleTimeline owns one public field and TweenLite four. Reflection order is unchanged.
Ten focused tests cover retained evidence, ownership/type/ancestry mismatches, and
source/parser changes. Run `python -m unittest discover -s as3-to-layaair-porting-kit/tests
-p test_timing_metadata.py` from the root.

Own traits remain a validation input. Derived runtime registration must compose the
complete inherited trait surface with authenticated type tokens and overrides; it
cannot pass this own-only list directly to the common property registry. Private/
protected dispatch, typed methods/accessors and cross-source references still need
compiler and shared-provider implementation before timing-module admission.

To reacquire, set OP2_FLASH_PLUGIN to the installed original plugin and invoke
`sources/capture.py` with a fresh output directory. Optional OP2_FLEX_HOME and
OP2_ORACLE_ELECTRON select the recorded toolchain locations. Capture opens a hidden
Flash window, uses a separate profile, and records fresh provenance. No account
or server connection is involved.
