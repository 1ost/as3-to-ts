package {
 import flash.display.Sprite;
 import flash.external.ExternalInterface;
 import flash.utils.describeType;
 import flash.utils.getQualifiedClassName;
 import com.greensock.TweenLite;
 import com.greensock.core.PropTween;
 import com.greensock.core.TweenCore;
 import com.greensock.core.SimpleTimeline;
 import com.greensock.plugins.TweenPlugin;
 public class ConstructorOracle extends Sprite {
  public function ConstructorOracle() {
   var classes:Array=[PropTween,TweenPlugin,TweenCore,SimpleTimeline,TweenLite];
   var values:Array=[new PropTween({},'x',0,1,'x',false),new TweenPlugin(),
    new TweenCore(0,{paused:true}),new SimpleTimeline({paused:true}),
    new TweenLite({x:0},1,{x:1,paused:true,immediateRender:false})];
   var result:Object={rows:[],reflection:[],instances:[]};
   for(var i:int=0;i<classes.length;i++) {
    result.rows.push({id:getQualifiedClassName(values[i]),className:getQualifiedClassName(classes[i]),instanceOfSource:values[i] is classes[i]});
    result.reflection.push(describeType(classes[i]).toXMLString());
    result.instances.push(describeType(values[i]).toXMLString());
   }
   ExternalInterface.addCallback('snapshot',function():String{return encodeURIComponent(JSON.stringify(result));});
  }
 }
}
