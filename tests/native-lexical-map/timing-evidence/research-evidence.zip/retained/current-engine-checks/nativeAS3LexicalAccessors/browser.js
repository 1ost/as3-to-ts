var LexicalProbe = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name2 in all)
      __defProp(target, name2, { get: all[name2], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key3 of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key3) && key3 !== except)
          __defProp(to, key3, { get: () => from[key3], enumerable: !(desc = __getOwnPropDesc(from, key3)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // tests/nativeAS3LexicalAccessors/native.ts
  var native_exports = {};
  __export(native_exports, {
    accessorGuards: () => accessorGuards,
    execute: () => execute,
    executePrivate: () => executePrivate,
    heldOriginalIds: () => heldOriginalIds,
    invariants: () => invariants
  });

  // src/layaAir/flash/utils/FlashSourceReflection.ts
  var tags = /* @__PURE__ */ new Set([
    "type",
    "factory",
    "extendsClass",
    "implementsInterface",
    "constructor",
    "parameter",
    "accessor",
    "method",
    "variable",
    "constant",
    "metadata",
    "arg"
  ]);
  var required = {
    type: ["name", "base", "isDynamic", "isFinal", "isStatic"],
    factory: ["type"],
    extendsClass: ["type"],
    implementsInterface: ["type"],
    constructor: [],
    parameter: ["index", "type", "optional"],
    accessor: ["name", "access", "type", "declaredBy"],
    method: ["name", "declaredBy", "returnType"],
    variable: ["name", "type", "declaredBy"],
    constant: ["name", "type", "declaredBy"],
    metadata: ["name"],
    arg: ["key", "value"]
  };
  function invalid() {
    throw new TypeError("Invalid complete source reflection data");
  }
  function data(object2, key3) {
    const descriptor2 = Object.getOwnPropertyDescriptor(object2, key3);
    if (!descriptor2 || !("value" in descriptor2)) return invalid();
    return descriptor2.value;
  }
  function object(value) {
    if (!value || typeof value !== "object" || Object.getPrototypeOf(value) !== Object.prototype) return invalid();
    return value;
  }
  function copyFlashCompleteReflection(input) {
    const top = object(input);
    if (data(top, "kind") !== "source-complete") return invalid();
    const seen = /* @__PURE__ */ new Set();
    let count = 0;
    function node(input2, depth) {
      const source = object(input2);
      if (seen.has(source) || depth > 32 || ++count > 1e4) return invalid();
      seen.add(source);
      const tag = data(source, "tag"), attributes = object(data(source, "attributes")), children = data(source, "children");
      if (typeof tag !== "string" || !tags.has(tag) || !Array.isArray(children) || Object.getPrototypeOf(children) !== Array.prototype) return invalid();
      const copied = {};
      for (const key3 of Reflect.ownKeys(attributes)) {
        if (typeof key3 !== "string" || !key3.length) return invalid();
        const value = data(attributes, key3);
        if (typeof value !== "string") return invalid();
        Object.defineProperty(copied, key3, { value, enumerable: true });
      }
      const list = [];
      for (let i = 0; i < children.length; i++) list.push(node(data(children, String(i)), depth + 1));
      for (const key3 of required[tag]) if (typeof copied[key3] !== "string") return invalid();
      if (tag === "type" && ["isDynamic", "isFinal", "isStatic"].some((key3) => !["true", "false"].includes(copied[key3]))) return invalid();
      if (tag === "accessor" && !["readonly", "writeonly", "readwrite"].includes(copied.access)) return invalid();
      if (tag === "parameter" && (!/^[1-9][0-9]*$/.test(copied.index) || !["true", "false"].includes(copied.optional))) return invalid();
      const allowed = tag === "type" || tag === "factory" ? ["extendsClass", "implementsInterface", "constructor", "accessor", "method", "variable", "constant", "metadata", ...tag === "type" ? ["factory"] : []] : tag === "method" || tag === "constructor" ? ["parameter", "metadata"] : ["accessor", "variable", "constant"].includes(tag) ? ["metadata"] : tag === "metadata" ? ["arg"] : [];
      if (list.some((child2) => !allowed.includes(child2.tag))) return invalid();
      if (tag === "method" || tag === "constructor") {
        let optional = false, index = 0;
        for (const parameter of list.filter((child2) => child2.tag === "parameter")) {
          if (parameter.attributes.index !== String(++index) || optional && parameter.attributes.optional !== "true") return invalid();
          optional = parameter.attributes.optional === "true";
        }
      }
      if ((tag === "type" || tag === "factory") && list.filter((child2) => child2.tag === "constructor").length > 1) return invalid();
      seen.delete(source);
      return Object.freeze({ tag, attributes: Object.freeze(copied), children: Object.freeze(list) });
    }
    const classDocument = node(data(top, "classDocument"), 0);
    const instanceInput = data(top, "instanceDocument");
    const instanceDocument = instanceInput === null ? null : node(instanceInput, 0);
    const instanceFlagsAuthority = data(top, "instanceFlagsAuthority");
    if (classDocument.tag !== "type" || classDocument.attributes.isStatic !== "true" || classDocument.attributes.base !== "Class" || (instanceDocument ? instanceFlagsAuthority !== "captured-instance" || instanceDocument.tag !== "type" || instanceDocument.attributes.isStatic !== "false" : instanceFlagsAuthority !== "sdk-declaration")) return invalid();
    return Object.freeze({
      kind: "source-complete",
      classDocument,
      instanceDocument,
      instanceFlagsAuthority
    });
  }
  function flashReflectionFactory(source) {
    const factories = source.classDocument.children.filter((child2) => child2.tag === "factory");
    if (factories.length !== 1) return invalid();
    return factories[0];
  }

  // src/layaAir/flash/utils/FlashTypeMetadata.ts
  var constructors = /* @__PURE__ */ new WeakMap();
  var prototypes = /* @__PURE__ */ new WeakMap();
  var legacyReflection = Object.freeze({ kind: "legacy-incomplete" });
  function projectedMembers(node) {
    const lists = { variables: [], accessors: [], methods: [], constants: [] };
    for (const child2 of node.children) {
      const a = child2.attributes;
      const common = { name: a.name, declaredBy: a.declaredBy, ...a.uri === void 0 ? {} : { uri: a.uri } };
      if (child2.tag === "accessor") lists.accessors.push({ ...common, access: a.access });
      if (child2.tag === "variable" || child2.tag === "constant") lists[child2.tag === "variable" ? "variables" : "constants"].push({ ...common, type: a.type });
      if (child2.tag === "method") {
        const parameters = child2.children.filter((item) => item.tag === "parameter");
        parameters.forEach((parameter, index) => {
          if (parameter.attributes.index !== String(index + 1) || !parameter.attributes.type || !["true", "false"].includes(parameter.attributes.optional)) throw new TypeError("Invalid complete method parameters");
        });
        if (!a.returnType) throw new TypeError("Complete method requires return type");
        lists.methods.push({ ...common, parameterCount: parameters.length });
      }
    }
    return members(lists);
  }
  function validateComplete(metadata, source) {
    const factory = flashReflectionFactory(source), instance = source.instanceDocument ?? factory;
    if (source.instanceDocument) {
      const record5 = (node) => JSON.stringify([
        node.tag,
        Object.keys(node.attributes).sort().map((key3) => [key3, node.attributes[key3]]),
        node.children.map(record5)
      ]);
      const ancestry = (node) => node.children.filter((child2) => child2.tag === "extendsClass").map(record5);
      const surface = (node) => node.children.filter((child2) => child2.tag !== "extendsClass").map(record5).sort();
      if (JSON.stringify(ancestry(factory)) !== JSON.stringify(ancestry(instance)) || JSON.stringify(surface(factory)) !== JSON.stringify(surface(instance)))
        throw new TypeError("Complete Class factory and instance reflection differ");
    }
    const classAttributes = source.classDocument.attributes;
    if (classAttributes.name !== metadata.name || factory.attributes.type !== metadata.name || classAttributes.isDynamic !== "true" || classAttributes.isFinal !== "true" || source.instanceDocument && (instance.attributes.name !== metadata.name || instance.attributes.base !== metadata.base || instance.attributes.isDynamic !== String(metadata.isDynamic) || instance.attributes.isFinal !== String(metadata.isFinal)) || instance.children.find((child2) => child2.tag === "extendsClass")?.attributes.type !== metadata.base)
      throw new TypeError("Complete reflection identity differs from declaration projection");
    if (JSON.stringify(projectedMembers(instance)) !== JSON.stringify(metadata.instance) || JSON.stringify(projectedMembers(source.classDocument)) !== JSON.stringify(metadata.statics))
      throw new TypeError("Complete reflection traits differ from declaration projection");
  }
  function name(value) {
    if (typeof value !== "string" || value.length === 0)
      throw new TypeError("Flash reflection metadata requires nonempty names");
    return value;
  }
  function members(input) {
    if (!input || typeof input !== "object")
      throw new TypeError("Flash reflection metadata requires complete member lists");
    const list = (key3, optional = false) => {
      const property = Object.getOwnPropertyDescriptor(input, key3);
      if (optional && (!property || "value" in property && property.value === void 0)) return void 0;
      if (!property || !("value" in property) || !Array.isArray(property.value))
        throw new TypeError("Flash reflection metadata requires complete member lists");
      const source = property.value, copied = [];
      for (let index = 0; index < source.length; index++) {
        const slot = Object.getOwnPropertyDescriptor(source, String(index));
        if (!slot || !("value" in slot) || slot.value === null || typeof slot.value !== "object")
          throw new TypeError("Flash reflection metadata requires dense member records");
        const record5 = {};
        for (const field of ["name", "declaredBy", "uri", "type", "access", "parameterCount"]) {
          const value = Object.getOwnPropertyDescriptor(slot.value, field);
          if (value && !("value" in value))
            throw new TypeError("Flash reflection metadata requires data member records");
          if (value) record5[field] = value.value;
        }
        copied.push(record5);
      }
      return copied;
    };
    const variableRecords = list("variables");
    const accessorRecords = list("accessors");
    const methodRecords = list("methods");
    const constantRecords = list("constants", true);
    const names = /* @__PURE__ */ new Set();
    const common = (member) => {
      const localName = name(member.name);
      if (member.uri !== void 0 && typeof member.uri !== "string")
        throw new TypeError("Invalid Flash reflection namespace URI");
      const key3 = JSON.stringify([member.uri ?? "", localName]);
      if (names.has(key3)) throw new TypeError("Duplicate Flash reflection member: " + key3);
      names.add(key3);
      return {
        name: localName,
        declaredBy: name(member.declaredBy),
        ...member.uri === void 0 ? {} : { uri: member.uri }
      };
    };
    const variables = variableRecords.map((member) => Object.freeze({
      ...common(member),
      type: name(member.type)
    }));
    const constants = constantRecords?.map((member) => Object.freeze({
      ...common(member),
      type: name(member.type)
    }));
    const accessors = accessorRecords.map((member) => {
      if (!["readonly", "writeonly", "readwrite"].includes(member.access))
        throw new TypeError("Invalid Flash reflection accessor access");
      return Object.freeze({ ...common(member), access: member.access });
    });
    const methods = methodRecords.map((member) => {
      if (!Number.isSafeInteger(member.parameterCount) || member.parameterCount < 0)
        throw new TypeError("Invalid Flash reflection parameter count");
      return Object.freeze({ ...common(member), parameterCount: member.parameterCount });
    });
    return Object.freeze({
      variables: Object.freeze(variables),
      accessors: Object.freeze(accessors),
      methods: Object.freeze(methods),
      ...constants === void 0 ? {} : { constants: Object.freeze(constants) }
    });
  }
  function registerFlashTypeMetadata(constructor, input) {
    if (typeof constructor !== "function") throw new TypeError("Invalid Flash reflection constructor");
    const prototypeDescriptor = Object.getOwnPropertyDescriptor(constructor, "prototype");
    const prototype = prototypeDescriptor?.value;
    if (!prototype || typeof prototype !== "object") throw new TypeError("Invalid Flash reflection prototype");
    if (prototypeDescriptor.writable || prototypeDescriptor.configurable)
      throw new TypeError("Flash reflection requires a stable native class prototype");
    if (!input || typeof input !== "object")
      throw new TypeError("Invalid Flash reflection class metadata");
    const field = (key3) => {
      const property = Object.getOwnPropertyDescriptor(input, key3);
      if (!property || !("value" in property))
        throw new TypeError("Flash reflection requires data class metadata");
      return property.value;
    };
    const className = field("name"), base2 = field("base"), isDynamic = field("isDynamic"), isFinal = field("isFinal");
    const instanceInput = field("instance"), staticInput = field("statics");
    if (typeof isDynamic !== "boolean" || typeof isFinal !== "boolean" || base2 !== null && (typeof base2 !== "string" || !base2))
      throw new TypeError("Invalid Flash reflection class metadata");
    const sourceDescriptor = Object.getOwnPropertyDescriptor(input, "sourceReflection");
    if (sourceDescriptor && !("value" in sourceDescriptor)) throw new TypeError("Source reflection must be data");
    const sourceReflection = sourceDescriptor?.value === void 0 ? void 0 : copyFlashCompleteReflection(sourceDescriptor.value);
    const metadata = Object.freeze({
      name: name(className),
      base: base2,
      isDynamic,
      isFinal,
      instance: members(instanceInput),
      statics: members(staticInput),
      ...sourceReflection ? { sourceReflection } : {}
    });
    if (sourceReflection) validateComplete(metadata, sourceReflection);
    if (isCanonicalAS3DeclarationConstructor(constructor)) {
      const declaration2 = getAS3DeclarationType(constructor);
      const base3 = getAS3SourceBase(constructor);
      if (!sourceReflection || metadata.name !== declaration2.name || metadata.base !== (base3?.name ?? "Object"))
        throw new TypeError("Canonical Class requires complete matching source reflection");
    }
    const fingerprint = JSON.stringify(metadata);
    const existing = constructors.get(constructor);
    if (existing) {
      if (existing.fingerprint !== fingerprint || prototypes.get(prototype) !== existing)
        throw new TypeError("Conflicting Flash reflection metadata");
      return;
    }
    if (prototypes.has(prototype)) throw new TypeError("Flash reflection prototype already registered");
    const instance = Object.freeze({
      name: metadata.name,
      base: metadata.base,
      isDynamic: metadata.isDynamic,
      isFinal: metadata.isFinal,
      isStatic: false,
      ...metadata.instance,
      factory: null,
      ...sourceReflection ? { reflectionAuthority: sourceReflection.instanceDocument ? Object.freeze({ kind: "source-complete", document: sourceReflection.instanceDocument }) : Object.freeze({
        kind: "declaration-projection",
        factory: flashReflectionFactory(sourceReflection),
        isDynamic: metadata.isDynamic,
        isFinal: metadata.isFinal,
        flagsAuthority: "sdk-declaration"
      }) } : {}
    });
    const statics = Object.freeze({
      name: metadata.name,
      base: "Class",
      isDynamic: true,
      isFinal: true,
      isStatic: true,
      ...metadata.statics,
      factory: metadata.instance,
      ...sourceReflection ? { reflectionAuthority: Object.freeze({
        kind: "source-complete",
        document: sourceReflection.classDocument
      }) } : {}
    });
    const record5 = { constructor, metadata, instance, statics, fingerprint };
    constructors.set(constructor, record5);
    prototypes.set(prototype, record5);
  }
  function describeRegisteredFlashType(value) {
    if (typeof value === "function") {
      const exact2 = constructors.get(value);
      if (exact2) {
        if (isCanonicalAS3DeclarationConstructor(value)) getAS3ExactSourceClass(value);
        return exact2.statics;
      }
      for (let parent = Object.getPrototypeOf(value); parent !== null; parent = Object.getPrototypeOf(parent)) {
        if (constructors.has(parent))
          throw new TypeError("Derived Flash class requires its own reflection metadata");
      }
      return null;
    }
    if (value === null || typeof value !== "object") return null;
    let prototype = Object.getPrototypeOf(value);
    const exact = prototypes.get(prototype);
    if (exact) {
      if (isCanonicalAS3DeclarationConstructor(exact.constructor) && getAS3ExactSourceClass(value)?.constructor !== exact.constructor)
        throw new TypeError("Canonical reflection requires genuine exact Class identity");
      return exact.instance;
    }
    for (; prototype !== null; prototype = Object.getPrototypeOf(prototype)) {
      if (prototypes.has(prototype))
        throw new TypeError("Derived Flash class requires its own reflection metadata");
    }
    return null;
  }

  // src/layaAir/flash/utils/AS3DeclarationType.ts
  var declarations = /* @__PURE__ */ new WeakMap();
  var constructors2 = /* @__PURE__ */ new WeakMap();
  var prototypes2 = /* @__PURE__ */ new WeakMap();
  var instances = /* @__PURE__ */ new WeakMap();
  var canonicalGenerations = [];
  function invalid2(reason) {
    throw new TypeError("AS3_DECLARATION_UNSUPPORTED: " + reason);
  }
  function declaration(value) {
    const found = value !== null && typeof value === "object" ? declarations.get(value) : void 0;
    if (!found) return invalid2("unauthenticated declaration token");
    return found;
  }
  function isAS3DeclarationType(value) {
    return value !== null && typeof value === "object" && declarations.has(value);
  }
  function declareAS3ReferenceType(name2, base2 = null) {
    if (typeof name2 !== "string" || !name2) return invalid2("nonempty source name required");
    const baseRecord = base2 === null ? null : declaration(base2);
    const type = Object.freeze({ name: name2 });
    const closure = new Set(baseRecord?.closure);
    const record5 = {
      token: type,
      base: baseRecord,
      closure,
      canonical: false,
      interfaces: new Set(baseRecord?.interfaces)
    };
    closure.add(record5);
    declarations.set(type, record5);
    return Object.freeze({ type, publishGeneration: (constructor) => publish(record5, constructor) });
  }
  function publish(record5, constructor) {
    if (typeof constructor !== "function") return invalid2("native constructor required");
    const metadata = describeRegisteredFlashType(constructor);
    if (!metadata?.isStatic || metadata.name !== record5.token.name)
      return invalid2("generation requires matching exact source reflection metadata");
    const descriptor2 = Object.getOwnPropertyDescriptor(constructor, "prototype");
    if (!descriptor2 || descriptor2.writable || descriptor2.configurable || descriptor2.value === null || typeof descriptor2.value !== "object")
      return invalid2("locked native class prototype required");
    const prototype = descriptor2.value;
    const instanceMetadata = describeRegisteredFlashType(Object.create(prototype));
    const previous = constructors2.get(constructor);
    if (previous) {
      if (previous.declaration !== record5 || previous.prototype !== prototype)
        return invalid2("constructor already belongs to another declaration");
      return previous.authority;
    }
    if (prototypes2.has(prototype)) return invalid2("prototype already belongs to another generation");
    const parent = Object.getPrototypeOf(prototype);
    if (record5.base) {
      if (prototypes2.get(parent)?.declaration !== record5.base || instanceMetadata?.base !== record5.base.token.name)
        return invalid2("native base does not match sealed source declaration ancestry");
    } else if (parent !== Object.prototype || instanceMetadata?.base !== "Object") {
      return invalid2("non-Object base requires explicit declaration authority");
    }
    const authority = Object.freeze({ enterInstance(value) {
      if (value === null || typeof value !== "object") return invalid2("native instance required");
      let actual;
      for (let current = Object.getPrototypeOf(value); current !== null; current = Object.getPrototypeOf(current)) {
        const registered = prototypes2.get(current);
        if (registered) {
          actual = registered;
          break;
        }
      }
      if (!actual || !actual.declaration.closure.has(record5))
        return invalid2("constructor entry does not match actual native generation");
      const existing = instances.get(value);
      if (existing && existing !== actual) return invalid2("instance generation cannot be rebound");
      instances.set(value, actual);
    } });
    const generation = {
      declaration: record5,
      constructor,
      prototype,
      authority,
      baseGeneration: record5.base ? prototypes2.get(parent) : null
    };
    constructors2.set(constructor, generation);
    prototypes2.set(prototype, generation);
    return authority;
  }
  function getAS3DeclarationType(constructor) {
    return constructors2.get(constructor)?.declaration.token;
  }
  function isAS3DeclaredInstance(value, type) {
    const target = declaration(type);
    if (value === null || typeof value !== "object") return false;
    const actual = instances.get(value);
    if (actual) return actual.declaration.closure.has(target);
    if (!target.canonical) return false;
    return canonicalGenerations.some((generation) => generation.declaration.closure.has(target) && generation.proof(value));
  }
  function getAS3SourceBase(constructor) {
    const generation = constructors2.get(constructor);
    if (generation?.nativeBase && (Object.getPrototypeOf(generation.prototype) !== generation.nativeBase.prototype || Object.getPrototypeOf(generation.constructor) !== generation.nativeBase))
      return invalid2("canonical native ancestry changed");
    return generation ? generation.declaration.base?.token ?? null : void 0;
  }
  function isAS3DeclaredInterface(value, token) {
    if (value === null || typeof value !== "object") return false;
    const actual = instances.get(value);
    if (actual) return actual.declaration.interfaces.has(token);
    return canonicalGenerations.some((generation) => generation.declaration.interfaces.has(token) && generation.proof(value));
  }
  function getAS3EnteredSourceConstructors(value) {
    if (value === null || typeof value !== "object") return void 0;
    let generation = instances.get(value);
    if (!generation) return void 0;
    const result = [];
    for (; generation; generation = generation.baseGeneration ?? void 0) result.push(generation.constructor);
    return Object.freeze(result);
  }
  function isCanonicalAS3DeclarationConstructor(constructor) {
    return constructors2.get(constructor)?.declaration.canonical ?? false;
  }
  function getAS3PrototypeDeclarationType(prototype) {
    return prototypes2.get(prototype)?.declaration.token;
  }
  function getAS3ExactSourceClass(value) {
    let generation;
    if (typeof value === "function") {
      generation = constructors2.get(value);
      if (!generation) {
        for (let parent = Object.getPrototypeOf(value); parent; parent = Object.getPrototypeOf(parent)) {
          if (constructors2.has(parent)) return invalid2("derived source Class requires its own exact generation");
        }
      }
    } else if (value !== null && typeof value === "object") {
      generation = instances.get(value);
      if (!generation) {
        const candidates = canonicalGenerations.filter((candidate) => candidate.proof(value));
        if (candidates.length) {
          const prototype = Object.getPrototypeOf(value);
          generation = candidates.find((candidate) => candidate.prototype === prototype);
          if (!generation) return invalid2("canonical descendant requires its own exact source Class generation");
          if (candidates.some((candidate) => !generation.declaration.closure.has(candidate.declaration)))
            return invalid2("canonical prototype conflicts with private source Class proof");
        } else {
          for (let prototype = Object.getPrototypeOf(value); prototype; prototype = Object.getPrototypeOf(prototype)) {
            if (prototypes2.has(prototype)) return invalid2("source Class identity requires genuine constructor entry");
          }
        }
      }
    }
    if (!generation) return void 0;
    for (let current = generation; current; current = current.baseGeneration)
      getAS3SourceBase(current.constructor);
    return Object.freeze({
      constructor: generation.constructor,
      name: generation.declaration.token.name,
      baseConstructor: generation.baseGeneration?.constructor ?? null,
      baseName: generation.declaration.base?.token.name ?? "Object"
    });
  }

  // src/layaAir/flash/utils/AS3ArrayCreation.ts
  var creations = /* @__PURE__ */ new WeakMap();
  function unsupported(reason) {
    throw new TypeError("AS3_ARRAY_CREATION_UNSUPPORTED: " + reason);
  }
  function valuesOf(input) {
    if (!Array.isArray(input) || Object.getPrototypeOf(input) !== Array.prototype)
      return unsupported("ordinary compiler value list required");
    const values3 = [];
    for (let index = 0; index < input.length; index++) {
      const slot = Object.getOwnPropertyDescriptor(input, String(index));
      if (!slot || !("value" in slot)) return unsupported("dense compiler data slots required; source elisions must be explicit undefined");
      if (typeof slot.value === "symbol" || typeof slot.value === "bigint") return unsupported("host-only primitive");
      values3.push(slot.value);
    }
    return values3;
  }
  function created(values3, kind) {
    creations.set(values3, Object.freeze({ kind, initialLength: values3.length }));
    return values3;
  }
  function as3CreateArray(arguments_ = []) {
    const values3 = valuesOf(arguments_);
    if (values3.length === 1 && typeof values3[0] === "number") {
      const length = values3[0];
      if (!Number.isInteger(length) || length < 0 || length > 4294967295) {
        const error4 = new RangeError("Error #1005");
        Object.defineProperty(error4, "errorID", { value: 1005 });
        throw error4;
      }
      return created(new Array(length), "length");
    }
    return created(values3, "values");
  }

  // src/layaAir/flash/utils/AS3ConversionMethodResolver.ts
  var resolver;
  function installAS3SourcePublicConversionResolver(value) {
    if (typeof value !== "function" || resolver && resolver !== value)
      throw new TypeError("Conflicting source conversion property authority");
    resolver = value;
  }
  function resolveAS3SourcePublicConversionMethod(value, name2) {
    return resolver?.(value, name2);
  }

  // src/layaAir/flash/utils/AS3Number.ts
  var powersOfTen = [
    1,
    10,
    100,
    1e3,
    1e4,
    1e5,
    1e6,
    1e7,
    1e8,
    1e9,
    1e10,
    1e11,
    1e12,
    1e13,
    1e14,
    1e15,
    1e16,
    1e17,
    1e18,
    1e19,
    1e20,
    1e21,
    1e22
  ];
  var hiddenBit = BigInt(1) << BigInt(52);
  var coercionNaNBits = new DataView(new ArrayBuffer(8));
  coercionNaNBits.setUint32(0, 2147483647, false);
  coercionNaNBits.setUint32(4, 3758096384, false);
  function as3NumberNaN() {
    return coercionNaNBits.getFloat64(0, false);
  }
  function powerOfTen(exponent) {
    if (exponent >= 0 && exponent < 23) return powersOfTen[exponent];
    let base2 = 10, result = 1, power = Math.abs(exponent);
    while (power > 0) {
      if (power % 2 === 1) result = exponent < 0 ? result / base2 : result * base2;
      power = Math.floor(power / 2);
      base2 *= base2;
    }
    return result;
  }
  function split(value) {
    const bytes = new DataView(new ArrayBuffer(8));
    bytes.setFloat64(0, value);
    const bits = bytes.getBigUint64(0);
    const rawExponent = Number(bits >> BigInt(52) & BigInt(2047));
    let mantissa = bits & hiddenBit - BigInt(1);
    let exponent = rawExponent === 0 ? -1074 : rawExponent - 1075;
    if (rawExponent !== 0) mantissa |= hiddenBit;
    else if (mantissa !== BigInt(0)) {
      while (mantissa < hiddenBit) {
        mantissa <<= BigInt(1);
        exponent--;
      }
    }
    return { mantissa, exponent };
  }
  function integerFromDouble(value) {
    if (!Number.isFinite(value)) return BigInt(1024);
    const { mantissa, exponent } = split(value);
    return exponent < 0 ? mantissa >> BigInt(-exponent) : mantissa << BigInt(exponent);
  }
  function integerToDouble(value) {
    if (value === BigInt(0)) return 0;
    const bitLength = value.toString(2).length;
    const wordCount = Math.ceil(bitLength / 32);
    const word = (index) => value >> BigInt(index * 32) & BigInt(4294967295);
    if (wordCount === 1) return Number(value);
    let nextWord = wordCount - 1, position = 53, bits = bitLength - nextWord * 32;
    let shift = 0, mantissa = BigInt(0), current = BigInt(0);
    while (position > 0) {
      current = word(nextWord--);
      mantissa |= current >> BigInt(shift);
      position -= bits;
      if (position > 0) {
        if (nextWord < 0) break;
        bits = position > 31 ? 32 : position;
        shift = position > 31 ? 0 : 32 - bits;
        mantissa <<= BigInt(bits);
      }
    }
    let roundBit = false, rest = false;
    if (position <= 0) {
      if (bits === 32) {
        if (nextWord >= 0) {
          current = word(nextWord--);
          roundBit = (current & BigInt(2147483648)) !== BigInt(0);
          rest = (current & BigInt(2147483647)) !== BigInt(0);
        }
      } else {
        roundBit = (current & BigInt(1) << BigInt(shift - 1)) !== BigInt(0);
        if (shift > 1) rest = (current & (BigInt(1) << BigInt(shift - 1)) - BigInt(1)) !== BigInt(0);
        if (nextWord >= 0) rest ||= word(nextWord--) !== BigInt(0);
      }
    }
    if (roundBit && ((mantissa & BigInt(1)) !== BigInt(0) || rest)) mantissa++;
    const exponent = bitLength - 53;
    return Number(mantissa) * (exponent > 0 ? 2 ** exponent : 1);
  }
  var DecimalDigits = class {
    constructor(value) {
      this.finished = false;
      const { mantissa, exponent } = split(value);
      this.inclusive = (mantissa & BigInt(1)) === BigInt(0);
      if (exponent >= 0) {
        const scale2 = BigInt(1) << BigInt(exponent);
        if (mantissa !== hiddenBit) {
          this.r = integerFromDouble(value) * BigInt(2);
          this.s = BigInt(2);
          this.plus = this.minus = scale2;
        } else {
          this.r = integerFromDouble(value * 4);
          this.s = BigInt(4);
          this.plus = scale2 * BigInt(2);
          this.minus = scale2;
        }
      } else if (mantissa !== hiddenBit) {
        this.r = mantissa * BigInt(2);
        this.s = BigInt(2) << BigInt(-exponent);
        this.plus = this.minus = BigInt(1);
      } else {
        this.r = mantissa * BigInt(4);
        this.s = BigInt(2) << BigInt(1 - exponent);
        this.plus = BigInt(2);
        this.minus = BigInt(1);
      }
      const estimate = Math.ceil((exponent + 52) * 0.3010299956639812 - 1e-10);
      const scale = BigInt(10) ** BigInt(Math.abs(estimate));
      if (estimate >= 0) this.s *= scale;
      else {
        this.r *= scale;
        this.plus *= scale;
        this.minus *= scale;
      }
      if (this.inclusive ? this.r + this.plus >= this.s : this.r + this.plus > this.s)
        this.exponent = estimate + 1;
      else {
        this.r *= BigInt(10);
        this.plus *= BigInt(10);
        this.minus *= BigInt(10);
        this.exponent = estimate;
      }
    }
    next() {
      if (this.finished) return -1;
      let digit2 = Number(this.r / this.s);
      this.r %= this.s;
      const low = this.inclusive ? this.r <= this.minus : this.r < this.minus;
      const high = this.inclusive ? this.r + this.plus >= this.s : this.r + this.plus > this.s;
      if (digit2 < 0 || digit2 > 9) digit2 = 0;
      if (!low && !high) {
        this.r *= BigInt(10);
        this.plus *= BigInt(10);
        this.minus *= BigInt(10);
      } else {
        if (!low || high && this.r * BigInt(2) >= this.s) digit2++;
        this.finished = true;
      }
      return digit2;
    }
  };
  function as3NumberToString(value) {
    if (typeof value !== "number") throw new TypeError("AS3 numeric formatting requires a number");
    if (Number.isNaN(value)) return "NaN";
    if (value === Infinity) return "Infinity";
    if (value === -Infinity) return "-Infinity";
    if (value === 0) return "0";
    if (Number.isInteger(value) && value > -2147483648 && value <= 2147483647) {
      let integer = Math.abs(value), text2 = "";
      while (integer > 0) {
        const quotient = Math.floor(integer / 10);
        text2 = String.fromCharCode(48 + integer - quotient * 10) + text2;
        integer = quotient;
      }
      return (value < 0 ? "-" : "") + text2;
    }
    const negative = value < 0;
    const digits = new DecimalDigits(Math.abs(value));
    let exponent = digits.exponent - 1, output = "";
    if (exponent < 0 && exponent > -7) {
      output = "00." + "0".repeat(-exponent - 1);
      while (!digits.finished) output += String.fromCharCode(48 + digits.next());
      exponent = 0;
    } else if (exponent > 20) {
      output += String.fromCharCode(48 + digits.next());
      if (!digits.finished) {
        output += ".";
        for (let index = 0; index < 14 && !digits.finished; index++) output += String.fromCharCode(48 + digits.next());
      }
    } else {
      output = "0";
      const first = digits.next();
      if (first > 0) output += String.fromCharCode(48 + first);
      while (exponent > 0) {
        output += String.fromCharCode(48 + (digits.finished ? 0 : digits.next()));
        exponent--;
      }
      if (!digits.finished) {
        output += ".";
        while (!digits.finished) output += String.fromCharCode(48 + digits.next());
      }
    }
    if (exponent !== 0) {
      let first = 0;
      while (first < output.length && output[first] === "0") first++;
      if (first === output.length) {
        output += "1";
        exponent++;
      } else {
        let last = output.length - 1;
        while (last > first && output[last] === "0") last--;
        if (first === last) {
          exponent += output.length - first - 1;
          output = output.slice(0, last + 1);
        }
      }
      output += "e" + (exponent > 0 ? "+" : "") + exponent;
    }
    if (output[0] === "0" && output[1] !== ".") output = output.slice(1);
    return (negative ? "-" : "") + output;
  }
  function isSpace(code) {
    return code === 32 || code >= 9 && code <= 13 || code >= 8192 && code <= 8203 || code === 8232 || code === 8233 || code === 8287 || code === 12288;
  }
  function skipSpace(text2, index) {
    while (index < text2.length && isSpace(text2.charCodeAt(index))) index++;
    return index;
  }
  function digit(code) {
    return code >= 48 && code <= 57;
  }
  function decimal(text2) {
    let index = skipSpace(text2, 0), negative = false, count = 0, exponent = 0, code = 0;
    if (index >= text2.length) return 0;
    if (text2[index] === "+" || text2[index] === "-") negative = text2[index++] === "-";
    const start = index;
    let length = text2.length;
    while (index < length) {
      code = text2.charCodeAt(index);
      if (digit(code)) {
        count++;
        index++;
      } else {
        if (code === 0) length = index;
        break;
      }
    }
    if (code === 46) {
      while (++index < length) {
        code = text2.charCodeAt(index);
        if (digit(code)) count++;
        else {
          if (code === 0) length = index;
          break;
        }
      }
    }
    if (index < length && (text2[index] === "e" || text2[index] === "E")) {
      let amount = 0, negativeExponent = false;
      index++;
      if (text2[index] === "+" || text2[index] === "-") negativeExponent = text2[index++] === "-";
      if (negativeExponent && index >= length) return null;
      while (index < length) {
        code = text2.charCodeAt(index);
        if (digit(code)) {
          amount = amount * 10 + code - 48 | 0;
          index++;
        } else {
          if (code === 0) length = index;
          break;
        }
      }
      exponent = negativeExponent ? -amount | 0 : amount;
    }
    index = skipSpace(text2, index);
    if (count === 0) {
      if (text2.slice(index, index + 8) !== "Infinity") return null;
      index += 8;
      if (index < length && skipSpace(text2, index) === index) return null;
      return negative ? -Infinity : Infinity;
    }
    if (index < length) return null;
    const limit = index;
    index = start;
    let fraction = -1, exact = BigInt(0), result = 0;
    while (index < limit) {
      code = text2.charCodeAt(index);
      if (!digit(code) && code !== 46) break;
      if (fraction !== -1) fraction++;
      if (code === 46) fraction = 0;
      else if (count > 15) exact = exact * BigInt(10) + BigInt(code - 48);
      else result = result * 10 + code - 48;
      index++;
    }
    if (fraction > 0) exponent = exponent - fraction | 0;
    if (count > 15) {
      if (exponent > 0) {
        const factor = integerFromDouble(powerOfTen(exponent));
        const words = (integer) => Math.ceil(integer.toString(2).length / 32);
        if (words(exact) + words(factor) > 130) return null;
        exact *= factor;
        exponent = 0;
      }
      result = integerToDouble(exact);
    } else if (exponent >= 0) result *= powerOfTen(exponent);
    if (exponent < 0) {
      if (exponent < -307) {
        const difference = exponent + 307;
        result /= powerOfTen(-difference);
        exponent -= difference;
      }
      result /= powerOfTen(-exponent);
    }
    return negative ? -result : result;
  }
  function integerDigit(code) {
    return digit(code) ? code - 48 : code >= 65 && code <= 90 ? code - 55 : code >= 97 && code <= 122 ? code - 87 : -1;
  }
  function roundedHexInteger(text2, start) {
    let end = start;
    while (end < text2.length && text2[end] === "0") end++;
    if (end >= text2.length) return 0;
    let next = 0, value = 0, result = 0;
    for (; next * 4 <= 52; next++) {
      value = integerDigit(text2.charCodeAt(end++));
      if (value < 0 || value >= 16) {
        value = 0;
        break;
      }
      result = result * 16 + value;
      if (end >= text2.length) break;
    }
    if (next * 4 > 52) {
      const bit53 = (value & 1) !== 0;
      let bit54 = false, roundUp = false, factor = 1;
      value = integerDigit(text2.charCodeAt(end));
      if (value >= 0 && value < 16) {
        factor *= 16;
        bit54 = (value & 8) !== 0;
        roundUp = (value & 3) !== 0;
      } else roundUp = bit53;
      while (++end < text2.length) {
        value = integerDigit(text2.charCodeAt(end));
        if (value < 0 || value >= 16) break;
        roundUp ||= value !== 0;
        factor *= 16;
      }
      result += bit54 && (bit53 || roundUp) ? 1 : 0;
      result *= factor;
    }
    return result;
  }
  function integerFallback(text2) {
    let index = skipSpace(text2, 0), negative = false;
    if (text2[index] === "+" || text2[index] === "-") negative = text2[index++] === "-";
    let radix = 10;
    if (text2[index] === "0" && (text2[index + 1] === "x" || text2[index + 1] === "X")) {
      radix = 16;
      index += 2;
    }
    const start = index;
    let count = 0, result = 0;
    while (index < text2.length) {
      const number = integerDigit(text2.charCodeAt(index));
      if (number < 0 || number >= radix) break;
      result = result * radix + number;
      count++;
      index++;
    }
    if (count === 0 || skipSpace(text2, index) < text2.length) return as3NumberNaN();
    if (radix === 16 && result >= 9007199254740992) result = roundedHexInteger(text2, start);
    return negative ? -result : result;
  }
  function as3NumberFromString(text2) {
    if (typeof text2 !== "string") throw new TypeError("AS3 numeric parsing requires a string");
    const value = decimal(text2);
    return value === null ? integerFallback(text2) : value;
  }

  // src/layaAir/flash/utils/AS3String.ts
  var objectToString = Object.prototype.toString;
  var functionToString = Function.prototype.toString;
  var numberToString = Number.prototype.toString;
  var stringToString = String.prototype.toString;
  var booleanToString = Boolean.prototype.toString;
  var arrayToString = Array.prototype.toString;
  var arrayJoin = Array.prototype.join;
  var intrinsicToStrings = [
    objectToString,
    functionToString,
    numberToString,
    stringToString,
    booleanToString,
    arrayToString
  ];
  var builtinClasses = /* @__PURE__ */ new Map([
    [Object, "Object"],
    [Function, "Function"],
    [Number, "Number"],
    [Array, "Array"]
  ]);
  var convertingArrays = /* @__PURE__ */ new Set();
  function typeError(errorID) {
    const error4 = new TypeError("Error #" + errorID);
    Object.defineProperty(error4, "errorID", { value: errorID });
    throw error4;
  }
  function unsupported2(message) {
    throw new TypeError("AS3_STRING_UNSUPPORTED: " + message);
  }
  function primitive(value) {
    return value !== null && typeof value !== "object" && typeof value !== "function";
  }
  function scalar(value) {
    switch (typeof value) {
      case "undefined":
        return "undefined";
      case "string":
        return value;
      case "boolean":
        return value ? "true" : "false";
      case "number":
        return as3NumberToString(value);
      default:
        return unsupported2("value has no source scalar representation");
    }
  }
  function registeredLabel(value) {
    const metadata = describeRegisteredFlashType(value);
    if (!metadata) return null;
    const local = metadata.name.split(/::|\./).pop();
    return "[" + (metadata.isStatic ? "class " : "object ") + local + "]";
  }
  function defaultFunctionString(value) {
    const builtin = builtinClasses.get(value);
    if (builtin) return "[class " + builtin + "]";
    const label = registeredLabel(value);
    if (label !== null) return label;
    const prototype = Object.getOwnPropertyDescriptor(value, "prototype");
    if (prototype && !prototype.writable)
      return unsupported2("native class requires exact source metadata");
    return "function Function() {}";
  }
  function defaultObjectString(value) {
    const label = registeredLabel(value);
    if (label !== null) return label;
    if (Object.getPrototypeOf(value) === Object.prototype) return "[object Object]";
    return unsupported2("object prototype requires exact source metadata");
  }
  function defaultArrayString(value) {
    if (value.join !== arrayJoin) return unsupported2("custom Array.join requires source method binding");
    if (convertingArrays.has(value)) return unsupported2("cyclic Array conversion has no captured authority");
    convertingArrays.add(value);
    try {
      const parts = [];
      const length = value.length;
      for (let index = 0; index < length; index++) {
        const item = value[index];
        parts.push(item == null ? "" : as3String(item));
      }
      return parts.join(",");
    } finally {
      convertingArrays.delete(value);
    }
  }
  function as3InvokeToString(value) {
    if (value === null) return typeError(1009);
    if (value === void 0) return typeError(1010);
    if (typeof value === "symbol" || typeof value === "bigint")
      return unsupported2("host-only primitive");
    const resolved = resolveAS3SourcePublicConversionMethod(value, "toString");
    const method2 = resolved ? resolved.method : getAS3BuiltinClassName(value) !== void 0 ? functionToString : value.toString;
    return as3InvokeToStringMethod(value, method2);
  }
  function as3InvokeToStringMethod(value, method2) {
    if (value === null) return typeError(1009);
    if (value === void 0) return typeError(1010);
    if (typeof value === "symbol" || typeof value === "bigint")
      return unsupported2("host-only primitive");
    if (as3AsClass(method2) !== null) return as3CallClass(method2, []);
    if (typeof method2 !== "function") return typeError(1006);
    if (method2 === numberToString && typeof value === "number") return as3NumberToString(value);
    if (method2 === stringToString && typeof value === "string") return value;
    if (method2 === booleanToString && typeof value === "boolean") return value ? "true" : "false";
    if (method2 === functionToString) {
      const builtin = getAS3BuiltinClassName(value);
      if (builtin !== void 0) return "[class " + builtin + "]";
      if (typeof value === "function") return defaultFunctionString(value);
    }
    if (method2 === objectToString && typeof value === "object") return defaultObjectString(value);
    if (method2 === arrayToString && Array.isArray(value)) return defaultArrayString(value);
    if (intrinsicToStrings.includes(method2))
      return unsupported2("borrowed intrinsic toString requires source receiver evidence");
    return Reflect.apply(method2, value, []);
  }
  function as3InvokeValueOfMethod(value, method2) {
    if (as3AsClass(method2) !== null) return as3CallClass(method2, []);
    if (typeof method2 !== "function") return typeError(1006);
    return Reflect.apply(method2, value, []);
  }
  function as3String(value) {
    if (value === null) return "null";
    if (primitive(value)) return scalar(value);
    const first = as3InvokeToString(value);
    if (primitive(first)) return scalar(first);
    const resolved = resolveAS3SourcePublicConversionMethod(value, "valueOf");
    const method2 = resolved ? resolved.method : getAS3BuiltinClassName(value) !== void 0 ? Object.prototype.valueOf : value.valueOf;
    const second = as3InvokeValueOfMethod(value, method2);
    if (primitive(second)) return scalar(second);
    return typeError(1050);
  }
  function as3CoerceString(value) {
    return value == null ? null : as3String(value);
  }

  // src/layaAir/flash/utils/AS3Coercion.ts
  var objectValueOf = Object.prototype.valueOf;
  var objectToString2 = Object.prototype.toString;
  var functionToString2 = Function.prototype.toString;
  var builtinClasses2 = [Object, Function, Number, Array];
  function unsupported3(reason) {
    throw new TypeError("AS3_COERCION_UNSUPPORTED: " + reason);
  }
  function typeError2(errorID) {
    const error4 = new TypeError("Error #" + errorID);
    Object.defineProperty(error4, "errorID", { value: errorID });
    throw error4;
  }
  function scalar2(value) {
    if (value === null) return 0;
    switch (typeof value) {
      case "undefined":
        return as3NumberNaN();
      case "number":
        return value;
      case "boolean":
        return value ? 1 : 0;
      case "string":
        return as3NumberFromString(value);
      default:
        return unsupported3("host-only primitive");
    }
  }
  function primitive2(value) {
    return value !== null && typeof value !== "object" && typeof value !== "function";
  }
  function method(value, name2) {
    const resolved = resolveAS3SourcePublicConversionMethod(value, name2);
    if (resolved) return resolved.method;
    if (getAS3BuiltinClassName(value) !== void 0)
      return name2 === "valueOf" ? objectValueOf : functionToString2;
    const metadata = describeRegisteredFlashType(value);
    if (metadata) {
      const member = [...metadata.variables, ...metadata.accessors, ...metadata.methods].find((member2) => member2.name === name2 && !member2.uri);
      if (member && member.declaredBy !== "Object") {
        if ("access" in member && member.access === "writeonly") {
          const error4 = new ReferenceError("Error #1077");
          Object.defineProperty(error4, "errorID", { value: 1077 });
          throw error4;
        }
        return Reflect.get(value, name2);
      }
      if (metadata.isDynamic && Object.prototype.hasOwnProperty.call(value, name2))
        return unsupported3("dynamic class conversion slot lacks public/private authority");
      return name2 === "valueOf" ? objectValueOf : metadata.isStatic ? functionToString2 : objectToString2;
    }
    const prototype = Object.getPrototypeOf(value);
    if (typeof value === "function") {
      const descriptor2 = Object.getOwnPropertyDescriptor(value, "prototype");
      if (descriptor2 && !descriptor2.writable && !builtinClasses2.includes(value))
        return unsupported3("native class conversion needs exact source metadata");
      if (prototype !== Function.prototype)
        return unsupported3("function prototype needs source binding");
    } else if (prototype !== Object.prototype && !(Array.isArray(value) && prototype === Array.prototype)) {
      return unsupported3("object conversion needs exact source metadata");
    }
    return Reflect.get(value, name2);
  }
  function as3CoerceNumber(value) {
    return scalar2(as3DefaultPrimitive(value, "number"));
  }
  function as3DefaultPrimitive(value, hint) {
    if (value === null || primitive2(value)) return sourcePrimitive(value);
    const reference = value;
    const firstName = hint === "number" ? "valueOf" : "toString";
    const secondName = hint === "number" ? "toString" : "valueOf";
    const firstMethod = method(reference, firstName);
    const first = firstName === "valueOf" ? as3InvokeValueOfMethod(reference, firstMethod) : as3InvokeToStringMethod(reference, firstMethod);
    if (primitive2(first)) return sourcePrimitive(first);
    const secondMethod = method(reference, secondName);
    const second = secondName === "valueOf" ? as3InvokeValueOfMethod(reference, secondMethod) : as3InvokeToStringMethod(reference, secondMethod);
    if (primitive2(second)) return sourcePrimitive(second);
    return typeError2(1050);
  }
  function sourcePrimitive(value) {
    if (value === null) return null;
    if (value === void 0) return void 0;
    if (typeof value === "number" || typeof value === "string" || typeof value === "boolean") return value;
    return unsupported3("host-only primitive");
  }
  function as3CoerceInt(value) {
    return as3CoerceNumber(value) | 0;
  }
  function as3CoerceUint(value) {
    return as3CoerceNumber(value) >>> 0;
  }
  function as3CoerceObject(value) {
    if (typeof value === "symbol" || typeof value === "bigint")
      return unsupported3("host-only primitive");
    return value === void 0 ? null : value;
  }

  // src/layaAir/flash/errors/AS3SourceError.ts
  var values = /* @__PURE__ */ new WeakMap();
  var prototypes3 = /* @__PURE__ */ new Map();
  var NativeError = Error;
  var NativeTypeError = TypeError;
  var NativeReferenceError = ReferenceError;
  var fields = /* @__PURE__ */ new Set(["name", "message", "errorID"]);
  function unsupported4(reason) {
    throw new NativeTypeError("AS3_ERROR_UNSUPPORTED: " + reason);
  }
  function record(value) {
    const found = values.get(value);
    if (!found) return unsupported4("unissued instance");
    for (const name2 of found.fixed ? fields : []) {
      const descriptor2 = Object.getOwnPropertyDescriptor(value, name2);
      if (!descriptor2 || !("value" in descriptor2) || descriptor2.configurable || descriptor2.enumerable || descriptor2.writable !== (name2 !== "errorID") || name2 === "errorID" && descriptor2.value !== found.id)
        return unsupported4("native field descriptor changed");
    }
    return found;
  }
  function issue(kind, message, id, name2, parent) {
    const value = kind === "TypeError" ? new NativeTypeError() : kind === "ReferenceError" ? new NativeReferenceError() : new NativeError();
    Object.defineProperties(value, {
      name: { value: name2, writable: true, configurable: false, enumerable: false },
      message: { value: message, writable: true, configurable: false, enumerable: false },
      errorID: { value: id, writable: false, configurable: false, enumerable: false }
    });
    values.set(value, { value, fixed: true, id, parent, slots: /* @__PURE__ */ new Map(), hidden: /* @__PURE__ */ new Set() });
    return value;
  }
  function getAS3SourceErrorPrototype(kind = "Error") {
    if (kind !== "Error" && kind !== "TypeError" && kind !== "ReferenceError" && kind !== "ArgumentError")
      return unsupported4("prototype kind");
    let value = prototypes3.get(kind);
    if (!value) {
      if (kind === "Error") value = issue(kind, "Error", 0, kind, null);
      else {
        const parent = getAS3SourceErrorPrototype();
        value = /* @__PURE__ */ Object.create(null);
        values.set(value, { value, fixed: false, id: 0, parent, slots: /* @__PURE__ */ new Map([["name", kind]]), hidden: /* @__PURE__ */ new Set() });
      }
      prototypes3.set(kind, value);
    }
    return value;
  }
  function construct(kind, message, id) {
    const number = as3CoerceInt(id), prototype = getAS3SourceErrorPrototype(kind);
    const field = sourceErrorField(prototype, "name");
    const name2 = field ? field.value : sourceErrorDynamic(prototype, "name")?.value;
    return issue(kind, message, number, name2, prototype);
  }
  function createAS3ArrayCoercionError() {
    return construct("TypeError", "Error #1034", 1034);
  }
  function createAS3ErrorReadonlyFailure() {
    return construct("ReferenceError", "Error #1074", 1074);
  }
  function isAS3SourceError(value) {
    return value !== null && typeof value === "object" && values.has(value);
  }
  function sourceErrorField(value, name2) {
    const r = record(value);
    return r.fixed && fields.has(name2) ? { value: Object.getOwnPropertyDescriptor(r.value, name2).value } : void 0;
  }
  function setSourceErrorField(value, name2, input) {
    const r = record(value);
    if (!r.fixed || !fields.has(name2)) return false;
    if (name2 === "errorID") throw createAS3ErrorReadonlyFailure();
    Object.defineProperty(r.value, name2, { value: input });
    return true;
  }
  function sourceErrorDynamic(value, name2) {
    const r = record(value);
    return r.slots.has(name2) ? { value: r.slots.get(name2) } : void 0;
  }
  function setSourceErrorDynamic(value, name2, input) {
    record(value).slots.set(name2, input);
  }
  function deleteSourceErrorDynamic(value, name2) {
    const r = record(value);
    if (r.fixed && fields.has(name2)) return false;
    r.slots.delete(name2);
    r.hidden.delete(name2);
    return true;
  }
  function sourceErrorParent(value) {
    return record(value).parent;
  }
  function sourceErrorEnumerable(value, name2) {
    const r = record(value);
    return r.slots.has(name2) && !r.hidden.has(name2);
  }
  function setSourceErrorEnumerable(value, name2, flag) {
    const r = record(value);
    if (r.slots.has(name2)) {
      if (flag) r.hidden.delete(name2);
      else r.hidden.add(name2);
    }
  }

  // src/layaAir/flash/utils/AS3Type.ts
  var sourceArrayConstructor = Array;
  var interfaces = /* @__PURE__ */ new WeakMap();
  var classes = /* @__PURE__ */ new WeakMap();
  var prototypes4 = /* @__PURE__ */ new WeakMap();
  var canonicalInterfaceClasses = [];
  function isAS3Interface(value) {
    return value !== null && typeof value === "object" && interfaces.has(value);
  }
  var AS3Int = Object.freeze({ name: "int" });
  var AS3Uint = Object.freeze({ name: "uint" });
  var nativeBuiltinClasses = /* @__PURE__ */ new Set([Object, Array, Number, String, Boolean, Function]);
  function isSourceFunction(value) {
    if (typeof value !== "function") return false;
    if (nativeBuiltinClasses.has(value) || describeRegisteredFlashType(value)?.isStatic) return false;
    const prototype = Object.getOwnPropertyDescriptor(value, "prototype");
    if (prototype && !prototype.writable)
      throw new TypeError("AS3_FUNCTION_UNSUPPORTED: native class lacks exact source metadata");
    return true;
  }
  function as3Is(value, target) {
    if (isAS3DeclarationType(target)) return isAS3DeclaredInstance(value, target);
    if (typeof target === "function") {
      const declaration2 = getAS3DeclarationType(target);
      if (declaration2) return isAS3DeclaredInstance(value, declaration2);
    }
    if (target === AS3Int || target === AS3Uint) {
      return typeof value === "number" && Number.isInteger(value) && (target === AS3Int ? value >= -2147483648 && value <= 2147483647 : value >= 0 && value <= 4294967295);
    }
    if (isAS3Interface(target)) {
      if (value === null || typeof value !== "object" && typeof value !== "function") return false;
      const entered2 = getAS3EnteredSourceConstructors(value);
      if (entered2) {
        if (isAS3DeclaredInterface(value, target)) return true;
        return entered2.some((constructor2) => !isCanonicalAS3DeclarationConstructor(constructor2) && classes.get(constructor2)?.interfaces.has(target));
      }
      if (isAS3DeclaredInterface(value, target)) return true;
      for (const record5 of canonicalInterfaceClasses) {
        if (record5.interfaceProof.interfaces.has(target) && record5.interfaceProof.proof(value)) return true;
      }
      for (let prototype = Object.getPrototypeOf(value); prototype !== null; prototype = Object.getPrototypeOf(prototype)) {
        if (getAS3PrototypeDeclarationType(prototype)) return false;
        const record5 = prototypes4.get(prototype);
        if (!record5) continue;
        if (record5.interfaceProof) return false;
        if (record5.interfaces.has(target)) return true;
      }
      return false;
    }
    if (typeof target !== "function") throw new TypeError("Invalid AS3 type operand");
    const constructor = target;
    if (value === null || value === void 0) return false;
    if (constructor === Object) return typeof value !== "symbol" && typeof value !== "bigint";
    if (constructor === Number) return typeof value === "number";
    if (constructor === String) return typeof value === "string";
    if (constructor === Boolean) return typeof value === "boolean";
    if (constructor === Function) return isSourceFunction(value);
    return value instanceof target;
  }
  function as3CoerceReference(value, target) {
    const operand = target;
    if (operand === Number || operand === String || operand === Boolean || operand === AS3Int || operand === AS3Uint || !isAS3Interface(target) && !isAS3DeclarationType(target) && typeof target !== "function") {
      throw new TypeError("Invalid AS3 reference coercion type operand");
    }
    if (value === null || value === void 0) return null;
    if (as3Is(value, target)) return value;
    if (operand === sourceArrayConstructor) throw createAS3ArrayCoercionError();
    const declared = isAS3DeclarationType(target) || typeof target === "function" && getAS3DeclarationType(target);
    const error4 = new TypeError(declared ? "Error #1034" : "Error #1034: Type Coercion failed.");
    Object.defineProperty(error4, "errorID", { value: 1034 });
    throw error4;
  }
  function as3CheckArgumentCount(actual, minimum, maximum = Infinity) {
    if (!Number.isInteger(actual) || actual < 0 || !Number.isInteger(minimum) || minimum < 0 || maximum !== Infinity && (!Number.isInteger(maximum) || maximum < minimum))
      throw new TypeError("Invalid AS3 argument count check");
    if (actual >= minimum && actual <= maximum) return;
    const error4 = new Error("Error #1063: Argument count mismatch.");
    error4.name = "ArgumentError";
    Object.defineProperty(error4, "errorID", { value: 1063 });
    throw error4;
  }

  // src/layaAir/flash/utils/AS3DynamicObject.ts
  var ordinaryObjects = /* @__PURE__ */ new WeakSet();
  var ordinaryPrototype = Object.prototype;
  function as3CreateDynamicObject() {
    const value = {};
    ordinaryObjects.add(value);
    return value;
  }
  function as3SetDynamicProperty(target, key3, value, namespaces = "public") {
    if (!ordinaryObjects.has(target) || Object.getPrototypeOf(target) !== ordinaryPrototype) {
      throw new TypeError("AS3 dynamic write requires an unchanged factory-created ordinary Object");
    }
    return as3DefineDynamicProperty(target, key3, value, namespaces);
  }
  function as3DefineDynamicProperty(target, key3, value, namespaces = "public") {
    if (typeof key3 !== "string") {
      throw new TypeError("AS3 dynamic write requires an already-coerced String key");
    }
    if (namespaces !== "public" && namespaces !== "public-and-AS3") {
      throw new TypeError("AS3 ordinary Object write requires an explicit supported namespace mode");
    }
    if (namespaces === "public-and-AS3" && (key3 === "hasOwnProperty" || key3 === "propertyIsEnumerable" || key3 === "isPrototypeOf")) {
      const error4 = new ReferenceError("Error #1037");
      Object.defineProperty(error4, "errorID", { value: 1037 });
      throw error4;
    }
    const existing = Object.getOwnPropertyDescriptor(target, key3);
    if (existing && (!("value" in existing) || !existing.writable || !existing.configurable)) {
      throw new TypeError("AS3 dynamic write does not support host-defined accessors or restricted properties");
    }
    Object.defineProperty(target, key3, {
      value,
      writable: true,
      enumerable: existing ? existing.enumerable : true,
      configurable: true
    });
    return value;
  }

  // src/layaAir/flash/utils/AS3Class.ts
  var AS3ClassType = Object.freeze({ name: "Class" });
  var builtinClasses3 = /* @__PURE__ */ new Set([
    Object,
    Array,
    Number,
    String,
    Boolean,
    Function,
    AS3Int,
    AS3Uint,
    AS3ClassType
  ]);
  function getAS3BuiltinClassName(value) {
    if (value === AS3ClassType) return "Class";
    if (value === AS3Int) return "int";
    if (value === AS3Uint) return "uint";
    if (value === Object) return "Object";
    if (value === Function) return "Function";
    if (value === Number) return "Number";
    if (value === String) return "String";
    if (value === Boolean) return "Boolean";
    if (value === Array) return "Array";
    return void 0;
  }
  var constructors3 = /* @__PURE__ */ new WeakMap();
  function unsupported5(reason) {
    throw new TypeError("AS3_CLASS_UNSUPPORTED: " + reason);
  }
  function sourceError(name2, errorID) {
    const error4 = name2 === "TypeError" ? new TypeError("Error #" + errorID) : new Error("Error #" + errorID);
    error4.name = name2;
    Object.defineProperty(error4, "errorID", { value: errorID });
    throw error4;
  }
  function as3CallClass(value, arguments_ = []) {
    const target = as3AsClass(value);
    if (target === null) return sourceError("TypeError", 1006);
    const args = suppliedArguments(arguments_);
    if (target === Array) return as3CreateArray(args);
    if (target === Object) return args[0] == null ? as3CreateDynamicObject() : args[0];
    if (target === Number) return args.length === 0 ? 0 : as3CoerceNumber(args[0]);
    if (target === String) return args.length === 0 ? "" : as3String(args[0]);
    if (target === Boolean) return args.length === 0 ? false : Boolean(args[0]);
    if (target === AS3Int) return args.length === 0 ? 0 : as3CoerceInt(args[0]);
    if (target === AS3Uint) return args.length === 0 ? 0 : as3CoerceUint(args[0]);
    if (target === Function) {
      if (args.length) return sourceError("EvalError", 1066);
      return function() {
      };
    }
    if (args.length !== 1) return sourceError("ArgumentError", 1112);
    if (target === AS3ClassType) return as3CoerceClass(args[0]);
    return as3CoerceReference(args[0], target);
  }
  function as3AsClass(value) {
    if (builtinClasses3.has(value) || isAS3Interface(value)) return value;
    if (typeof value === "symbol" || typeof value === "bigint") return unsupported5("host-only primitive");
    if (typeof value !== "function") return null;
    const description = describeRegisteredFlashType(value);
    if (description?.isStatic) return value;
    const descriptor2 = Object.getOwnPropertyDescriptor(value, "prototype");
    if (descriptor2 && !descriptor2.writable) return unsupported5("native class lacks exact source metadata");
    return null;
  }
  function as3CoerceClass(value) {
    if (value === null || value === void 0) return null;
    const result = as3AsClass(value);
    return result === null ? sourceError("TypeError", 1034) : result;
  }
  function registerAS3Constructor(constructor, context2) {
    if (typeof constructor !== "function" || !describeRegisteredFlashType(constructor)?.isStatic)
      return unsupported5("constructor registration requires exact source class metadata");
    if (!context2 || !Number.isSafeInteger(context2.minimum) || context2.minimum < 0 || context2.maximum !== Infinity && (!Number.isSafeInteger(context2.maximum) || context2.maximum < context2.minimum) || typeof context2.coerceArguments !== "function")
      throw new TypeError("Invalid source constructor signature");
    const previous = constructors3.get(constructor);
    if (previous) {
      if (previous.minimum !== context2.minimum || previous.maximum !== context2.maximum || previous.coerceArguments !== context2.coerceArguments)
        throw new TypeError("Conflicting source constructor signature");
      return;
    }
    constructors3.set(constructor, Object.freeze({
      minimum: context2.minimum,
      maximum: context2.maximum,
      coerceArguments: context2.coerceArguments
    }));
  }
  function suppliedArguments(value) {
    if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype)
      return unsupported5("constructor arguments require an ordinary compiler argument list");
    const result = [];
    for (let index = 0; index < value.length; index++) {
      const item = Object.getOwnPropertyDescriptor(value, String(index));
      if (!item || !("value" in item)) return unsupported5("constructor argument list must contain dense data slots");
      result.push(item.value);
    }
    return result;
  }

  // src/layaAir/flash/utils/AS3MethodBinding.ts
  var bindings = /* @__PURE__ */ new WeakMap();
  var methodClosures = /* @__PURE__ */ new WeakMap();
  var parameterCounts = /* @__PURE__ */ new WeakMap();
  function record2(instance, name2, source, closure) {
    let methods = bindings.get(instance);
    if (!methods) bindings.set(instance, methods = /* @__PURE__ */ new Map());
    methods.set(name2, { source, closure });
    methodClosures.set(closure, source);
  }
  function isAS3MethodClosure(value) {
    return typeof value === "function" && methodClosures.has(value);
  }
  function getBoundAS3Method(instance, name2, source) {
    if (typeof source !== "function") throw new TypeError("Invalid source method");
    const previous = bindings.get(instance)?.get(name2);
    const own2 = Object.getOwnPropertyDescriptor(instance, name2);
    if (previous) {
      if (previous.source !== source || own2 && (!("value" in own2) || own2.value !== previous.closure))
        throw new TypeError("Source method binding was replaced by a host property");
      if (!own2) Object.defineProperty(instance, name2, {
        configurable: true,
        enumerable: false,
        writable: true,
        value: previous.closure
      });
      return previous.closure;
    }
    if (own2 && (!("value" in own2) || own2.value !== source))
      throw new TypeError("Source method requires authenticated closure provenance");
    const closure = source.bind(instance);
    Object.defineProperty(instance, name2, {
      configurable: true,
      enumerable: false,
      writable: true,
      value: closure
    });
    record2(instance, name2, source, closure);
    return closure;
  }
  function getAS3MethodSource(instance, name2, method2) {
    const previous = bindings.get(instance)?.get(name2);
    if (!previous) return method2;
    if (method2 !== previous.source && method2 !== previous.closure)
      throw new TypeError("Source method binding differs from registered descriptor");
    return previous.source;
  }
  function registerAS3FunctionParameterCounts(entries) {
    const next = /* @__PURE__ */ new Map();
    for (const [fn, count] of entries) {
      if (typeof fn !== "function" || !Number.isSafeInteger(count) || count < 0)
        throw new TypeError("Invalid source function parameter count");
      const previous = next.get(fn) ?? parameterCounts.get(fn);
      if (previous !== void 0 && previous !== count)
        throw new TypeError("Conflicting source function parameter count");
      next.set(fn, count);
    }
    for (const [fn, count] of next) parameterCounts.set(fn, count);
  }
  function registerAS3FunctionParameterCount(fn, count) {
    registerAS3FunctionParameterCounts([[fn, count]]);
  }
  function getAS3FunctionParameterCount(fn) {
    return parameterCounts.get(fn) ?? parameterCounts.get(methodClosures.get(fn));
  }
  function registerAS3BoundMethodClosure(fn, parameterCount) {
    registerAS3FunctionParameterCount(fn, parameterCount);
    if (!methodClosures.has(fn)) methodClosures.set(fn, fn);
  }

  // src/layaAir/flash/utils/AS3ObjectModel.ts
  var parents = /* @__PURE__ */ new WeakMap();
  var delegates = /* @__PURE__ */ new WeakSet();
  var classPrototypes = /* @__PURE__ */ new WeakMap();
  var instancePrototypes = /* @__PURE__ */ new WeakMap();
  var nativeConstructors = /* @__PURE__ */ new WeakMap();
  var builtinObjectConstructors = /* @__PURE__ */ new WeakSet();
  var as3ObjectPrototype = as3CreateDynamicObject();
  parents.set(as3ObjectPrototype, null);
  delegates.add(as3ObjectPrototype);
  Object.defineProperty(as3ObjectPrototype, "constructor", { value: Object, writable: true, configurable: true });
  var classPrototype = createAS3Prototype(AS3ClassType, as3ObjectPrototype);
  classPrototypes.set(Object, as3ObjectPrototype);
  classPrototypes.set(AS3ClassType, classPrototype);
  classPrototypes.set(Function, Function.prototype);
  parents.set(Function.prototype, as3ObjectPrototype);
  delegates.add(Function.prototype);
  for (const ctor of [Object, Function, AS3ClassType]) parents.set(ctor, classPrototype);
  function createAS3Prototype(constructor, parent = as3ObjectPrototype) {
    const value = as3CreateDynamicObject();
    Object.defineProperty(value, "constructor", { value: constructor, writable: true, configurable: true });
    parents.set(value, parent);
    delegates.add(value);
    return value;
  }
  function registerAS3ClassPrototype(constructor, base2) {
    if (!describeRegisteredFlashType(constructor)?.isStatic)
      throw new TypeError("AS3_PROTOTYPE_UNSUPPORTED: exact source Class metadata required");
    const previous = classPrototypes.get(constructor);
    if (previous) return previous;
    const parent = base2 === null || base2 === Object ? as3ObjectPrototype : classPrototypes.get(base2);
    if (!parent) throw new TypeError("AS3_PROTOTYPE_UNSUPPORTED: source base delegate is not registered");
    const native = Object.getOwnPropertyDescriptor(constructor, "prototype");
    if (!native || native.writable || native.configurable || !native.value)
      throw new TypeError("AS3_PROTOTYPE_UNSUPPORTED: source Class prototype identity is not stable");
    const previousConstructor = nativeConstructors.get(native.value);
    if (previousConstructor && previousConstructor !== constructor)
      throw new TypeError("AS3_PROTOTYPE_UNSUPPORTED: native prototype belongs to another constructor");
    const value = createAS3Prototype(constructor, parent);
    classPrototypes.set(constructor, value);
    instancePrototypes.set(native.value, value);
    nativeConstructors.set(native.value, constructor);
    parents.set(constructor, classPrototype);
    return value;
  }
  function getRegisteredAS3ClassPrototype(constructor) {
    return classPrototypes.get(constructor);
  }
  function isAS3Prototype(value) {
    return delegates.has(value);
  }
  function as3PrototypeOf(value) {
    if (isAS3ScriptGlobal(value)) return as3ObjectPrototype;
    if (parents.has(value)) return parents.get(value);
    if (typeof value === "function") return Function.prototype;
    const native = Object.getPrototypeOf(value);
    if (instancePrototypes.has(native)) return instancePrototypes.get(native);
    if (native === Object.prototype) return as3ObjectPrototype;
    if (delegates.has(native)) return native;
    return null;
  }
  function as3PrototypeContains(prototype, value) {
    if (value === null || typeof value !== "object" && typeof value !== "function") return false;
    const seen = /* @__PURE__ */ new Set();
    for (let parent = as3PrototypeOf(value); parent; parent = as3PrototypeOf(parent)) {
      if (seen.has(parent)) throw new TypeError("AS3_PROTOTYPE_UNSUPPORTED: cyclic source delegate");
      if (parent === prototype) return true;
      seen.add(parent);
    }
    return false;
  }
  function registerAS3FunctionPrototypeObject(value) {
    if (delegates.has(value)) return;
    if (Object.getPrototypeOf(value) !== Object.prototype)
      throw new TypeError("AS3_PROTOTYPE_UNSUPPORTED: nonordinary Function instance delegate");
    parents.set(value, as3ObjectPrototype);
    delegates.add(value);
  }
  function registerAS3BuiltinObjectDelegate(constructor) {
    if (typeof constructor !== "function" || constructor === Object || constructor === Function)
      throw new TypeError("AS3_PROTOTYPE_UNSUPPORTED: builtin constructor identity");
    const native = Object.getOwnPropertyDescriptor(constructor, "prototype");
    if (!native || native.writable || native.configurable || !native.value || typeof native.value !== "object" || Object.getPrototypeOf(native.value) !== Object.prototype || Object.getOwnPropertyDescriptor(native.value, "constructor")?.value !== constructor)
      throw new TypeError("AS3_PROTOTYPE_UNSUPPORTED: builtin direct Object prototype identity");
    const owner = nativeConstructors.get(native.value);
    if (owner && owner !== constructor)
      throw new TypeError("AS3_PROTOTYPE_UNSUPPORTED: native prototype belongs to another constructor");
    const previous = classPrototypes.get(constructor);
    if (previous) {
      if (!builtinObjectConstructors.has(constructor))
        throw new TypeError("AS3_PROTOTYPE_UNSUPPORTED: different delegate authority already published");
      return previous;
    }
    const value = constructor === Array ? [] : createAS3Prototype(constructor, as3ObjectPrototype);
    if (constructor === Array) {
      Object.defineProperty(value, "constructor", { value: constructor, writable: true, configurable: true });
      parents.set(value, as3ObjectPrototype);
      delegates.add(value);
    }
    classPrototypes.set(constructor, value);
    instancePrototypes.set(native.value, value);
    nativeConstructors.set(native.value, constructor);
    builtinObjectConstructors.add(constructor);
    parents.set(constructor, classPrototype);
    return value;
  }
  function getAS3RegisteredPrototypeConstructor(prototype) {
    return nativeConstructors.get(prototype);
  }
  function registerAS3ClassValueParent(constructor) {
    if (getAS3BuiltinClassName(constructor) === void 0 && !describeRegisteredFlashType(constructor)?.isStatic)
      throw new TypeError("AS3_PROTOTYPE_UNSUPPORTED: exact source Class metadata required");
    const previous = parents.get(constructor);
    if (previous !== void 0 && previous !== classPrototype)
      throw new TypeError("AS3_PROTOTYPE_UNSUPPORTED: conflicting Class value parent");
    parents.set(constructor, classPrototype);
  }

  // src/layaAir/flash/utils/AS3Invocation.ts
  var functions = /* @__PURE__ */ new WeakMap();
  var intrinsics = /* @__PURE__ */ new WeakMap();
  registerAS3FunctionParameterCount(Function.prototype, 0);
  function error(id) {
    const e = new TypeError("Error #" + id);
    Object.defineProperty(e, "errorID", { value: id });
    throw e;
  }
  function unsupported6(reason) {
    throw new TypeError("AS3_INVOCATION_UNSUPPORTED: " + reason);
  }
  function sourceFunction(value) {
    if (!as3Is(value, Function)) return error(1006);
    const global = functions.get(value)?.global;
    if (global && !isAS3ScriptGlobal(global)) return unsupported6("failed source function creation context");
    return value;
  }
  function record3(fn) {
    let value = functions.get(fn);
    if (!value) functions.set(fn, value = {});
    return value;
  }
  function registerAS3Function(fn, scriptGlobal, parameterCount) {
    sourceFunction(fn);
    if (!isAS3ScriptGlobal(scriptGlobal) || !Number.isSafeInteger(parameterCount) || parameterCount < 0)
      return unsupported6("invalid source function creation context");
    const value = record3(fn);
    if (value.global && (value.global !== scriptGlobal || value.parameterCount !== parameterCount))
      return unsupported6("conflicting source function creation context");
    registerAS3FunctionParameterCount(fn, parameterCount);
    value.global = scriptGlobal;
    value.parameterCount = parameterCount;
    return fn;
  }
  function argumentsList(values3) {
    if (!Array.isArray(values3) || Object.getPrototypeOf(values3) !== Array.prototype)
      return unsupported6("ordinary argument list required");
    const result = [];
    for (let index = 0; index < values3.length; index++) {
      const own2 = Object.getOwnPropertyDescriptor(values3, String(index));
      if (own2 && !("value" in own2)) return unsupported6("host argument accessor");
      result.push(own2?.value);
    }
    return result;
  }
  function as3CallValue(value, arguments_, receiver2) {
    const args = argumentsList(arguments_());
    if (as3AsClass(value) !== null) return as3CallClass(value, args);
    const fn = sourceFunction(value);
    const target = receiver2;
    if (target == null && !isAS3MethodClosure(fn) && fn !== Function.prototype)
      return unsupported6("direct call requires its caller global or explicit receiver");
    if (target != null && typeof target !== "object" && typeof target !== "function" && !isAS3MethodClosure(fn))
      return unsupported6("primitive call receiver boxing");
    return Reflect.apply(fn, target, args);
  }
  function getAS3FunctionPrototype(value) {
    const fn = sourceFunction(value), state = record3(fn);
    if (isAS3MethodClosure(fn)) return null;
    if (fn === Function.prototype) {
      if (!state.prototype) state.prototype = createAS3Prototype(fn);
      return state.prototype;
    }
    if (!state.prototype) {
      const descriptor2 = Object.getOwnPropertyDescriptor(fn, "prototype");
      if (!descriptor2?.writable) return unsupported6("source function needs a native constructable function body");
      const original = descriptor2.value;
      if (!original || typeof original !== "object" || Reflect.ownKeys(original).length !== 1 || Object.getOwnPropertyDescriptor(original, "constructor")?.value !== fn)
        return unsupported6("host modified the initial native function prototype");
      state.prototype = createAS3Prototype(fn);
      Object.defineProperty(fn, "prototype", { ...descriptor2, value: state.prototype });
    }
    if (Object.getOwnPropertyDescriptor(fn, "prototype")?.value !== state.prototype)
      return unsupported6("host changed source function prototype");
    return state.prototype;
  }
  function setAS3FunctionPrototype(value, prototype) {
    const fn = sourceFunction(value);
    if (isAS3MethodClosure(fn)) {
      const e = new ReferenceError("Error #1074");
      Object.defineProperty(e, "errorID", { value: 1074 });
      throw e;
    }
    getAS3FunctionPrototype(fn);
    if (prototype == null) prototype = as3ObjectPrototype;
    if (typeof prototype !== "object" && typeof prototype !== "function") return error(1049);
    if (as3AsClass(prototype) !== null || typeof prototype === "function") return unsupported6("function/Class-valued instance prototype");
    registerAS3FunctionPrototypeObject(prototype);
    record3(fn).prototype = prototype;
    if (fn !== Function.prototype) Object.defineProperty(fn, "prototype", { value: prototype });
  }
  function getAS3FunctionIntrinsic(value, name2) {
    const fn = sourceFunction(value);
    if (name2 !== "call" && name2 !== "apply") return void 0;
    let cache = intrinsics.get(fn);
    if (!cache) intrinsics.set(fn, cache = /* @__PURE__ */ new Map());
    let closure = cache.get(name2);
    if (!closure) {
      closure = (...args) => {
        const callReceiver = () => {
          if (args[0] != null || isAS3MethodClosure(fn)) return args[0];
          const global = functions.get(fn)?.global;
          if (!global && fn !== Function.prototype) return unsupported6("callee script global was not registered");
          return global;
        };
        if (name2 === "call") return as3CallValue(fn, () => args.slice(1), callReceiver());
        as3CheckArgumentCount(args.length, 0, 2);
        const values3 = args[1];
        if (values3 != null && !Array.isArray(values3)) return error(1116);
        return as3CallValue(fn, () => values3 == null ? [] : argumentsList(values3), callReceiver());
      };
      cache.set(name2, closure);
      registerAS3BoundMethodClosure(closure, name2 === "call" ? 1 : 2);
    }
    return closure;
  }
  function getAS3FunctionLength(fn) {
    const length = getAS3FunctionParameterCount(sourceFunction(fn));
    if (length === void 0) return unsupported6("source formal parameter count was not registered");
    return length;
  }
  var publicFunctionWrappers = /* @__PURE__ */ new Map();
  function getAS3FunctionPrototypeIntrinsic(name2) {
    if (name2 !== "call" && name2 !== "apply") return void 0;
    let wrapper = publicFunctionWrappers.get(name2);
    if (!wrapper) {
      wrapper = function(...args) {
        const method2 = getAS3FunctionIntrinsic(sourceFunction(this), name2);
        return Reflect.apply(method2, void 0, args);
      };
      registerAS3Function(wrapper, getAS3BuiltinScriptGlobal(), name2 === "call" ? 1 : 2);
      publicFunctionWrappers.set(name2, wrapper);
    }
    return wrapper;
  }

  // src/layaAir/flash/utils/DefinitionRegistry.ts
  var definitions = /* @__PURE__ */ new Map();
  var domainOwnedDefinitions = /* @__PURE__ */ new WeakSet();
  function markDomainOwnedDefinition(definition) {
    if (typeof definition !== "function") throw new TypeError("Invalid native definition");
    domainOwnedDefinitions.add(definition);
  }
  function normalizeDefinitionName(value) {
    const name2 = String(value);
    if (name2.includes("::"))
      return name2;
    const lastDot = name2.lastIndexOf(".");
    return lastDot < 0 ? name2 : `${name2.slice(0, lastDot)}::${name2.slice(lastDot + 1)}`;
  }
  function registerObservedDefinition(name2, definition) {
    if (domainOwnedDefinitions.has(definition)) return;
    const key3 = normalizeDefinitionName(name2);
    if (!definitions.has(key3))
      definitions.set(key3, Object.freeze({ name: key3, definition }));
  }
  for (const definition of [
    Object,
    Array,
    String,
    Number,
    Boolean,
    Date,
    Function,
    Error,
    RegExp,
    Promise
  ]) registerObservedDefinition(definition.name, definition);

  // src/layaAir/flash/utils/AS3ScriptGlobal.ts
  var domains = /* @__PURE__ */ new WeakMap();
  var globals = /* @__PURE__ */ new WeakMap();
  var privateScopes = /* @__PURE__ */ new WeakMap();
  var sourceClassOwners = /* @__PURE__ */ new WeakMap();
  var builtinClasses4 = /* @__PURE__ */ new Map([
    [Object, "Object"],
    [Function, "Function"],
    [Number, "Number"],
    [String, "String"],
    [Boolean, "Boolean"],
    [Array, "Array"]
  ]);
  function unsupported7(message) {
    throw new TypeError("AS3_SCRIPT_GLOBAL_UNSUPPORTED: " + message);
  }
  function sourceError2(errorID) {
    const error4 = new ReferenceError("Error #" + errorID);
    Object.defineProperty(error4, "errorID", { value: errorID });
    throw error4;
  }
  function key(name2, uri = "", visibility = "public") {
    return JSON.stringify([visibility, uri, name2]);
  }
  function validateAS3ScriptPrivateScope(scope2) {
    if (scope2 !== void 0 && (!scope2 || !privateScopes.has(scope2) || privateScopes.get(scope2).state === "failed")) return unsupported7("unknown file-private namespace");
  }
  function scopedBinding(state, name2, uri, scope2) {
    validateAS3ScriptPrivateScope(scope2);
    if (!uri && scope2 && privateScopes.get(scope2) === state) {
      const found = state.bindings.get(key(name2, "", "file-private"));
      if (found) return found;
    }
    return state.bindings.get(key(name2, uri));
  }
  function data2(object2, name2, optional = false) {
    const descriptor2 = Object.getOwnPropertyDescriptor(object2, name2);
    if (!descriptor2 && optional) return void 0;
    if (!descriptor2 || !("value" in descriptor2)) return unsupported7("declarations must contain own data fields: " + name2);
    return descriptor2.value;
  }
  function text(value, label, allowEmpty = false) {
    if (typeof value !== "string" || !allowEmpty && !value.length) return unsupported7("invalid " + label);
    return value;
  }
  function record4(value) {
    const found = globals.get(value);
    if (!found || found.state !== "ready") return unsupported7("script instance is not initialized");
    return found;
  }
  function read(binding) {
    return binding.declaration.kind === "constant" ? binding.storage.value : binding.storage.get();
  }
  function scalarType(value, type) {
    switch (type) {
      case "*":
        return value;
      case "Number":
        return as3CoerceNumber(value);
      case "int":
        return as3CoerceInt(value);
      case "uint":
        return as3CoerceUint(value);
      case "String":
        return as3CoerceString(value);
      case "Boolean":
        return !!value;
      case "Object":
        return as3CoerceObject(value);
      case "Function":
        return as3CoerceReference(value, Function);
      default:
        return unsupported7("variable reference type requires emitted coercion authority: " + type);
    }
  }
  function validateConstant(value, type) {
    if (typeof value === "function") {
      const actual = builtinClasses4.get(value) ?? describeRegisteredFlashType(value)?.name;
      if (actual === type || !actual && (type === "Function" || type === "*")) return;
      return unsupported7("native Class differs from declared source binding");
    }
    const valid = type === "*" || type === "Object" && value !== void 0 || type === "String" && (value === null || typeof value === "string") || type === "Boolean" && typeof value === "boolean" || type === "Number" && typeof value === "number" || type === "int" && typeof value === "number" && Number.isInteger(value) && value >= -2147483648 && value <= 2147483647 || type === "uint" && typeof value === "number" && Number.isInteger(value) && value >= 0 && value <= 4294967295 || type === "Function" && value === null;
    if (!valid) return unsupported7("constant value lacks its declared source type authority: " + type);
  }
  function createAS3ScriptDomain() {
    const domain = Object.freeze({ kind: "AS3ScriptDomain" });
    domains.set(domain, { closed: false, units: /* @__PURE__ */ new Map() });
    return domain;
  }
  function instantiateUnit(domain, input, factory, nativeProvider) {
    const owner = domains.get(domain);
    if (!owner || owner.closed) return unsupported7("unknown or unloaded script domain");
    if (!input || typeof input !== "object" || typeof factory !== "function") return unsupported7("source unit declaration required");
    const sourceId = text(data2(input, nativeProvider ? "providerId" : "sourceId"), "source identity");
    const sourceSha256 = text(data2(input, nativeProvider ? "evidenceSha256" : "sourceSha256"), "authority digest");
    if (!/^[a-f0-9]{64}$/.test(sourceSha256)) return unsupported7("source digest must be SHA-256");
    if (owner.units.has(sourceId)) return unsupported7("source unit was already instantiated in this domain");
    const sourceBindings = data2(input, "bindings");
    if (!Array.isArray(sourceBindings) || sourceBindings.length === 0) return unsupported7("actual source declarations are required");
    const declarations3 = [];
    const names = /* @__PURE__ */ new Set();
    for (let index = 0; index < sourceBindings.length; index++) {
      const item = data2(sourceBindings, String(index));
      if (!item || typeof item !== "object") return unsupported7("dense declaration records required");
      const name2 = text(data2(item, "name"), "binding name"), uri = text(data2(item, "uri", true) ?? "", "namespace", true);
      const kind = data2(item, "kind"), type = text(data2(item, "type"), "binding type");
      const visibility = data2(item, "visibility", true) ?? "public";
      if (visibility !== "public" && visibility !== "file-private" || visibility === "file-private" && (uri !== "" || nativeProvider)) return unsupported7("invalid source namespace visibility");
      if (kind !== "constant" && kind !== "variable" || names.has(key(name2, uri, visibility))) return unsupported7("duplicate or invalid source binding");
      names.add(key(name2, uri, visibility));
      declarations3.push(Object.freeze({ name: name2, uri, visibility, kind, type }));
    }
    const authority = nativeProvider ? Object.freeze({ kind: "native-provider", providerId: sourceId, evidenceSha256: sourceSha256 }) : Object.freeze({ kind: "authored-source", sourceId, sourceSha256 });
    class SourceGlobal {
    }
    Object.defineProperty(SourceGlobal, Symbol.for("laya.flash.classIdentifier"), { value: "global" });
    markDomainOwnedDefinition(SourceGlobal);
    const global = new SourceGlobal();
    const state = { domain, authority, bindings: /* @__PURE__ */ new Map(), state: "initializing" };
    globals.set(global, state);
    const privateScope = Object.freeze({ kind: "file-private" });
    privateScopes.set(privateScope, state);
    const unit = Object.freeze({ global, export: (name2, uri = "", scope2) => readAS3ScriptGlobalDeclaration(global, name2, uri, scope2)?.value });
    owner.units.set(sourceId, unit);
    try {
      const context2 = Object.freeze({ global, privateScope, registerFunction: (fn, parameterCount) => {
        if (state.state === "failed") return unsupported7("failed script creation context");
        registerAS3Function(fn, global, parameterCount);
        return fn;
      } });
      const emitted = factory(context2);
      if (owner.closed) return unsupported7("script domain unloaded during initialization");
      if (!Array.isArray(emitted) || emitted.length !== declarations3.length) return unsupported7("factory must supply every declared binding");
      const byName = /* @__PURE__ */ new Map();
      for (let index = 0; index < emitted.length; index++) {
        const item = data2(emitted, String(index));
        if (!item || typeof item !== "object") return unsupported7("dense emitted binding records required");
        const name2 = text(data2(item, "name"), "emitted binding name"), uri = text(data2(item, "uri", true) ?? "", "namespace", true);
        const visibility = data2(item, "visibility", true) ?? "public";
        if (visibility !== "public" && visibility !== "file-private") return unsupported7("invalid emitted namespace visibility");
        const id = key(name2, uri, visibility);
        if (!names.has(id) || byName.has(id)) return unsupported7("factory binding differs from source declaration");
        byName.set(id, Object.freeze({
          name: name2,
          uri,
          visibility,
          value: data2(item, "value", true),
          get: data2(item, "get", true),
          set: data2(item, "set", true)
        }));
      }
      for (const item of declarations3) {
        const storage = byName.get(key(item.name, item.uri, item.visibility));
        if (item.kind === "variable") {
          if (typeof storage.get !== "function" || typeof storage.set !== "function") return unsupported7("variables need actual native slot accessors");
        } else {
          if (storage.get !== void 0 || storage.set !== void 0) return unsupported7("constants require an actual immutable native value");
          validateConstant(storage.value, item.type);
        }
        state.bindings.set(key(item.name, item.uri, item.visibility), Object.freeze({ declaration: item, storage }));
        if (item.visibility !== "file-private" && !item.uri && item.kind === "constant") Object.defineProperty(global, item.name, { value: storage.value, enumerable: false });
      }
      const classes2 = [...state.bindings.values()].map((binding) => binding.storage.value).filter((value) => typeof value === "function" && !builtinClasses4.has(value) && !!describeRegisteredFlashType(value)?.isStatic);
      for (const value of classes2) if (sourceClassOwners.has(value))
        return unsupported7("source Class must be created by this script instance, not reused across units or domains");
      registerFlashTypeMetadata(SourceGlobal, {
        name: "global",
        base: "Object",
        isDynamic: true,
        isFinal: true,
        instance: {
          methods: [],
          accessors: [],
          variables: declarations3.filter((item) => item.visibility !== "file-private" && item.kind === "variable").map((item) => ({ ...item, declaredBy: "global" })),
          constants: declarations3.filter((item) => item.visibility !== "file-private" && item.kind === "constant").map((item) => ({ ...item, declaredBy: "global" }))
        },
        statics: { variables: [], accessors: [], methods: [], constants: [] }
      });
      for (const value of classes2) {
        sourceClassOwners.set(value, domain);
        markDomainOwnedDefinition(value);
      }
      state.state = "ready";
      return unit;
    } catch (error4) {
      state.state = "failed";
      owner.units.delete(sourceId);
      throw error4;
    }
  }
  function isAS3ScriptGlobal(value) {
    return value !== null && typeof value === "object" && globals.has(value) && globals.get(value).state !== "failed";
  }
  function readAS3ScriptGlobalDeclaration(global, name2, uri = "", scope2) {
    const state = record4(global), binding = scopedBinding(state, name2, uri, scope2);
    if (binding) return { value: read(binding) };
    if (state.unavailable?.has(key(name2, uri))) return unsupported7("native builtin export is unavailable: " + name2);
    if (uri) return sourceError2(1069);
    return void 0;
  }
  function hasAS3ScriptGlobalDeclaration(global, name2, scope2) {
    const state = record4(global);
    if (state.unavailable?.has(key(name2))) return unsupported7("native builtin export is unavailable: " + name2);
    return scopedBinding(state, name2, "", scope2) !== void 0;
  }
  function setAS3ScriptGlobalProperty(global, name2, value, uri = "", scope2) {
    const state = record4(global), binding = scopedBinding(state, name2, uri, scope2);
    if (state.unavailable?.has(key(name2, uri))) return unsupported7("native builtin export is unavailable: " + name2);
    if (binding) {
      if (binding.declaration.kind === "constant") return sourceError2(1074);
      binding.storage.set(scalarType(value, binding.declaration.type));
      return;
    }
    if (uri) return sourceError2(1056);
    Object.defineProperty(global, name2, { value, writable: true, enumerable: true, configurable: true });
  }
  function deleteAS3ScriptGlobalProperty(global, name2, scope2) {
    if (scopedBinding(record4(global), name2, "", scope2) || hasAS3ScriptGlobalDeclaration(global, name2)) return false;
    return Reflect.deleteProperty(global, name2);
  }
  var builtinGlobal;
  function getAS3BuiltinScriptGlobal() {
    if (!builtinGlobal) {
      const unit = instantiateUnit(createAS3ScriptDomain(), {
        providerId: "laya.flash.native-object-function-provider",
        evidenceSha256: "6df723e747d964dd204c62e12a777123ad36d13fc864827095a082f606e7eca6",
        bindings: [{ name: "Object", kind: "constant", type: "Object" }, { name: "Function", kind: "constant", type: "Function" }]
      }, () => [{ name: "Object", value: Object }, { name: "Function", value: Function }], true);
      builtinGlobal = unit.global;
      const unavailable = /* @__PURE__ */ new Set([
        ...[
          "Class",
          "Number",
          "String",
          "Boolean",
          "Array",
          "Namespace",
          "int",
          "uint",
          "NaN",
          "Infinity",
          "undefined",
          "AS3",
          "decodeURI",
          "decodeURIComponent",
          "encodeURI",
          "encodeURIComponent",
          "isNaN",
          "isFinite",
          "parseFloat",
          "parseInt",
          "escape",
          "unescape",
          "isXMLName"
        ].map((name2) => key(name2)),
        ...["INCLUDE_BASES", "INCLUDE_INTERFACES", "INCLUDE_VARIABLES", "INCLUDE_ACCESSORS", "USE_ITRAITS", "INCLUDE_METHODS", "INCLUDE_METADATA", "INCLUDE_CONSTRUCTOR", "INCLUDE_TRAITS", "HIDE_OBJECT", "FLASH10_FLAGS", "HIDE_NSURI_METHODS", "getQualifiedSuperclassName", "describeType", "getQualifiedClassName"].map((name2) => key(name2, "avmplus")),
        key("Vector", "__AS3__.vec")
      ]);
      Object.defineProperty(globals.get(builtinGlobal), "unavailable", { value: unavailable });
    }
    return builtinGlobal;
  }

  // src/layaAir/flash/utils/QName.ts
  var values2 = /* @__PURE__ */ new WeakMap();
  var declaredMethods = /* @__PURE__ */ new Set(["toString", "valueOf", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable"]);
  var readableProperties = /* @__PURE__ */ new Set([
    "uri",
    "localName",
    ...declaredMethods,
    "constructor",
    "toLocaleString",
    "setPropertyIsEnumerable"
  ]);
  function error2(value, errorID) {
    Object.defineProperty(value, "errorID", { value: errorID, enumerable: false });
    return value;
  }
  function checkArity(count, minimum, maximum) {
    if (count >= minimum && count <= maximum) return;
    const failure2 = error2(new Error("Error #1063"), 1063);
    failure2.name = "ArgumentError";
    throw failure2;
  }
  function read2(value) {
    const record5 = value !== null && (typeof value === "object" || typeof value === "function") ? values2.get(value) : void 0;
    if (!record5) throw error2(new TypeError("Incompatible QName receiver"), 1034);
    return record5;
  }
  function create(defaultUri, args, target) {
    const namespace3 = args.length < 2 ? void 0 : args[0];
    const name2 = args.length < 2 ? args[0] : args[1];
    if (args.length < 2 && name2 instanceof QName) return name2;
    let uri;
    if (namespace3 === null) uri = null;
    else if (namespace3 !== void 0) {
      const original = namespace3 instanceof QName ? read2(namespace3).uri : void 0;
      uri = original !== void 0 && original !== null ? original : as3String(namespace3);
    }
    const localName = name2 instanceof QName ? read2(name2).localName : name2 === void 0 ? "" : as3String(name2);
    if (namespace3 === void 0) uri = name2 instanceof QName ? read2(name2).uri : localName === "*" ? null : defaultUri;
    const instance = new globalThis.Proxy(target, {
      get: (object2, property, receiver2) => {
        if (typeof property === "symbol" || readableProperties.has(property))
          return Reflect.get(object2, property, receiver2);
        throw error2(new ReferenceError("Error #1069"), 1069);
      },
      has: (object2, property) => typeof property === "symbol" ? Reflect.has(object2, property) : readableProperties.has(property),
      deleteProperty: (object2, property) => typeof property === "symbol" ? Reflect.deleteProperty(object2, property) : false,
      set: (_target, property) => {
        const code = property === "uri" || property === "localName" ? 1074 : typeof property === "string" && declaredMethods.has(property) ? 1037 : 1056;
        throw error2(new ReferenceError(`Error #${code}`), code);
      }
    });
    const record5 = {
      uri,
      localName,
      text: () => uri === null ? "*::" + localName : uri === "" ? localName : uri + "::" + localName,
      value: () => instance,
      own: (...args2) => {
        checkArity(args2.length, 0, 1);
        const name3 = as3String(args2[0]);
        return name3 === "uri" || name3 === "localName";
      },
      enumerable: (...args2) => {
        checkArity(args2.length, 0, 1);
        as3String(args2[0]);
        return false;
      },
      prototype: (...args2) => {
        checkArity(args2.length, 0, 1);
        return Reflect.apply(Object.prototype.isPrototypeOf, instance, [args2[0]]);
      }
    };
    values2.set(instance, record5);
    values2.set(target, record5);
    for (const field of ["uri", "localName"]) Object.defineProperty(target, field, {
      get: () => record5[field],
      enumerable: true,
      configurable: false
    });
    Object.preventExtensions(target);
    return instance;
  }
  var QName = class _QName {
    constructor(first, second, ..._ignored) {
      if (new.target !== _QName) throw new TypeError("QName is final");
      return create("", Array.prototype.slice.call(arguments), this);
    }
    static [Symbol.hasInstance](value) {
      return value !== null && (typeof value === "object" || typeof value === "function") && values2.has(value);
    }
    static toString() {
      return "[class QName]";
    }
    get toString() {
      return this === _QName.prototype ? emptyText : read2(this).text;
    }
    get valueOf() {
      return this === _QName.prototype ? prototypeValue : read2(this).value;
    }
    get hasOwnProperty() {
      return read2(this).own;
    }
    get propertyIsEnumerable() {
      return read2(this).enumerable;
    }
    get isPrototypeOf() {
      return read2(this).prototype;
    }
    toLocaleString(..._args) {
      if (this === void 0 || this === null || this === globalThis) return "[object global]";
      if (this instanceof _QName) return "[object QName]";
      if (typeof this === "string") return "[object String]";
      if (typeof this === "number") return "[object Number]";
      if (typeof this === "boolean") return "[object Boolean]";
      if (Array.isArray(this)) return "[object Array]";
      const prototype = Object.getPrototypeOf(this);
      if (this === _QName.prototype || prototype === Object.prototype || prototype === null) return "[object Object]";
      throw new Error("AS3_QNAME_UNSUPPORTED: borrowed Object conversion requires source type metadata");
    }
    setPropertyIsEnumerable(name2, _enumerable) {
      checkArity(arguments.length, 2, 2);
      if (!(this instanceof _QName))
        throw new Error("AS3_QNAME_UNSUPPORTED: borrowed Object property enumeration requires its own provider");
      read2(this);
      as3String(name2);
      throw error2(new ReferenceError("Error #1056"), 1056);
    }
  };
  var emptyText = () => "";
  var prototypeValue = () => QName.prototype;

  // src/layaAir/flash/utils/Dictionary.ts
  var dictionaryDeclaration = declareAS3ReferenceType("flash.utils::Dictionary");
  var dictionaryValues = /* @__PURE__ */ new WeakSet();
  var sealedObjectMethods = /* @__PURE__ */ new Set(["hasOwnProperty", "propertyIsEnumerable", "isPrototypeOf"]);
  function isFlashDictionary(value) {
    return value !== null && typeof value === "object" && dictionaryValues.has(value);
  }
  function namespace(mode) {
    if (mode !== "public" && mode !== "public-and-AS3") throw new TypeError("Unsupported Dictionary namespace context");
  }
  function canonicalKey(value) {
    if (value instanceof QName) throw new TypeError("Dictionary namespaced keys are unsupported");
    if (isObjectKey(value)) return value;
    const text2 = as3String(value);
    if (/^(0|[1-9][0-9]{0,8})$/.test(text2)) {
      const integer = Number(text2);
      if (integer <= 268435455) return integer;
    }
    return text2;
  }
  var dictionaryToJSON = function(_key) {
    as3CheckArgumentCount(arguments.length, 1, 1);
    as3CoerceString(_key);
    return "Dictionary";
  };
  var sourcePrototype;
  function getDictionarySourcePrototype() {
    if (sourcePrototype) return sourcePrototype;
    const prototype = registerAS3ClassPrototype(Dictionary, Object);
    registerAS3PropertyTraits(Dictionary, []);
    registerAS3Function(dictionaryToJSON, getAS3BuiltinScriptGlobal(), 1);
    Object.defineProperty(prototype, "toJSON", { value: dictionaryToJSON, writable: true, configurable: true, enumerable: false });
    sourcePrototype = prototype;
    return prototype;
  }
  function releaseEntry(entry) {
    entry.active = false;
    entry.value = void 0;
    if (entry.kind === "strong") entry.key = void 0;
  }
  function isObjectKey(value) {
    return typeof value === "object" && value !== null || typeof value === "function";
  }
  var Dictionary = class {
    constructor(weakKeys = false) {
      this._strong = /* @__PURE__ */ new Map();
      this._weak = /* @__PURE__ */ new WeakMap();
      this._entries = [];
      as3CheckArgumentCount(arguments.length, 0, 1);
      this.weakKeys = weakKeys = !!weakKeys;
      const weakReference = globalThis.WeakRef ?? null;
      if (weakKeys && !weakReference)
        throw new Error("Weak-key Dictionary requires native WeakRef support");
      this._weakReference = weakReference;
      dictionaryGeneration.enterInstance(this);
      dictionaryValues.add(this);
      this._intrinsics = {
        hasOwnProperty: (key3) => this.entryFor(canonicalKey(as3CoerceString(key3))) !== void 0,
        propertyIsEnumerable: (key3) => this.entryFor(canonicalKey(as3CoerceString(key3))) !== void 0,
        isPrototypeOf: (value) => value !== null && (typeof value === "object" || typeof value === "function") && Object.prototype.isPrototypeOf.call(this, value),
        // Dictionary's HeapHashtable does not track ScriptObject's enumerability flag.
        setPropertyIsEnumerable: (key3, _enumerable) => {
          as3CoerceString(key3);
        },
        toString: () => "[object Dictionary]"
      };
      getAS3ObjectIntrinsic(this, "valueOf", "public", this._intrinsics);
      getDictionarySourcePrototype();
    }
    get size() {
      let count = 0;
      for (const _entry of this.liveEntries()) count++;
      return count;
    }
    has(key3, namespaces = "public-and-AS3") {
      namespace(namespaces);
      const canonical = canonicalKey(key3);
      if (this.entryFor(canonical) !== void 0) return true;
      if (typeof key3 === "number" && Number.isInteger(key3) && key3 >= 0 && key3 <= 2147483647 && !Object.is(key3, -0)) return false;
      return !isObjectKey(canonical) && this.hasPrototypeProperty(as3String(canonical));
    }
    /** QName membership bypasses identity storage and consults only public delegates. */
    hasPrototypeProperty(name2) {
      return !!getAS3ObjectDelegateProperty(this, name2, "public", this._intrinsics);
    }
    get(key3, namespaces = "public-and-AS3") {
      namespace(namespaces);
      const canonical = canonicalKey(key3);
      if (namespaces === "public-and-AS3" && typeof canonical === "string" && sealedObjectMethods.has(canonical))
        return getAS3ObjectIntrinsic(this, canonical, namespaces, this._intrinsics);
      const entry = this.entryFor(canonical);
      if (entry) return entry.value;
      if (isObjectKey(canonical)) return void 0;
      return getAS3ObjectDelegateProperty(this, as3String(canonical), namespaces, this._intrinsics)?.value;
    }
    set(key3, value, namespaces = "public-and-AS3") {
      namespace(namespaces);
      key3 = canonicalKey(key3);
      if (namespaces === "public-and-AS3" && typeof key3 === "string" && sealedObjectMethods.has(key3)) {
        const error4 = new ReferenceError("Error #1037");
        Object.defineProperty(error4, "errorID", { value: 1037 });
        throw error4;
      }
      const existing = this.entryFor(key3);
      if (existing) {
        existing.value = value;
        return this;
      }
      if (this.weakKeys && isObjectKey(key3)) {
        const entry = {
          kind: "weak",
          key: new this._weakReference(key3),
          value,
          active: true
        };
        this._weak.set(key3, entry);
        this._entries.push(entry);
      } else {
        const entry = { kind: "strong", key: key3, value, active: true };
        this._strong.set(key3, entry);
        this._entries.push(entry);
      }
      return this;
    }
    delete(key3, namespaces = "public-and-AS3") {
      namespace(namespaces);
      key3 = canonicalKey(key3);
      if (namespaces === "public-and-AS3" && typeof key3 === "string" && sealedObjectMethods.has(key3)) return false;
      const entry = this.entryFor(key3);
      if (!entry) return true;
      releaseEntry(entry);
      if (entry.kind === "weak") this._weak.delete(key3);
      else this._strong.delete(key3);
      return true;
    }
    clear() {
      for (const entry of this._entries) releaseEntry(entry);
      this._entries = [];
      this._strong.clear();
      this._weak = /* @__PURE__ */ new WeakMap();
    }
    *keys() {
      for (const entry of this.liveEntries()) yield entry[0];
    }
    *values() {
      for (const entry of this.liveEntries()) yield entry[1];
    }
    *entries() {
      yield* this.liveEntries();
    }
    entryFor(key3) {
      if (this.weakKeys && isObjectKey(key3)) return this._weak.get(key3);
      return this._strong.get(key3);
    }
    *liveEntries() {
      let stale = 0;
      for (const entry of this._entries) {
        if (!entry.active) {
          stale++;
          continue;
        }
        if (entry.kind === "strong") {
          yield [entry.key, entry.value];
          continue;
        }
        const key3 = entry.key.deref();
        if (key3 !== void 0) yield [key3, entry.value];
        else {
          releaseEntry(entry);
          stale++;
        }
      }
      if (stale > 32 && stale * 2 >= this._entries.length)
        this._entries = this._entries.filter((entry) => entry.active);
    }
  };
  registerFlashTypeMetadata(Dictionary, {
    name: "flash.utils::Dictionary",
    base: "Object",
    isDynamic: true,
    isFinal: false,
    instance: { variables: [], accessors: [], methods: [] },
    statics: { variables: [], accessors: [{ name: "prototype", declaredBy: "Class", access: "readonly" }], methods: [] }
  });
  var dictionaryGeneration = dictionaryDeclaration.publishGeneration(Dictionary);
  registerAS3Constructor(Dictionary, {
    minimum: 0,
    maximum: 1,
    // The actual constructor owns the single optional Boolean coercion. Keep
    // omitted arguments omitted and preserve count for its authored signature.
    coerceArguments: (arguments_) => arguments_
  });

  // src/layaAir/flash/utils/AS3Property.ts
  var instances2 = /* @__PURE__ */ new WeakMap();
  var constructors4 = /* @__PURE__ */ new WeakMap();
  var functionRecord = { constructor: Function, dynamic: true, static: false, function: true, traits: /* @__PURE__ */ new Map() };
  var methodClosureRecord = { ...functionRecord, dynamic: false };
  var builtinClassRecords = new Map([Object, Function, AS3ClassType].map((constructor) => [constructor, { constructor, dynamic: true, static: true, traits: /* @__PURE__ */ new Map() }]));
  var dynamicSlots = /* @__PURE__ */ new WeakMap();
  var nonEnumerableSlots = /* @__PURE__ */ new WeakMap();
  var functionPrototypeInitialized = false;
  function initializeFunctionPrototype() {
    if (functionPrototypeInitialized) return;
    dynamicSlots.set(Function.prototype, /* @__PURE__ */ new Map([
      ["constructor", Function],
      ["call", getAS3FunctionPrototypeIntrinsic("call")],
      ["apply", getAS3FunctionPrototypeIntrinsic("apply")]
    ]));
    nonEnumerableSlots.set(Function.prototype, /* @__PURE__ */ new Set(["constructor", "call", "apply"]));
    functionPrototypeInitialized = true;
  }
  var as3Methods = /* @__PURE__ */ new Set(["hasOwnProperty", "propertyIsEnumerable", "isPrototypeOf"]);
  function dictionaryAS3Method(key3) {
    return key3.uri === "http://adobe.com/AS3/2006/builtin" && as3Methods.has(key3.localName);
  }
  var intrinsicNames = /* @__PURE__ */ new Set(["constructor", ...as3Methods, "toString", "toLocaleString", "valueOf", "setPropertyIsEnumerable"]);
  function failure(name2, errorID) {
    const error4 = name2 === "TypeError" ? new TypeError(`Error #${errorID}`) : new ReferenceError(`Error #${errorID}`);
    Object.defineProperty(error4, "errorID", { value: errorID });
    throw error4;
  }
  function unsupported8(reason) {
    throw new TypeError("Unsupported source property representation: " + reason);
  }
  function receiver(value) {
    if (value === null) return failure("TypeError", 1009);
    if (value === void 0) return failure("TypeError", 1010);
    if (typeof value !== "object" && typeof value !== "function") return unsupported8("primitive receiver");
    return value;
  }
  function propertyName(value) {
    if (value instanceof QName) unsupported8("namespaced property keys are unsupported");
    return as3String(value);
  }
  function namespace2(value) {
    if (value !== "public" && value !== "public-and-AS3") unsupported8("namespace set");
  }
  function validateAS3PropertyType(type) {
    if (typeof type === "string" && ["*", "int", "uint", "Number", "Boolean", "String", "Object", "Function"].includes(type)) return type;
    if (type && typeof type === "object" && typeof type.name === "string" && type.name.length && (isAS3DeclarationType(type.reference) && type.reference.name === type.name || isAS3Interface(type.reference) || typeof type.reference === "function" && typeof Object.getOwnPropertyDescriptor(type.reference, "prototype")?.value === "object"))
      return type.name;
    return unsupported8("missing or invalid declared type");
  }
  function coerceAS3PropertyValue(value, type) {
    switch (type) {
      case "*":
        return value;
      case "int":
        return as3CoerceInt(value);
      case "uint":
        return as3CoerceUint(value);
      case "Number":
        return as3CoerceNumber(value);
      case "Boolean":
        return Boolean(value);
      case "String":
        return as3CoerceString(value);
      case "Object":
        return as3CoerceObject(value);
      case "Function":
        return as3CoerceReference(value, Function);
      default:
        return as3CoerceReference(value, type.reference);
    }
  }
  function descriptor(prototype, key3) {
    for (let current = prototype; current && current !== Object.prototype; current = Object.getPrototypeOf(current)) {
      const found = Object.getOwnPropertyDescriptor(current, key3);
      if (found) return found;
    }
    return void 0;
  }
  function registerAS3PropertyTraits(constructor, input, statics = []) {
    const reflection = describeRegisteredFlashType(constructor);
    if (!reflection?.isStatic || !reflection.factory) unsupported8("class needs exact reflection metadata");
    if (constructors4.has(constructor)) unsupported8("dispatch metadata already registered");
    const prototype = Object.getOwnPropertyDescriptor(constructor, "prototype")?.value;
    const instance = describeRegisteredFlashType(Object.create(prototype));
    if (!instance) unsupported8("instance metadata");
    const traits = buildTraits(input, instance, prototype, false);
    const staticTraits = buildTraits(statics, reflection, constructor, true);
    registerAS3ClassValueParent(constructor);
    sourceClassPrototype(constructor, false);
    registerAS3FunctionParameterCounts([...traits.values(), ...staticTraits.values()].filter((trait) => trait.kind === "method").map((trait) => [trait.descriptor.value, trait.parameterCount]));
    instances2.set(prototype, Object.freeze({ constructor, dynamic: instance.isDynamic, static: false, traits }));
    constructors4.set(constructor, Object.freeze({ constructor, dynamic: true, static: true, traits: staticTraits }));
  }
  function buildTraits(input, surface, prototype, statics) {
    const expected = /* @__PURE__ */ new Map();
    for (const [kind, list] of [
      ["variable", surface.variables],
      ["accessor", surface.accessors],
      ["method", surface.methods],
      ["constant", surface.constants ?? []]
    ])
      for (const item of list) if (!item.uri && (!statics || item.declaredBy === surface.name)) expected.set(item.name, { kind, ...item });
    const traits = /* @__PURE__ */ new Map();
    const storage = /* @__PURE__ */ new Set();
    if (!Array.isArray(input)) unsupported8("dense trait list required");
    for (const item of input) {
      if (!item || typeof item.name !== "string" || !item.name || traits.has(item.name)) unsupported8("duplicate/invalid trait");
      const match = expected.get(item.name);
      if (match ? match.kind !== item.kind : item.kind !== "constant" || surface.constants !== void 0)
        unsupported8("trait does not match reflected public authority");
      const key3 = item.key ?? item.name;
      if (typeof key3 !== "string" && typeof key3 !== "symbol") unsupported8("native storage key");
      if (storage.has(key3)) unsupported8("distinct source traits share native storage");
      storage.add(key3);
      let captured;
      let type = item.type;
      if (item.kind !== "method") {
        const name2 = validateAS3PropertyType(type);
        if (match?.type && name2 !== match.type) unsupported8("variable type differs from reflection");
        if (type && typeof type === "object") type = Object.freeze({ name: type.name, reference: type.reference });
      }
      if (item.kind === "accessor" || item.kind === "method") {
        captured = statics ? Object.getOwnPropertyDescriptor(prototype, key3) : descriptor(prototype, key3);
        if (!captured) unsupported8("declared prototype trait missing");
        if (item.kind === "method" && typeof captured.value !== "function") unsupported8("method descriptor");
        if (item.kind === "method" && typeof key3 !== "string") unsupported8("symbol method closure binding");
        if (item.kind === "accessor" && (Boolean(captured.get) !== (match.access !== "writeonly") || Boolean(captured.set) !== (match.access !== "readonly"))) unsupported8("accessor descriptor differs from reflection");
        if (item.kind === "method" && statics) captured = { ...captured, value: getAS3MethodSource(prototype, key3, captured.value) };
        captured = Object.freeze({ ...captured });
      }
      traits.set(item.name, Object.freeze({ name: item.name, kind: item.kind, key: key3, type, descriptor: captured, parameterCount: match?.parameterCount }));
      expected.delete(item.name);
    }
    if (expected.size) unsupported8("incomplete public trait surface");
    return traits;
  }
  function context(target) {
    initializeObjectPrototype();
    if (target === Dictionary) getDictionarySourcePrototype();
    if (isAS3ScriptGlobal(target)) return null;
    if (Array.isArray(target)) {
      initializeArrayPrototype(target);
      return null;
    }
    const record5 = typeof target === "function" ? constructors4.get(target) : instances2.get(Object.getPrototypeOf(target));
    if (record5) {
      if (!record5.static && record5.constructor === Dictionary)
        return unsupported8("Dictionary instances require private storage identity");
      sourceClassPrototype(record5.constructor, false);
      return record5;
    }
    if (builtinClassRecords.has(target)) return builtinClassRecords.get(target);
    if (getAS3BuiltinClassName(target) !== void 0) {
      registerAS3ClassValueParent(target);
      const builtin = {
        constructor: target,
        dynamic: true,
        static: true,
        conversionOnly: true,
        traits: /* @__PURE__ */ new Map()
      };
      builtinClassRecords.set(target, builtin);
      return builtin;
    }
    if (typeof target === "function" && as3Is(target, Function)) {
      initializeFunctionPrototype();
      return isAS3MethodClosure(target) ? methodClosureRecord : functionRecord;
    }
    if (typeof target === "function") return unsupported8("Class property dispatch requires registered source properties");
    if (Object.getPrototypeOf(target) === Object.prototype || isAS3Prototype(Object.getPrototypeOf(target))) return null;
    return unsupported8("unregistered class, Class, Array, Dictionary, Proxy, or custom prototype");
  }
  var arrayClosures = /* @__PURE__ */ new WeakMap();
  var remainingArrayMethods = /* @__PURE__ */ new Set(["concat", "every", "filter", "forEach", "indexOf", "lastIndexOf", "join", "map", "pop", "reverse", "shift", "slice", "some", "sort", "sortOn", "splice", "unshift", "toString", "toLocaleString"]);
  var arrayPrototypeInitialized = false;
  function initializeArrayPrototype(target) {
    if (Object.getPrototypeOf(target) !== Array.prototype) unsupported8("Array subclass or host prototype mutation");
    const length = Object.getOwnPropertyDescriptor(target, "length");
    if (!length || !("value" in length) || !length.writable || length.configurable || length.enumerable)
      unsupported8("host Array length descriptor");
    if (arrayPrototypeInitialized) return;
    const prototype = registerAS3BuiltinObjectDelegate(Array);
    const push = function(...values3) {
      return pushArrayValues(receiver(this), values3);
    };
    registerAS3Function(push, getAS3BuiltinScriptGlobal(), 0);
    Object.defineProperty(prototype, "push", { value: push, writable: true, configurable: true, enumerable: false });
    arrayPrototypeInitialized = true;
  }
  function arrayIndex(name2) {
    const value = Number(name2);
    return Number.isInteger(value) && value >= 0 && value < 4294967295 && String(value) === name2;
  }
  function pushArrayValues(target, values3) {
    if (Array.isArray(target)) {
      initializeArrayPrototype(target);
      for (const value of values3) as3DefineDynamicProperty(target, String(target.length), value);
      return target.length;
    }
    let length = as3CoerceUint(as3GetProperty(target, "length"));
    for (const value of values3) {
      as3SetProperty(target, String(length), value);
      length = length + 1 >>> 0;
    }
    as3SetProperty(target, "length", length);
    return length;
  }
  function arrayPush(target) {
    let closure = arrayClosures.get(target);
    if (!closure) {
      closure = (...values3) => pushArrayValues(target, values3);
      registerAS3BoundMethodClosure(closure, 0);
      arrayClosures.set(target, closure);
    }
    return closure;
  }
  function setArrayLength(target, value) {
    const length = as3CoerceUint(value);
    if (length < target.length) for (const key3 of Object.getOwnPropertyNames(target)) {
      if (arrayIndex(key3) && Number(key3) >= length && !Object.getOwnPropertyDescriptor(target, key3).configurable)
        unsupported8("host restricted Array element");
    }
    Object.defineProperty(target, "length", { value: length });
  }
  function arrayPublicName(key3) {
    if (key3.uri !== "") return unsupported8("non-public Array key namespace");
    return key3.localName;
  }
  function ownData(target, key3) {
    const found = Object.getOwnPropertyDescriptor(target, key3);
    if (found && !("value" in found)) unsupported8("dynamic/native slot is an accessor");
    return found;
  }
  var classConversionProperties = /* @__PURE__ */ new Set([
    "toString",
    "toLocaleString",
    "valueOf",
    "constructor",
    "hasOwnProperty",
    "propertyIsEnumerable",
    "isPrototypeOf",
    "setPropertyIsEnumerable"
  ]);
  function validateClassProperty(record5, name2) {
    if (record5?.conversionOnly && !classConversionProperties.has(name2))
      unsupported8("builtin Class property requires its own source metadata");
  }
  function own(target, name2, record5) {
    validateClassProperty(record5, name2);
    if (isAS3ScriptGlobal(target) && hasAS3ScriptGlobalDeclaration(target, name2)) return true;
    return record5 ? (record5.static || record5.function) && name2 === "prototype" || record5.function && name2 === "length" || record5.traits.has(name2) || !!dynamicSlots.get(target)?.has(name2) : !!ownData(target, name2);
  }
  var intrinsicClosures = /* @__PURE__ */ new WeakMap();
  var intrinsicOperations = /* @__PURE__ */ new WeakMap();
  var publicWrappers = /* @__PURE__ */ new Map();
  function invokeIntrinsic(target, name2, args) {
    const object2 = receiver(target);
    const ops = intrinsicOperations.get(object2) ?? operations(object2, context(object2));
    if (name2 === "setPropertyIsEnumerable") as3CheckArgumentCount(args.length, 2, 2);
    else if (as3Methods.has(name2)) as3CheckArgumentCount(args.length, 0, 1);
    switch (name2) {
      case "hasOwnProperty":
        return ops.hasOwnProperty(args[0]);
      case "propertyIsEnumerable":
        return ops.propertyIsEnumerable(args[0]);
      case "isPrototypeOf":
        return ops.isPrototypeOf(args[0]);
      case "setPropertyIsEnumerable":
        return ops.setPropertyIsEnumerable(args[0], args[1]);
      case "valueOf":
        return object2;
      case "toString":
        return Object.prototype.hasOwnProperty.call(ops, "toString") ? ops.toString() : as3InvokeToStringMethod(object2, Object.prototype.toString);
      case "toLocaleString":
        return Object.prototype.hasOwnProperty.call(ops, "toString") ? ops.toString() : as3InvokeToStringMethod(object2, Object.prototype.toString);
    }
    return void 0;
  }
  function getAS3ObjectIntrinsic(target, name2, namespaces, provider) {
    namespace2(namespaces);
    if (!intrinsicNames.has(name2) || name2 === "constructor") return void 0;
    for (const name3 of ["hasOwnProperty", "propertyIsEnumerable", "isPrototypeOf", "setPropertyIsEnumerable"])
      if (typeof provider[name3] !== "function") unsupported8("Object intrinsic provider operations");
    intrinsicOperations.set(target, Object.freeze({
      hasOwnProperty: provider.hasOwnProperty,
      propertyIsEnumerable: provider.propertyIsEnumerable,
      isPrototypeOf: provider.isPrototypeOf,
      setPropertyIsEnumerable: provider.setPropertyIsEnumerable,
      ...Object.prototype.hasOwnProperty.call(provider, "toString") ? { toString: provider.toString } : {}
    }));
    if (namespaces === "public-and-AS3" && as3Methods.has(name2)) {
      let cache = intrinsicClosures.get(target);
      if (!cache) intrinsicClosures.set(target, cache = /* @__PURE__ */ new Map());
      let fn = cache.get(name2);
      if (!fn) {
        fn = (...args) => invokeIntrinsic(target, name2, args);
        registerAS3BoundMethodClosure(fn, 1);
        cache.set(name2, fn);
      }
      return fn;
    }
    return publicWrapper(name2);
  }
  function publicWrapper(name2) {
    if (name2 === "toLocaleString") name2 = "toString";
    let fn = publicWrappers.get(name2);
    if (!fn) {
      fn = function(...args) {
        return invokeIntrinsic(this, name2, args);
      };
      registerAS3Function(fn, getAS3BuiltinScriptGlobal(), name2 === "setPropertyIsEnumerable" ? 2 : as3Methods.has(name2) ? 1 : 0);
      publicWrappers.set(name2, fn);
    }
    return fn;
  }
  var objectPrototypeInitialized = false;
  function initializeObjectPrototype() {
    if (objectPrototypeInitialized) return;
    for (const name2 of intrinsicNames) if (name2 !== "constructor")
      Object.defineProperty(as3ObjectPrototype, name2, { value: publicWrapper(name2), writable: true, configurable: true, enumerable: false });
    objectPrototypeInitialized = true;
  }
  function getAS3ObjectDelegateProperty(target, name2, namespaces, provider) {
    namespace2(namespaces);
    initializeObjectPrototype();
    getAS3ObjectIntrinsic(target, "valueOf", "public", provider);
    if (namespaces === "public-and-AS3" && as3Methods.has(name2))
      return { value: getAS3ObjectIntrinsic(target, name2, namespaces, provider) };
    return delegateValue(target, name2);
  }
  function sourceClassPrototype(constructor, required2 = true) {
    const known = getRegisteredAS3ClassPrototype(constructor);
    if (known) return known;
    if (typeof constructor !== "function") unsupported8("source Class prototype identity");
    const native = Object.getOwnPropertyDescriptor(constructor, "prototype")?.value;
    const parent = Object.getPrototypeOf(native);
    let base2 = null;
    if (parent !== Object.prototype) {
      const record5 = instances2.get(parent);
      const authority = getAS3RegisteredPrototypeConstructor(parent) ?? record5?.constructor;
      if (typeof authority !== "function") {
        if (required2) unsupported8("source base delegate requires its own registered class or builtin delegate authority");
        return void 0;
      }
      base2 = authority;
      if (!sourceClassPrototype(base2, required2)) return void 0;
    }
    return registerAS3ClassPrototype(constructor, base2);
  }
  function delegateValue(target, name2) {
    for (let parent = as3PrototypeOf(target); parent; parent = as3PrototypeOf(parent)) {
      const record5 = typeof parent === "function" ? context(parent) : null;
      if (record5) {
        if (dynamicSlots.get(parent)?.has(name2)) return { value: dynamicSlots.get(parent).get(name2) };
      } else {
        const data3 = ownData(parent, name2);
        if (data3) return { value: data3.value };
      }
    }
    return void 0;
  }
  function operations(target, record5) {
    return {
      hasOwnProperty: (key3) => own(target, as3String(as3CoerceString(key3)), record5),
      propertyIsEnumerable: (key3) => {
        const name2 = as3String(as3CoerceString(key3));
        return record5 ? !!dynamicSlots.get(target)?.has(name2) && !nonEnumerableSlots.get(target)?.has(name2) : !!ownData(target, name2)?.enumerable;
      },
      isPrototypeOf: (value) => {
        if (record5?.static) sourceClassPrototype(record5.constructor);
        return as3PrototypeContains(target, value);
      },
      ...!record5 && isAS3Prototype(Object.getPrototypeOf(target)) ? { toString: () => "[object Object]" } : {},
      ...record5?.static || record5?.function ? { toString: () => as3InvokeToStringMethod(target, Function.prototype.toString) } : {},
      setPropertyIsEnumerable: (key3, flag) => {
        if (record5) unsupported8("dynamic class enumerable flags");
        const name2 = as3String(as3CoerceString(key3));
        if (Array.isArray(target) && (name2 === "length" || arrayIndex(name2))) return;
        const found = ownData(target, name2);
        if (found) Object.defineProperty(target, name2, { ...found, enumerable: Boolean(flag) });
      }
    };
  }
  function read3(target, name2, record5, namespaces, scope2) {
    validateClassProperty(record5, name2);
    if (isAS3ScriptGlobal(target)) {
      const binding = readAS3ScriptGlobalDeclaration(target, name2, "", scope2);
      if (binding) return binding.value;
    }
    if (Array.isArray(target)) {
      if (namespaces === "public-and-AS3" && name2 === "push") return arrayPush(target);
      if (remainingArrayMethods.has(name2) && (namespaces === "public-and-AS3" || !ownData(target, name2))) unsupported8("Array method " + name2);
    }
    if (record5?.function) {
      if (name2 === "prototype") return getAS3FunctionPrototype(target);
      if (name2 === "length") return getAS3FunctionLength(target);
      const method2 = namespaces === "public-and-AS3" ? getAS3FunctionIntrinsic(target, name2) : void 0;
      if (method2) return method2;
    }
    const trait = record5?.traits.get(name2);
    if (trait) {
      if (trait.kind === "method") return getBoundAS3Method(target, trait.key, trait.descriptor.value);
      if (trait.kind === "accessor") {
        if (!trait.descriptor.get) return failure("ReferenceError", 1077);
        return trait.descriptor.get.call(target);
      }
      const stored = ownData(target, trait.key);
      if (!stored) unsupported8("declared slot has not been initialized");
      return stored.value;
    }
    if (namespaces === "public-and-AS3" && as3Methods.has(name2))
      return getAS3ObjectIntrinsic(target, name2, namespaces, operations(target, record5));
    if (record5 ? dynamicSlots.get(target)?.has(name2) : ownData(target, name2))
      return record5 ? dynamicSlots.get(target).get(name2) : ownData(target, name2).value;
    if (record5?.static && name2 === "prototype") return sourceClassPrototype(record5.constructor);
    const delegated = delegateValue(target, name2);
    if (delegated) return delegated.value;
    if (name2 === "constructor" && record5 && !record5.static && !record5.function && !getRegisteredAS3ClassPrototype(record5.constructor)) return record5.constructor;
    if (record5 && !record5.dynamic) return failure("ReferenceError", 1069);
    return void 0;
  }
  function as3GetProperty(target, key3, namespaces = "public-and-AS3", scope2) {
    const object2 = receiver(target);
    namespace2(namespaces);
    validateAS3ScriptPrivateScope(scope2);
    if (isAS3SourceError(object2)) return readSourceError(object2, propertyName(key3), namespaces);
    if (isFlashDictionary(object2)) {
      if (key3 instanceof QName) {
        if (key3.uri !== "" && !dictionaryAS3Method(key3)) return failure("ReferenceError", 1069);
        namespaces = dictionaryAS3Method(key3) ? "public-and-AS3" : "public";
        key3 = key3.localName;
      }
      return object2.get(key3, namespaces);
    }
    if (Array.isArray(object2) && key3 instanceof QName) {
      key3 = arrayPublicName(key3);
      namespaces = "public";
    }
    if (isAS3ScriptGlobal(object2) && key3 instanceof QName) {
      if (key3.uri === null) return unsupported8("wildcard global namespace");
      if (key3.uri) return readAS3ScriptGlobalDeclaration(object2, key3.localName, key3.uri)?.value;
      key3 = key3.localName;
      namespaces = "public";
      scope2 = void 0;
    }
    const record5 = context(object2), name2 = propertyName(key3);
    return read3(object2, name2, record5, namespaces, scope2);
  }
  function as3SetProperty(target, key3, value, namespaces = "public-and-AS3", scope2) {
    const object2 = receiver(target);
    namespace2(namespaces);
    validateAS3ScriptPrivateScope(scope2);
    if (isAS3SourceError(object2)) {
      const name3 = propertyName(key3);
      if (setSourceErrorField(object2, name3, value)) return value;
      if (name3 === "getStackTrace" || name3 === "constructor") return unsupported8("Error method/Class field");
      if (namespaces === "public-and-AS3" && as3Methods.has(name3)) return failure("ReferenceError", 1037);
      setSourceErrorDynamic(object2, name3, value);
      return value;
    }
    if (isFlashDictionary(object2)) {
      if (key3 instanceof QName) {
        if (key3.uri !== "" && !dictionaryAS3Method(key3)) return failure("ReferenceError", 1056);
        namespaces = dictionaryAS3Method(key3) ? "public-and-AS3" : "public";
        key3 = key3.localName;
      }
      object2.set(key3, value, namespaces);
      return value;
    }
    if (Array.isArray(object2) && key3 instanceof QName) {
      key3 = arrayPublicName(key3);
      namespaces = "public";
    }
    if (isAS3ScriptGlobal(object2) && key3 instanceof QName) {
      if (key3.uri === null) return unsupported8("wildcard global namespace");
      setAS3ScriptGlobalProperty(object2, key3.localName, value, key3.uri);
      return value;
    }
    const record5 = context(object2), name2 = propertyName(key3), trait = record5?.traits.get(name2);
    validateClassProperty(record5, name2);
    if (Array.isArray(object2)) {
      if (name2 === "length") {
        setArrayLength(object2, value);
        return value;
      }
      if (namespaces === "public-and-AS3" && name2 === "push") return failure("ReferenceError", 1037);
      if (namespaces === "public-and-AS3" && remainingArrayMethods.has(name2)) unsupported8("Array method " + name2);
    }
    if (record5?.function) {
      if (name2 === "prototype") {
        setAS3FunctionPrototype(object2, value);
        return value;
      }
      if (name2 === "length") return failure("ReferenceError", 1074);
      if (namespaces === "public-and-AS3" && (name2 === "call" || name2 === "apply")) return failure("ReferenceError", 1037);
    }
    if (trait) {
      if (trait.kind === "method") return failure("ReferenceError", 1037);
      if (trait.kind === "constant" || trait.kind === "accessor" && !trait.descriptor.set) return failure("ReferenceError", 1074);
      const converted = coerceAS3PropertyValue(value, trait.type);
      if (trait.kind === "accessor") trait.descriptor.set.call(object2, converted);
      else {
        const stored = ownData(object2, trait.key);
        if (!stored || !stored.writable) unsupported8("declared writable native slot");
        Object.defineProperty(object2, trait.key, { ...stored, value: converted });
      }
      return value;
    }
    if (isAS3ScriptGlobal(object2) && hasAS3ScriptGlobalDeclaration(object2, name2, scope2)) {
      setAS3ScriptGlobalProperty(object2, name2, value, "", scope2);
      return value;
    }
    if (namespaces === "public-and-AS3" && as3Methods.has(name2)) return failure("ReferenceError", 1037);
    if (isAS3ScriptGlobal(object2)) {
      setAS3ScriptGlobalProperty(object2, name2, value, "", scope2);
      return value;
    }
    if (record5) {
      if (record5.static && name2 === "prototype") return failure("ReferenceError", 1074);
      if (!record5.dynamic) return failure("ReferenceError", 1056);
      let slots = dynamicSlots.get(object2);
      if (!slots) dynamicSlots.set(object2, slots = /* @__PURE__ */ new Map());
      slots.set(name2, value);
      return value;
    }
    if (Array.isArray(object2) || isAS3Prototype(Object.getPrototypeOf(object2))) return as3DefineDynamicProperty(object2, name2, value, namespaces);
    return as3SetDynamicProperty(object2, name2, value, namespaces);
  }
  function as3HasProperty(key3, target) {
    const object2 = receiver(target);
    if (isAS3SourceError(object2)) {
      const name3 = propertyName(key3);
      if (name3 === "constructor" || name3 === "getStackTrace") return unsupported8("Error method/Class identity");
      if (sourceErrorOwn(object2, name3) || ["toString", "toLocaleString"].includes(name3)) return true;
      for (let parent = sourceErrorParent(object2); parent; parent = sourceErrorParent(parent))
        if (sourceErrorDynamic(parent, name3)) return true;
      return as3HasProperty(name3, as3ObjectPrototype);
    }
    if (isFlashDictionary(object2)) return key3 instanceof QName ? key3.uri === "" && object2.hasPrototypeProperty(key3.localName) : object2.has(key3);
    const record5 = context(object2), name2 = Array.isArray(object2) && key3 instanceof QName ? arrayPublicName(key3) : isAS3ScriptGlobal(object2) && key3 instanceof QName ? as3String(key3) : propertyName(key3);
    if (Array.isArray(object2) && typeof key3 === "number" && Number.isInteger(key3) && key3 >= 0 && key3 <= 2147483647)
      return own(object2, name2, record5);
    if (Array.isArray(object2) && remainingArrayMethods.has(name2) && !ownData(object2, name2)) unsupported8("Array method " + name2);
    return own(object2, name2, record5) || !!delegateValue(object2, name2) || !!record5 && !record5.static && !record5.function && name2 === "constructor" && !getRegisteredAS3ClassPrototype(record5.constructor) || !!record5?.function && name2 === "length";
  }
  function as3DeleteProperty(target, key3, namespaces = "public-and-AS3", scope2) {
    const object2 = receiver(target);
    namespace2(namespaces);
    validateAS3ScriptPrivateScope(scope2);
    if (isAS3SourceError(object2)) {
      const name3 = propertyName(key3);
      if (name3 === "constructor" || name3 === "getStackTrace") return unsupported8("Error method/Class identity");
      if (namespaces === "public-and-AS3" && as3Methods.has(name3)) return false;
      return deleteSourceErrorDynamic(object2, name3);
    }
    if (isFlashDictionary(object2)) {
      if (key3 instanceof QName) {
        if (key3.uri !== "") return false;
        key3 = key3.localName;
        namespaces = "public";
      }
      return object2.delete(key3, namespaces);
    }
    if (Array.isArray(object2) && key3 instanceof QName) {
      key3 = arrayPublicName(key3);
      namespaces = "public";
    }
    if (isAS3ScriptGlobal(object2) && key3 instanceof QName) {
      if (key3.uri !== "") return unsupported8("non-public global delete namespace");
      key3 = key3.localName;
      scope2 = void 0;
      namespaces = "public";
    }
    const record5 = context(object2), name2 = propertyName(key3);
    validateClassProperty(record5, name2);
    if (Array.isArray(object2) && namespaces === "public-and-AS3") {
      if (name2 === "push") return false;
      if (remainingArrayMethods.has(name2)) unsupported8("Array method " + name2);
    }
    if (record5 && !record5.dynamic) return false;
    if (record5?.traits.has(name2) || (record5?.static || record5?.function) && name2 === "prototype" || record5?.function && (name2 === "length" || namespaces === "public-and-AS3" && (name2 === "call" || name2 === "apply")) || namespaces === "public-and-AS3" && as3Methods.has(name2)) return false;
    if (isAS3ScriptGlobal(object2)) return deleteAS3ScriptGlobalProperty(object2, name2, scope2);
    if (record5) {
      dynamicSlots.get(object2)?.delete(name2);
      nonEnumerableSlots.get(object2)?.delete(name2);
      return true;
    }
    return Reflect.deleteProperty(object2, name2);
  }
  function resolveAS3SourcePublicConversionMethod2(value, name2) {
    if (value === null || typeof value !== "object" && typeof value !== "function") return void 0;
    if (name2 !== "toString" && name2 !== "valueOf") unsupported8("conversion property name");
    if (isAS3SourceError(value)) return { method: as3GetProperty(value, name2, "public") };
    if (getAS3BuiltinClassName(value) !== void 0) return { method: as3GetProperty(value, name2, "public") };
    if (isFlashDictionary(value)) return { method: as3GetProperty(value, name2, "public") };
    const prototype = Object.getPrototypeOf(value);
    const record5 = typeof value === "function" ? constructors4.get(value) : instances2.get(prototype);
    const sourceOwn = record5?.traits.has(name2) || dynamicSlots.get(value)?.has(name2);
    if (!sourceOwn && Object.getOwnPropertyDescriptor(value, name2)) return void 0;
    if (!record5) {
      if (typeof value === "function") {
        if (!as3Is(value, Function)) return void 0;
      } else if (prototype !== Object.prototype && !isAS3Prototype(prototype) && !isAS3ScriptGlobal(value)) return void 0;
    }
    return { method: as3GetProperty(value, name2, "public") };
  }
  installAS3SourcePublicConversionResolver(resolveAS3SourcePublicConversionMethod2);
  initializeArrayPrototype([]);
  function sourceErrorOwn(target, name2) {
    if (name2 === "constructor" || name2 === "getStackTrace") return unsupported8("Error method/Class identity");
    return !!sourceErrorField(target, name2) || !!sourceErrorDynamic(target, name2);
  }
  function sourceErrorOperations(target) {
    const key3 = (value) => as3String(as3CoerceString(value));
    return {
      hasOwnProperty: (value) => sourceErrorOwn(target, key3(value)),
      propertyIsEnumerable: (value) => sourceErrorEnumerable(target, key3(value)),
      setPropertyIsEnumerable: (value, flag) => setSourceErrorEnumerable(target, key3(value), Boolean(flag)),
      isPrototypeOf: (value) => {
        if (!isAS3SourceError(value)) return false;
        for (let parent = sourceErrorParent(value); parent; parent = sourceErrorParent(parent)) if (parent === target) return true;
        return false;
      },
      toString: () => unsupported8("Error toString/stack lowering is not admitted")
    };
  }
  function readSourceError(target, name2, namespaces) {
    const field = sourceErrorField(target, name2);
    if (field) return field.value;
    if (name2 === "constructor" || name2 === "getStackTrace") return unsupported8("Error method/Class field");
    const ops = sourceErrorOperations(target);
    getAS3ObjectIntrinsic(target, "valueOf", "public", ops);
    if (namespaces === "public-and-AS3" && as3Methods.has(name2)) return getAS3ObjectIntrinsic(target, name2, namespaces, ops);
    for (let current = target; current; current = sourceErrorParent(current)) {
      const dynamic = sourceErrorDynamic(current, name2);
      if (dynamic) return dynamic.value;
    }
    if (name2 === "toString" || name2 === "toLocaleString") return unsupported8("Error toString/stack lowering is not admitted");
    return as3GetProperty(as3ObjectPrototype, name2, "public");
  }

  // src/layaAir/flash/utils/AS3LexicalMembers.ts
  var scopes = /* @__PURE__ */ new WeakMap();
  var declarations2 = /* @__PURE__ */ new WeakMap();
  var generations = /* @__PURE__ */ new WeakMap();
  var accesses = /* @__PURE__ */ new WeakMap();
  function unsupported9(reason) {
    throw new TypeError("AS3_LEXICAL_UNSUPPORTED: " + reason);
  }
  function error3(id) {
    const e = new ReferenceError("Error #" + id);
    Object.defineProperty(e, "errorID", { value: id });
    throw e;
  }
  function scope(value) {
    return value && scopes.get(value) || unsupported9("unknown lexical capability");
  }
  function key2(name2, visibility, isStatic) {
    return JSON.stringify([isStatic, visibility, name2]);
  }
  function sameType(a, b) {
    return a === b || !!a && !!b && typeof a === "object" && typeof b === "object" && a.name === b.name && a.reference === b.reference;
  }
  function sameTrait(a, b) {
    return a.name === b.name && a.visibility === b.visibility && a.static === b.static && a.kind === b.kind && a.parameterCount === b.parameterCount && sameType(a.type, b.type) && a.getter === b.getter && a.setter === b.setter;
  }
  function registerAS3LexicalMembers(constructor, base2, members2) {
    const type = getAS3DeclarationType(constructor);
    if (!type || isCanonicalAS3DeclarationConstructor(constructor)) unsupported9("entered source declaration required");
    const parent = base2 === null ? null : scope(base2);
    if (getAS3SourceBase(constructor) !== (parent?.type ?? null)) unsupported9("sealed lexical source base mismatch");
    if (generations.has(constructor)) unsupported9("generation already registered");
    if (!Array.isArray(members2)) unsupported9("complete supplied lexical member list required");
    const traits = /* @__PURE__ */ new Map(), bindings2 = /* @__PURE__ */ new Map(), storage = /* @__PURE__ */ new Set();
    const counts = [];
    for (const member of members2) {
      if (!member || typeof member.name !== "string" || !member.name || !["private", "protected"].includes(member.visibility) || member.static !== void 0 && typeof member.static !== "boolean") unsupported9("lexical member identity");
      const id = key2(member.name, member.visibility, !!member.static);
      if (traits.has(id)) unsupported9("duplicate lexical declaration");
      const trait = { name: member.name, visibility: member.visibility, static: !!member.static, kind: member.kind };
      let binding;
      if (member.kind === "variable") {
        validateAS3PropertyType(member.type);
        const type2 = typeof member.type === "object" ? Object.freeze({ ...member.type }) : member.type;
        Object.assign(trait, { type: type2 });
        binding = { trait, key: Symbol(member.name) };
      } else if (member.kind === "method") {
        if (typeof member.key !== "string" && typeof member.key !== "symbol" || !Number.isSafeInteger(member.parameterCount) || member.parameterCount < 0) unsupported9("method declaration");
        const owner = member.static ? constructor : Object.getOwnPropertyDescriptor(constructor, "prototype")?.value;
        const descriptor2 = Object.getOwnPropertyDescriptor(owner, member.key);
        if (!descriptor2 || !("value" in descriptor2) || typeof descriptor2.value !== "function") unsupported9("exact own source method required");
        Object.assign(trait, { parameterCount: member.parameterCount });
        if (storage.has(member.key)) unsupported9("distinct lexical methods share native storage");
        storage.add(member.key);
        binding = { trait, key: Symbol(member.name), source: descriptor2.value };
        counts.push([descriptor2.value, member.parameterCount]);
      } else if (member.kind === "accessor") {
        if (member.getter !== true || member.setter !== true)
          unsupported9("accessor/signature admission pending: complete source accessor pair required");
        if (typeof member.key !== "string" && typeof member.key !== "symbol") unsupported9("accessor native key");
        validateAS3PropertyType(member.type);
        const owner = member.static ? constructor : Object.getOwnPropertyDescriptor(constructor, "prototype")?.value;
        const descriptor2 = owner && Object.getOwnPropertyDescriptor(owner, member.key);
        if (!descriptor2 || "value" in descriptor2 || typeof descriptor2.get !== "function" || typeof descriptor2.set !== "function")
          unsupported9("exact own source accessor pair required");
        if (storage.has(member.key)) unsupported9("distinct lexical members share native storage");
        storage.add(member.key);
        const type2 = typeof member.type === "object" ? Object.freeze({ ...member.type }) : member.type;
        Object.assign(trait, { type: type2, getter: true, setter: true });
        binding = { trait, key: Symbol(member.name), get: descriptor2.get, set: descriptor2.set };
      } else unsupported9("accessor/signature admission pending");
      Object.freeze(trait);
      Object.freeze(binding);
      traits.set(id, trait);
      bindings2.set(id, binding);
    }
    const previous = declarations2.get(type);
    if (previous && (previous.base !== parent || previous.traits.size !== traits.size || [...traits].some(([id, trait]) => !previous.traits.has(id) || !sameTrait(previous.traits.get(id), trait))))
      unsupported9("source declaration changed between generations");
    for (const trait of traits.values()) if (trait.visibility === "protected") {
      for (let current = parent; current; current = current.base) {
        const inherited = current.traits.get(key2(trait.name, "protected", trait.static));
        if (inherited && !(trait.kind === "method" && inherited.kind === "method" && trait.parameterCount === inherited.parameterCount || trait.kind === "accessor" && inherited.kind === "accessor" && sameTrait(trait, inherited)))
          unsupported9("protected override/field conflict");
      }
    }
    const reflection = describeRegisteredFlashType(constructor);
    for (const [surface, isStatic] of [[reflection.factory, false], [reflection, true]]) {
      for (const member of [...surface.variables, ...surface.accessors, ...surface.methods, ...surface.constants ?? []]) {
        if (member.uri || member.declaredBy !== type.name) continue;
        if (traits.has(key2(member.name, "protected", isStatic))) unsupported9("public/protected declaration conflict");
        for (let current = parent; current; current = current.base)
          if (current.traits.has(key2(member.name, "protected", isStatic))) unsupported9("public override of protected declaration");
      }
    }
    if ([...traits.values()].some((trait) => trait.static && trait.kind === "variable") && !Object.isExtensible(constructor))
      unsupported9("static lexical storage requires extensible native constructor");
    registerAS3FunctionParameterCounts(counts);
    const record5 = previous ?? { value: Object.freeze({}), type, base: parent, traits };
    const generation = { constructor, scope: record5, bindings: bindings2 };
    declarations2.set(type, record5);
    scopes.set(record5.value, record5);
    generations.set(constructor, generation);
    initializeFields(generation, constructor, true);
    return record5.value;
  }
  function defaultValue(type) {
    return type === "*" ? void 0 : type === "Number" ? NaN : type === "int" || type === "uint" ? 0 : type === "Boolean" ? false : null;
  }
  function initializeFields(generation, target, isStatic) {
    for (const binding of generation.bindings.values()) if (binding.trait.static === isStatic && binding.trait.kind === "variable") {
      if (!Object.getOwnPropertyDescriptor(target, binding.key))
        Object.defineProperty(target, binding.key, { value: defaultValue(binding.trait.type), writable: true, enumerable: false, configurable: false });
    }
  }
  function entered(value) {
    const constructors5 = getAS3EnteredSourceConstructors(value);
    if (!constructors5) return void 0;
    const chain = constructors5.map((constructor) => generations.get(constructor));
    if (chain.some((generation) => !generation)) unsupported9("entered source chain has unregistered lexical generation");
    return chain;
  }
  function initializeAS3LexicalInstance(lexical, target) {
    const current = scope(lexical), chain = entered(target);
    if (!chain || !chain.some((generation) => generation.scope === current)) unsupported9("lexical initialization requires genuine source entry");
    for (const generation of [...chain].reverse()) initializeFields(generation, target, false);
  }
  function resolveAS3LexicalMember(lexical, name2, visibility, isStatic = false, superAccess = false) {
    const current = scope(lexical);
    if (typeof name2 !== "string" || !name2 || !["private", "protected"].includes(visibility) || typeof isStatic !== "boolean" || typeof superAccess !== "boolean" || superAccess && (visibility !== "protected" || isStatic)) unsupported9("source lexical lookup");
    let owner = superAccess ? current.base : current;
    for (; owner; owner = visibility === "private" ? null : owner.base) {
      const trait = owner.traits.get(key2(name2, visibility, isStatic));
      if (trait) {
        const value = Object.freeze({});
        accesses.set(value, { scope: current, owner, trait, super: superAccess });
        return value;
      }
    }
    return unsupported9("source lexical declaration not found");
  }
  function access(value) {
    return value && accesses.get(value) || unsupported9("unknown lexical access");
  }
  function select(request, target) {
    let chain;
    if (request.trait.static) {
      const generation = typeof target === "function" ? generations.get(target) : void 0;
      if (!generation || generation.scope !== request.owner) return void 0;
      const binding = generation.bindings.get(key2(request.trait.name, request.trait.visibility, true));
      return binding ? { generation, binding, target } : void 0;
    } else chain = entered(target);
    if (!chain || !chain.some((generation) => generation.scope === request.scope)) return void 0;
    const virtual = request.trait.kind !== "variable" && request.trait.visibility === "protected" && !request.super;
    const id = key2(request.trait.name, request.trait.visibility, request.trait.static);
    for (const generation of chain) {
      if (!virtual && generation.scope !== request.owner) continue;
      const binding = generation.bindings.get(id);
      if (binding) return { generation, binding, target };
    }
    return void 0;
  }
  function as3GetLexicalMember(target, capability) {
    const request = access(capability);
    if (target == null) return as3GetProperty(target, request.trait.name);
    const found = select(request, target);
    if (!found) return error3(1069);
    const { binding } = found;
    if (binding.trait.kind === "method") return getBoundAS3Method(found.target, binding.key, binding.source);
    if (binding.trait.kind === "accessor") return Reflect.apply(binding.get, found.target, []);
    const stored = Object.getOwnPropertyDescriptor(found.target, binding.key);
    if (!stored || !("value" in stored)) return unsupported9("lexical fields must be initialized before source access");
    return stored.value;
  }
  function as3SetLexicalMember(target, capability, value) {
    const request = access(capability);
    if (target == null) {
      as3SetProperty(target, request.trait.name, value);
      return value;
    }
    const found = select(request, target);
    if (!found) return error3(1056);
    if (found.binding.trait.kind === "accessor") {
      const converted2 = coerceAS3PropertyValue(value, found.binding.trait.type);
      Reflect.apply(found.binding.set, found.target, [converted2]);
      return value;
    }
    if (found.binding.trait.kind !== "variable") return unsupported9("source method assignment not admitted");
    if (!Object.getOwnPropertyDescriptor(found.target, found.binding.key)) return unsupported9("lexical fields must be initialized before source access");
    const converted = coerceAS3PropertyValue(value, found.binding.trait.type);
    Object.defineProperty(found.target, found.binding.key, { value: converted });
    return value;
  }
  function as3CallLexicalMember(target, capability, argumentsThunk) {
    const fn = as3GetLexicalMember(target, capability);
    return as3CallValue(fn, argumentsThunk, target);
  }
  function dynamicAccess(current, name2) {
    if (current.traits.has(key2(name2, "private", false))) return resolveAS3LexicalMember(current.value, name2, "private");
    for (let owner = current; owner; owner = owner.base)
      if (owner.traits.has(key2(name2, "protected", false))) return resolveAS3LexicalMember(current.value, name2, "protected");
    return void 0;
  }
  function as3GetLexicalProperty(lexical, target, property) {
    const current = scope(lexical);
    if (property instanceof QName) return property.uri === "" ? as3GetProperty(target, property.localName, "public") : as3GetProperty(target, property);
    const name2 = as3String(property);
    if (as3HasProperty(name2, target)) return as3GetProperty(target, name2, "public");
    const capability = dynamicAccess(current, name2);
    if (capability && !getAS3EnteredSourceConstructors(target)) unsupported9("dynamic lexical lookup requires entered source receiver");
    return capability ? as3GetLexicalMember(target, capability) : as3GetProperty(target, name2);
  }
  function as3SetLexicalProperty(lexical, target, property, value) {
    const current = scope(lexical);
    if (property instanceof QName) return property.uri === "" ? as3SetProperty(target, property.localName, value, "public") : as3SetProperty(target, property, value);
    const name2 = as3String(property);
    if (as3HasProperty(name2, target)) return as3SetProperty(target, name2, value, "public");
    const capability = dynamicAccess(current, name2);
    if (capability && !getAS3EnteredSourceConstructors(target)) unsupported9("dynamic lexical lookup requires entered source receiver");
    return capability ? as3SetLexicalMember(target, capability, value) : as3SetProperty(target, name2, value);
  }

  // tests/nativeAS3LexicalAccessors/metadata.json
  var metadata_default = [
    {
      name: "probe::LexicalBase",
      base: "Object",
      isDynamic: false,
      isFinal: false,
      instance: {
        variables: [
          {
            name: "label",
            declaredBy: "probe::LexicalBase",
            type: "String"
          }
        ],
        constants: [],
        accessors: [
          {
            name: "changeFactor",
            declaredBy: "probe::LexicalBase",
            access: "readwrite"
          }
        ],
        methods: [
          {
            name: "setPrivate",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "protectedState",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          },
          {
            name: "peerPrivate",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "lexicalString",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "privateClosure",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          },
          {
            name: "lexicalAlias",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "protectedClosure",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          },
          {
            name: "publicQName",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "invokeProtected",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "nestedLexical",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          },
          {
            name: "accessProtected",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "privateState",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          }
        ]
      },
      statics: {
        variables: [],
        constants: [],
        accessors: [],
        methods: [
          {
            name: "baseEventClosure",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          },
          {
            name: "baseStatic",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          }
        ]
      }
    },
    {
      name: "probe::LexicalChild",
      base: "probe::LexicalBase",
      isDynamic: false,
      isFinal: false,
      instance: {
        variables: [
          {
            name: "label",
            declaredBy: "probe::LexicalBase",
            type: "String"
          }
        ],
        constants: [],
        accessors: [
          {
            name: "changeFactor",
            declaredBy: "probe::LexicalBase",
            access: "readwrite"
          }
        ],
        methods: [
          {
            name: "protectedState",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          },
          {
            name: "lexicalString",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "lexicalAlias",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "publicQName",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "nestedLexical",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          },
          {
            name: "privateState",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          },
          {
            name: "childPrivateState",
            declaredBy: "probe::LexicalChild",
            parameterCount: 0
          },
          {
            name: "setPrivate",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "childPrivateClosure",
            declaredBy: "probe::LexicalChild",
            parameterCount: 0
          },
          {
            name: "peerPrivate",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "childProtectedClosure",
            declaredBy: "probe::LexicalChild",
            parameterCount: 0
          },
          {
            name: "privateClosure",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          },
          {
            name: "directSuper",
            declaredBy: "probe::LexicalChild",
            parameterCount: 1
          },
          {
            name: "protectedClosure",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          },
          {
            name: "superClosure",
            declaredBy: "probe::LexicalChild",
            parameterCount: 0
          },
          {
            name: "invokeProtected",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "superScale",
            declaredBy: "probe::LexicalChild",
            parameterCount: 1
          },
          {
            name: "accessProtected",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "peerProtected",
            declaredBy: "probe::LexicalChild",
            parameterCount: 1
          }
        ]
      },
      statics: {
        variables: [],
        constants: [],
        accessors: [],
        methods: [
          {
            name: "childStatic",
            declaredBy: "probe::LexicalChild",
            parameterCount: 0
          },
          {
            name: "childEventClosure",
            declaredBy: "probe::LexicalChild",
            parameterCount: 0
          }
        ]
      }
    },
    {
      name: "probe::PublicTwin",
      base: "probe::LexicalBase",
      isDynamic: false,
      isFinal: false,
      instance: {
        variables: [
          {
            name: "secret",
            declaredBy: "probe::PublicTwin",
            type: "Number"
          },
          {
            name: "label",
            declaredBy: "probe::LexicalBase",
            type: "String"
          }
        ],
        constants: [],
        accessors: [
          {
            name: "changeFactor",
            declaredBy: "probe::LexicalBase",
            access: "readwrite"
          }
        ],
        methods: [
          {
            name: "setPrivate",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "protectedState",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          },
          {
            name: "peerPrivate",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "lexicalString",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "privateClosure",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          },
          {
            name: "lexicalAlias",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "protectedClosure",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          },
          {
            name: "publicQName",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "stamp",
            declaredBy: "probe::PublicTwin",
            parameterCount: 0
          },
          {
            name: "invokeProtected",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "nestedLexical",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          },
          {
            name: "accessProtected",
            declaredBy: "probe::LexicalBase",
            parameterCount: 1
          },
          {
            name: "privateState",
            declaredBy: "probe::LexicalBase",
            parameterCount: 0
          }
        ]
      },
      statics: {
        variables: [],
        constants: [],
        accessors: [],
        methods: []
      }
    }
  ];

  // tests/nativeAS3LexicalAccessors/source-lexical-traits.json
  var source_lexical_traits_default = [
    [
      {
        name: "secret",
        visibility: "private",
        static: false,
        kind: "variable",
        type: "Number"
      },
      {
        name: "amount",
        visibility: "protected",
        static: false,
        kind: "variable",
        type: "Number"
      },
      {
        name: "marker",
        visibility: "private",
        static: true,
        kind: "variable",
        type: "Number"
      },
      {
        name: "ticks",
        visibility: "protected",
        static: true,
        kind: "variable",
        type: "Number"
      },
      {
        name: "stamp",
        visibility: "private",
        static: false,
        kind: "method",
        parameterCount: 0
      },
      {
        name: "updateTweens",
        visibility: "protected",
        static: false,
        kind: "method",
        parameterCount: 1
      },
      {
        name: "scale",
        visibility: "protected",
        static: false,
        kind: "accessor",
        access: "get",
        type: "Number"
      },
      {
        name: "scale",
        visibility: "protected",
        static: false,
        kind: "accessor",
        access: "set",
        type: "Number"
      },
      {
        name: "onTweenEvent",
        visibility: "private",
        static: true,
        kind: "method",
        parameterCount: 1
      }
    ],
    [
      {
        name: "secret",
        visibility: "private",
        static: false,
        kind: "variable",
        type: "Number"
      },
      {
        name: "marker",
        visibility: "private",
        static: true,
        kind: "variable",
        type: "Number"
      },
      {
        name: "stamp",
        visibility: "private",
        static: false,
        kind: "method",
        parameterCount: 0
      },
      {
        name: "updateTweens",
        visibility: "protected",
        static: false,
        kind: "method",
        parameterCount: 1
      },
      {
        name: "scale",
        visibility: "protected",
        static: false,
        kind: "accessor",
        access: "get",
        type: "Number"
      },
      {
        name: "scale",
        visibility: "protected",
        static: false,
        kind: "accessor",
        access: "set",
        type: "Number"
      },
      {
        name: "onTweenEvent",
        visibility: "private",
        static: true,
        kind: "method",
        parameterCount: 1
      }
    ],
    []
  ];

  // tests/nativeAS3LexicalAccessors/private-metadata.json
  var private_metadata_default = [
    {
      name: "probe::PrivateBase",
      base: "Object",
      isDynamic: false,
      isFinal: false,
      instance: {
        variables: [],
        constants: [],
        accessors: [],
        methods: [
          {
            name: "readBase",
            declaredBy: "probe::PrivateBase",
            parameterCount: 0
          },
          {
            name: "setKey",
            declaredBy: "probe::PrivateBase",
            parameterCount: 2
          },
          {
            name: "writeBase",
            declaredBy: "probe::PrivateBase",
            parameterCount: 1
          },
          {
            name: "key",
            declaredBy: "probe::PrivateBase",
            parameterCount: 1
          },
          {
            name: "peer",
            declaredBy: "probe::PrivateBase",
            parameterCount: 1
          }
        ]
      },
      statics: {
        variables: [],
        constants: [],
        accessors: [],
        methods: [
          {
            name: "writeStatic",
            declaredBy: "probe::PrivateBase",
            parameterCount: 1
          }
        ]
      }
    },
    {
      name: "probe::PrivateChild",
      base: "probe::PrivateBase",
      isDynamic: false,
      isFinal: false,
      instance: {
        variables: [],
        constants: [],
        accessors: [],
        methods: [
          {
            name: "readChild",
            declaredBy: "probe::PrivateChild",
            parameterCount: 0
          },
          {
            name: "readBase",
            declaredBy: "probe::PrivateBase",
            parameterCount: 0
          },
          {
            name: "writeChild",
            declaredBy: "probe::PrivateChild",
            parameterCount: 1
          },
          {
            name: "setKey",
            declaredBy: "probe::PrivateBase",
            parameterCount: 2
          },
          {
            name: "writeBase",
            declaredBy: "probe::PrivateBase",
            parameterCount: 1
          },
          {
            name: "key",
            declaredBy: "probe::PrivateBase",
            parameterCount: 1
          },
          {
            name: "peer",
            declaredBy: "probe::PrivateBase",
            parameterCount: 1
          }
        ]
      },
      statics: {
        variables: [],
        constants: [],
        accessors: [],
        methods: []
      }
    }
  ];

  // tests/nativeAS3LexicalAccessors/private-source-traits.json
  var private_source_traits_default = [
    [
      {
        name: "amount",
        visibility: "private",
        static: false,
        kind: "variable",
        type: "Number"
      },
      {
        name: "total",
        visibility: "private",
        static: true,
        kind: "variable",
        type: "Number"
      },
      {
        name: "value",
        visibility: "private",
        static: false,
        kind: "accessor",
        access: "get",
        type: "Number"
      },
      {
        name: "value",
        visibility: "private",
        static: false,
        kind: "accessor",
        access: "set",
        type: "Number"
      },
      {
        name: "scale",
        visibility: "private",
        static: true,
        kind: "accessor",
        access: "get",
        type: "Number"
      },
      {
        name: "scale",
        visibility: "private",
        static: true,
        kind: "accessor",
        access: "set",
        type: "Number"
      }
    ],
    [
      {
        name: "amount",
        visibility: "private",
        static: false,
        kind: "variable",
        type: "Number"
      },
      {
        name: "value",
        visibility: "private",
        static: false,
        kind: "accessor",
        access: "get",
        type: "Number"
      },
      {
        name: "value",
        visibility: "private",
        static: false,
        kind: "accessor",
        access: "set",
        type: "Number"
      }
    ]
  ];

  // tests/nativeAS3LexicalAccessors/private.ts
  var events = [];
  var add = (s) => events.push(s);
  var base = declareAS3ReferenceType("probe::PrivateBase");
  var child = declareAS3ReferenceType("probe::PrivateChild", base.type);
  function hierarchy() {
    let bs, cs, bg, cg;
    const b = (name2, st = false) => resolveAS3LexicalMember(bs, name2, "private", st), c = (name2) => resolveAS3LexicalMember(cs, name2, "private");
    class PrivateBase {
      constructor() {
        bg.enterInstance(this);
        initializeAS3LexicalInstance(bs, this);
        as3SetLexicalMember(this, b("amount"), 5);
      }
      get _value() {
        add("base:get");
        return as3GetLexicalMember(this, b("amount"));
      }
      set _value(v) {
        add("base:set:" + v);
        as3SetLexicalMember(this, b("amount"), v);
      }
      static get _scale() {
        add("static:get");
        return as3GetLexicalMember(PrivateBase, b("total", true));
      }
      static set _scale(v) {
        add("static:set:" + v);
        as3SetLexicalMember(PrivateBase, b("total", true), v);
      }
      readBase() {
        return as3GetLexicalMember(this, b("value"));
      }
      writeBase(v) {
        const rhs = as3SetLexicalMember(this, b("value"), v);
        return [rhs === v, as3GetLexicalMember(this, b("value"))];
      }
      peer(other) {
        return as3GetLexicalMember(other, b("value"));
      }
      key(k) {
        return as3GetLexicalProperty(bs, this, k);
      }
      setKey(k, v) {
        const rhs = as3SetLexicalProperty(bs, this, k, v);
        return [rhs === v, as3GetLexicalProperty(bs, this, k)];
      }
      static writeStatic(v) {
        const rhs = as3SetLexicalMember(PrivateBase, b("scale", true), v);
        return [rhs === v, as3GetLexicalMember(PrivateBase, b("scale", true))];
      }
    }
    class PrivateChild extends PrivateBase {
      constructor() {
        super();
        cg.enterInstance(this);
        initializeAS3LexicalInstance(cs, this);
        as3SetLexicalMember(this, c("amount"), 50);
      }
      get _value() {
        add("child:get");
        return as3GetLexicalMember(this, c("amount"));
      }
      set _value(v) {
        add("child:set:" + v);
        as3SetLexicalMember(this, c("amount"), v * 2);
      }
      readChild() {
        return as3GetLexicalMember(this, c("value"));
      }
      writeChild(v) {
        const rhs = as3SetLexicalMember(this, c("value"), v);
        return [rhs === v, as3GetLexicalMember(this, c("value"))];
      }
    }
    const specs2 = (index) => private_source_traits_default[index].filter((t) => t.kind !== "accessor" || t.access === "get").map((t) => {
      if (t.kind === "accessor") {
        const pair = private_source_traits_default[index].find((s) => s.kind === "accessor" && s.access === "set" && s.name === t.name && s.static === t.static && s.visibility === t.visibility);
        if (!pair || pair.type !== t.type) throw new Error("Unpaired private source accessor");
        return { ...t, key: "_" + t.name, getter: true, setter: true };
      }
      return t;
    });
    for (const [ctor, i] of [[PrivateBase, 0], [PrivateChild, 1]]) {
      const row = private_metadata_default[i];
      registerFlashTypeMetadata(ctor, row);
      registerAS3PropertyTraits(ctor, row.instance.methods.map((v) => ({ name: v.name, kind: "method" })), row.statics.methods.map((v) => ({ name: v.name, kind: "method" })));
    }
    bg = base.publishGeneration(PrivateBase);
    bs = registerAS3LexicalMembers(PrivateBase, null, specs2(0));
    cg = child.publishGeneration(PrivateChild);
    cs = registerAS3LexicalMembers(PrivateChild, bs, specs2(1));
    as3SetLexicalMember(PrivateBase, b("total", true), 10);
    return { PrivateBase, PrivateChild, bs, cs, b, c };
  }
  function hook(s, bad = false) {
    return { valueOf() {
      add(s + ":valueOf");
      if (bad) throw Object.assign(new Error("hook"), { errorID: 7001 });
      return 3;
    }, toString() {
      add(s + ":toString");
      return "4";
    } };
  }
  function executePrivate() {
    const { PrivateBase, PrivateChild } = hierarchy(), rows = [];
    function rec(id, fn) {
      events = [];
      try {
        rows.push({ id, value: fn(), events: [...events] });
      } catch (e) {
        rows.push({ id, error: { name: e.name, errorID: e.errorID }, events: [...events] });
      }
    }
    rec("private-accessor-read", () => new PrivateBase().readBase());
    rec("private-accessor-write", () => new PrivateBase().writeBase(7));
    rec("private-accessor-coercion-rhs", () => new PrivateBase().writeBase(hook("input")));
    rec("private-accessor-throw", () => new PrivateBase().writeBase(hook("bad", true)));
    rec("private-accessor-failed-write-state", () => {
      const x = new PrivateBase();
      try {
        x.writeBase(hook("bad", true));
      } catch (e) {
        add("caught:" + e.errorID);
      }
      return x.readBase();
    });
    rec("private-accessor-peer", () => {
      const x = new PrivateChild(), y = new PrivateChild();
      y.writeBase(9);
      y.writeChild(8);
      return [x.peer(y), y.readChild()];
    });
    rec("private-accessor-shadowing", () => {
      const x = new PrivateChild();
      return [x.writeBase(7), x.writeChild(4), x.readBase(), x.readChild()];
    });
    rec("private-accessor-dynamic-key", () => {
      const x = new PrivateChild();
      return [x.setKey("value", hook("key")), x.key("value"), x.readChild()];
    });
    rec("private-static-accessor", () => PrivateBase.writeStatic(hook("static")));
    rec("private-accessor-public-read", () => as3GetProperty(new PrivateChild(), "value"));
    rec("private-accessor-public-write", () => as3SetProperty(new PrivateChild(), "value", hook("outside")));
    return rows;
  }

  // tests/nativeAS3LexicalAccessors/guards.ts
  function accessorGuards() {
    const results = [], events3 = [];
    const check = (name2, fn) => {
      if (!fn()) throw new Error("Accessor guard failed: " + name2);
      results.push(name2);
    };
    const reject = (name2, fn, message = "AS3_LEXICAL_UNSUPPORTED") => check(name2, () => {
      try {
        fn();
        return false;
      } catch (e) {
        return String(e.message).includes(message);
      }
    });
    const identityError = { failure: "body" }, returned = { valueOf() {
      events3.push("unwanted-getter-conversion");
      return 2;
    } };
    let serial = 0;
    function authority(base2) {
      return declareAS3ReferenceType("guard::Accessor" + ++serial, base2?.type);
    }
    const pair = (name2 = "item", visibility = "protected", st2 = false) => ({ name: name2, visibility, static: st2, kind: "accessor", key: "native", type: "Number", getter: true, setter: true });
    function published(a2, Base = Object, descriptor2 = {
      get() {
        events3.push("get");
        return returned;
      },
      set(v) {
        events3.push("set:" + v);
        if (v === 9) throw identityError;
      }
    }, staticDescriptor) {
      class Subject extends Base {
      }
      if (descriptor2) Object.defineProperty(Subject.prototype, "native", { configurable: true, ...descriptor2 });
      if (staticDescriptor) Object.defineProperty(Subject, "native", { configurable: true, ...staticDescriptor });
      const empty = () => ({ variables: [], accessors: [], methods: [] });
      registerFlashTypeMetadata(Subject, { name: a2.type.name, base: Base === Object ? "Object" : Base.sourceName, isDynamic: false, isFinal: false, instance: empty(), statics: empty() });
      Object.defineProperty(Subject, "sourceName", { value: a2.type.name });
      const generation = a2.publishGeneration(Subject);
      return { Subject, generation, entered: () => {
        const x2 = Object.create(Subject.prototype);
        generation.enterInstance(x2);
        return x2;
      } };
    }
    const a = authority(), h = published(a), s = registerAS3LexicalMembers(h.Subject, null, [pair()]), cap = resolveAS3LexicalMember(s, "item", "protected"), x = h.entered();
    events3.length = 0;
    check("getter-body-result-identity-without-post-body-conversion", () => as3GetLexicalMember(x, cap) === returned && events3.join(",") === "get");
    const rhs = { valueOf() {
      events3.push("coerce");
      return 4;
    } };
    events3.length = 0;
    check("setter-converts-once-before-body-and-preserves-RHS", () => as3SetLexicalMember(x, cap, rhs) === rhs && events3.join(",") === "coerce,set:4");
    events3.length = 0;
    check("setter-body-error-identity", () => {
      try {
        as3SetLexicalMember(x, cap, 9);
        return false;
      } catch (e) {
        return e === identityError && events3.join(",") === "set:9";
      }
    });
    const coercionError = { failure: "coerce" };
    events3.length = 0;
    check("conversion-error-identity-and-no-body", () => {
      try {
        as3SetLexicalMember(x, cap, { valueOf() {
          events3.push("coerce");
          throw coercionError;
        } });
        return false;
      } catch (e) {
        return e === coercionError && events3.join(",") === "coerce";
      }
    });
    Object.defineProperty(h.Subject.prototype, "native", { get() {
      throw new Error("replacement");
    }, set() {
      throw new Error("replacement");
    }, configurable: true });
    events3.length = 0;
    check("both-native-descriptor-halves-captured", () => as3GetLexicalMember(x, cap) === returned && as3SetLexicalMember(x, cap, 3) === 3 && events3.join(",") === "get,set:3");
    const retry = published(a, Object, { get() {
      return "retry";
    }, set(v) {
      events3.push("retry:" + v);
    } }), rs = registerAS3LexicalMembers(retry.Subject, null, [pair()]);
    const y = retry.entered();
    check("retry-retains-scope-but-uses-exact-generation-bodies", () => rs === s && as3GetLexicalMember(x, cap) === returned && as3GetLexicalMember(y, cap) === "retry");
    Object.setPrototypeOf(x, retry.Subject.prototype);
    events3.length = 0;
    check("mutated-instance-prototype-cannot-reselect-accessors", () => as3GetLexicalMember(x, cap) === returned && as3SetLexicalMember(x, cap, 3) === 3 && events3.join(",") === "get,set:3");
    events3.length = 0;
    const changing = { valueOf() {
      events3.push("coerce-mutate");
      Object.setPrototypeOf(x, retry.Subject.prototype);
      return 5;
    } };
    check("setter-selection-survives-coercion-prototype-mutation", () => as3SetLexicalMember(x, cap, changing) === changing && events3.join(",") === "coerce-mutate,set:5");
    reject("clone-accessor-read-rejected", () => as3GetLexicalMember(Object.create(h.Subject.prototype), cap), "1069");
    reject("clone-accessor-write-rejected", () => as3SetLexicalMember(Object.create(h.Subject.prototype), cap, 1), "1056");
    reject("forged-accessor-capability-rejected", () => as3GetLexicalMember(x, { name: "item" }));
    reject("null-accessor-read-source-error", () => as3GetLexicalMember(null, cap), "1009");
    reject("undefined-accessor-write-source-error", () => as3SetLexicalMember(void 0, cap, 1), "1010");
    const getterError = { failure: "getter" }, thrower = published(authority(), Object, { get() {
      throw getterError;
    }, set() {
    } });
    const throwScope = registerAS3LexicalMembers(thrower.Subject, null, [pair()]);
    check("getter-body-error-identity", () => {
      try {
        as3GetLexicalMember(thrower.entered(), resolveAS3LexicalMember(throwScope, "item", "protected"));
        return false;
      } catch (e) {
        return e === getterError;
      }
    });
    function malformed(name2, member, descriptor2, message = "AS3_LEXICAL_UNSUPPORTED") {
      const v = published(authority(), Object, descriptor2);
      reject(name2, () => registerAS3LexicalMembers(v.Subject, null, [member]), message);
      return v;
    }
    malformed("get-only-source-declaration-held", { ...pair(), setter: false });
    malformed("set-only-source-declaration-held", { ...pair(), getter: false });
    malformed("missing-source-half-flags-held", { name: "item", visibility: "protected", kind: "accessor", key: "native", type: "Number" });
    malformed("untyped-accessor-declaration-rejected", { ...pair(), type: "not-a-source-type" }, void 0, "missing or invalid declared type");
    malformed("non-key-accessor-storage-rejected", { ...pair(), key: {} });
    malformed("missing-native-getter-rejected", pair(), { set() {
    } });
    malformed("missing-native-setter-rejected", pair(), { get() {
      return 1;
    } });
    malformed("data-method-cannot-be-accessor", pair(), { value() {
      return 1;
    } });
    const inhAuthority = authority(), inh = published(inhAuthority), inhScope = registerAS3LexicalMembers(inh.Subject, null, []);
    const childAuth = authority(inhAuthority), inherited = published(childAuth, inh.Subject);
    delete inherited.Subject.prototype.native;
    reject("inherited-native-pair-is-not-own-source-declaration", () => registerAS3LexicalMembers(inherited.Subject, inhScope, [pair()]));
    const duplicate = published(authority());
    reject("same-native-key-for-two-accessor-declarations-rejected", () => registerAS3LexicalMembers(duplicate.Subject, null, [pair(), pair("other")]));
    const recovered = registerAS3LexicalMembers(duplicate.Subject, null, [pair()]);
    check("failed-registration-can-retry-atomically", () => as3GetLexicalMember(duplicate.entered(), resolveAS3LexicalMember(recovered, "item", "protected")) === returned);
    reject("retry-type-change-rejected", () => registerAS3LexicalMembers(published(a).Subject, null, [{ ...pair(), type: "String" }]));
    reject("retry-half-change-held", () => registerAS3LexicalMembers(published(a).Subject, null, [{ ...pair(), setter: false }]));
    const parentA = authority(), parent = published(parentA), ps = registerAS3LexicalMembers(parent.Subject, null, [pair()]);
    function derived(member) {
      const ca = authority(parentA), ch = published(ca, parent.Subject);
      return registerAS3LexicalMembers(ch.Subject, ps, [member]);
    }
    reject("protected-accessor-type-override-rejected", () => derived({ ...pair(), type: "String" }));
    reject("protected-accessor-field-override-rejected", () => derived({ name: "item", visibility: "protected", kind: "variable", type: "Number" }));
    const methodA = authority(parentA), methodChild = published(methodA, parent.Subject);
    Object.defineProperty(methodChild.Subject.prototype, "method", { value() {
    } });
    reject("protected-accessor-method-override-rejected", () => registerAS3LexicalMembers(methodChild.Subject, ps, [{ name: "item", visibility: "protected", kind: "method", key: "method", parameterCount: 0 }]));
    const childA = authority(parentA), child2 = published(childA, parent.Subject, { get() {
      return "child";
    }, set(v) {
      events3.push("child:" + v);
    } }), cs = registerAS3LexicalMembers(child2.Subject, ps, [pair()]), z = child2.entered();
    events3.length = 0;
    check("protected-accessor-virtual-selection", () => as3GetLexicalMember(z, resolveAS3LexicalMember(ps, "item", "protected")) === "child" && as3SetLexicalMember(z, resolveAS3LexicalMember(ps, "item", "protected"), 2) === 2 && events3.join(",") === "child:2");
    events3.length = 0;
    check("protected-accessor-super-selection", () => as3GetLexicalMember(z, resolveAS3LexicalMember(cs, "item", "protected", false, true)) === returned && as3SetLexicalMember(z, resolveAS3LexicalMember(cs, "item", "protected", false, true), 2) === 2 && events3.join(",") === "get,set:2");
    reject("derived-scope-accessor-rejects-base-receiver", () => as3GetLexicalMember(parent.entered(), resolveAS3LexicalMember(cs, "item", "protected")), "1069");
    const st = published(authority(), Object, {}, { get() {
      return this;
    }, set(v) {
      events3.push("static:" + v);
    } }), ss = registerAS3LexicalMembers(st.Subject, null, [pair("item", "private", true)]), sc = resolveAS3LexicalMember(ss, "item", "private", true);
    check("private-static-accessor-exact-receiver", () => as3GetLexicalMember(st.Subject, sc) === st.Subject);
    reject("static-accessor-foreign-constructor-rejected", () => as3GetLexicalMember(h.Subject, sc), "1069");
    Object.defineProperty(st.Subject, "native", { get() {
      throw identityError;
    }, set() {
      throw identityError;
    } });
    events3.length = 0;
    check("static-accessor-descriptors-captured", () => as3SetLexicalMember(st.Subject, sc, 2) === 2 && events3.join(",") === "static:2");
    const atomic = published(authority()), method2 = function() {
    };
    Object.defineProperty(atomic.Subject.prototype, "method", { value: method2 });
    const beforeCount = getAS3FunctionParameterCount(method2);
    reject("invalid-accessor-after-method-rejects", () => registerAS3LexicalMembers(atomic.Subject, null, [{ name: "method", visibility: "private", kind: "method", key: "method", parameterCount: 7 }, { ...pair(), getter: false }]));
    check("invalid-accessor-does-not-publish-method-count", () => getAS3FunctionParameterCount(method2) === beforeCount);
    return results;
  }

  // tests/nativeAS3LexicalAccessors/native.ts
  var events2 = [];
  var add2 = (s) => events2.push(s);
  var baseAuthority = declareAS3ReferenceType("probe::LexicalBase");
  var childAuthority = declareAS3ReferenceType("probe::LexicalChild", baseAuthority.type);
  var twinAuthority = declareAS3ReferenceType("probe::PublicTwin", baseAuthority.type);
  var nativeKeys = { stamp: "_stamp", updateTweens: "_updateTweens", onTweenEvent: "_onTweenEvent", scale: "_scale" };
  var specs = (index) => source_lexical_traits_default[index].filter((t) => t.kind !== "accessor" || t.access === "get").map((t) => {
    if (t.kind === "accessor") {
      const setter = source_lexical_traits_default[index].find((s) => s.kind === "accessor" && s.access === "set" && s.name === t.name && s.visibility === t.visibility && s.static === t.static);
      if (!setter || setter.type !== t.type) throw new Error("Incomplete source fixture accessor pair");
      return { ...t, key: nativeKeys[t.name], getter: true, setter: true };
    }
    if (t.kind === "method" && !nativeKeys[t.name]) throw new Error("Missing native fixture method binding");
    return { ...t, ...t.kind === "method" ? { key: nativeKeys[t.name] } : {} };
  });
  var baseSpecs = specs(0);
  var childSpecs = specs(1);
  function publicRegistration(ctor, index) {
    const row = metadata_default[index];
    registerFlashTypeMetadata(ctor, row);
    const traits = (m) => [
      ...m.variables.map((v) => ({ name: v.name, kind: "variable", type: v.type })),
      ...m.methods.map((v) => ({ name: v.name, kind: "method" })),
      ...m.accessors.map((v) => ({ name: v.name, kind: "accessor", type: "Number" }))
    ];
    registerAS3PropertyTraits(ctor, traits(row.instance), traits(row.statics));
  }
  function createHierarchy(authorities = [baseAuthority, childAuthority, twinAuthority], rootSpecs = baseSpecs, derivedSpecs = childSpecs) {
    let bs, cs, ts;
    let bg, cg, tg;
    const cap = (s, n, v, st = false, su = false) => resolveAS3LexicalMember(s, n, v, st, su);
    const b = (n, v = "private", st = false, su = false) => cap(bs, n, v, st, su);
    const c = (n, v = "private", st = false, su = false) => cap(cs, n, v, st, su);
    class LexicalBase {
      label;
      constructor(s = "base") {
        bg.enterInstance(this);
        initializeAS3LexicalInstance(bs, this);
        as3SetLexicalMember(this, b("secret"), 10);
        as3SetLexicalMember(this, b("amount", "protected"), 1);
        this.label = s;
      }
      _stamp() {
        add2(this.label + ":base-private");
        return this.label + ":base:" + as3GetLexicalMember(this, b("secret"));
      }
      _updateTweens(v) {
        add2(this.label + ":base-update:" + v);
        as3SetLexicalMember(this, b("amount", "protected"), Number(as3GetLexicalMember(this, b("amount", "protected"))) + v);
        return "base:" + as3GetLexicalMember(this, b("amount", "protected"));
      }
      privateState() {
        return [as3GetLexicalMember(this, b("secret")), as3CallLexicalMember(this, b("stamp"), () => [])];
      }
      setPrivate(v) {
        as3SetLexicalMember(this, b("secret"), v);
        return as3GetLexicalMember(this, b("secret"));
      }
      peerPrivate(v) {
        return as3GetLexicalMember(v, b("secret"));
      }
      privateClosure() {
        return as3GetLexicalMember(this, b("stamp"));
      }
      protectedClosure() {
        return as3GetLexicalMember(this, b("updateTweens", "protected"));
      }
      invokeProtected(v) {
        return as3CallLexicalMember(this, b("updateTweens", "protected"), () => [v]);
      }
      get _scale() {
        add2(this.label + ":base-get");
        return as3GetLexicalMember(this, b("amount", "protected"));
      }
      set _scale(v) {
        add2(this.label + ":base-set:" + v);
        as3SetLexicalMember(this, b("amount", "protected"), v);
      }
      accessProtected(v) {
        as3SetLexicalMember(this, b("scale", "protected"), v);
        return as3GetLexicalMember(this, b("scale", "protected"));
      }
      get changeFactor() {
        add2(this.label + ":public-get");
        return as3GetLexicalMember(this, b("amount", "protected"));
      }
      set changeFactor(v) {
        add2(this.label + ":public-set:" + v);
        as3CallLexicalMember(this, b("updateTweens", "protected"), () => [v]);
      }
      protectedState() {
        return as3GetLexicalMember(this, b("amount", "protected"));
      }
      static _onTweenEvent(v) {
        add2("base-event:" + v);
        return as3GetLexicalMember(LexicalBase, b("marker", "private", true));
      }
      static baseEventClosure() {
        return as3GetLexicalMember(LexicalBase, b("onTweenEvent", "private", true));
      }
      static baseStatic() {
        const ticks = b("ticks", "protected", true), marker = b("marker", "private", true);
        as3SetLexicalMember(LexicalBase, ticks, Number(as3GetLexicalMember(LexicalBase, ticks)) + 1);
        as3SetLexicalMember(LexicalBase, marker, Number(as3GetLexicalMember(LexicalBase, marker)) + 1);
        return [as3GetLexicalMember(LexicalBase, ticks), as3GetLexicalMember(LexicalBase, marker)];
      }
      lexicalString(k) {
        return as3GetLexicalProperty(bs, this, k);
      }
      lexicalAlias(k) {
        const v = this;
        return as3GetLexicalProperty(bs, v, k);
      }
      publicQName(k) {
        return as3GetLexicalProperty(bs, this, new QName("", k));
      }
      nestedLexical() {
        const v = this;
        return function(k) {
          return as3GetLexicalProperty(bs, v, k);
        };
      }
    }
    class LexicalChild extends LexicalBase {
      constructor(s = "child") {
        super(s);
        cg.enterInstance(this);
        initializeAS3LexicalInstance(cs, this);
        as3SetLexicalMember(this, c("secret"), 20);
      }
      _stamp() {
        add2(this.label + ":child-private");
        return this.label + ":child:" + as3GetLexicalMember(this, c("secret"));
      }
      _updateTweens(v) {
        add2(this.label + ":child-update:" + v);
        as3SetLexicalMember(this, c("amount", "protected"), Number(as3GetLexicalMember(this, c("amount", "protected"))) + v * 2);
        return "child:" + as3GetLexicalMember(this, c("amount", "protected"));
      }
      childPrivateState() {
        return [as3GetLexicalMember(this, c("secret")), as3CallLexicalMember(this, c("stamp"), () => [])];
      }
      childPrivateClosure() {
        return as3GetLexicalMember(this, c("stamp"));
      }
      childProtectedClosure() {
        return as3GetLexicalMember(this, c("updateTweens", "protected"));
      }
      directSuper(v) {
        return as3CallLexicalMember(this, c("updateTweens", "protected", false, true), () => [v]);
      }
      superClosure() {
        return as3GetLexicalMember(this, c("updateTweens", "protected", false, true));
      }
      get _scale() {
        add2(this.label + ":child-get");
        return Number(as3GetLexicalMember(this, c("amount", "protected"))) * 10;
      }
      set _scale(v) {
        add2(this.label + ":child-set:" + v);
        as3SetLexicalMember(this, c("amount", "protected"), v * 2);
      }
      superScale(v) {
        as3SetLexicalMember(this, c("scale", "protected", false, true), v);
        return as3GetLexicalMember(this, c("scale", "protected", false, true));
      }
      peerProtected(v) {
        return as3GetLexicalMember(v, c("amount", "protected"));
      }
      static _onTweenEvent(v) {
        add2("child-event:" + v);
        return as3GetLexicalMember(LexicalChild, c("marker", "private", true));
      }
      static childEventClosure() {
        return as3GetLexicalMember(LexicalChild, c("onTweenEvent", "private", true));
      }
      static childStatic() {
        const ticks = c("ticks", "protected", true), marker = c("marker", "private", true);
        as3SetLexicalMember(LexicalBase, ticks, Number(as3GetLexicalMember(LexicalBase, ticks)) + 1);
        as3SetLexicalMember(LexicalChild, marker, Number(as3GetLexicalMember(LexicalChild, marker)) + 1);
        return [as3GetLexicalMember(LexicalBase, ticks), as3GetLexicalMember(LexicalChild, marker)];
      }
    }
    class PublicTwin extends LexicalBase {
      secret = 30;
      constructor(s = "public") {
        super(s);
        tg.enterInstance(this);
        initializeAS3LexicalInstance(ts, this);
      }
      stamp() {
        add2(this.label + ":public-stamp");
        return this.label + ":public:" + this.secret;
      }
    }
    for (const [ctor, i] of [[LexicalBase, 0], [LexicalChild, 1], [PublicTwin, 2]]) publicRegistration(ctor, i);
    bg = authorities[0].publishGeneration(LexicalBase);
    bs = registerAS3LexicalMembers(LexicalBase, null, rootSpecs);
    cg = authorities[1].publishGeneration(LexicalChild);
    cs = registerAS3LexicalMembers(LexicalChild, bs, derivedSpecs);
    tg = authorities[2].publishGeneration(PublicTwin);
    ts = registerAS3LexicalMembers(PublicTwin, bs, []);
    as3SetLexicalMember(LexicalBase, b("marker", "private", true), 100);
    as3SetLexicalMember(LexicalBase, b("ticks", "protected", true), 0);
    as3SetLexicalMember(LexicalChild, c("marker", "private", true), 200);
    return { LexicalBase, LexicalChild, PublicTwin, bs, cs, ts, b, c, bg, cg, tg };
  }
  function hook2(s, bad = false) {
    return { valueOf() {
      add2(s + ":valueOf");
      if (bad) throw Object.assign(new Error("hook"), { errorID: 7001 });
      return 3;
    }, toString() {
      add2(s + ":toString");
      return "4";
    } };
  }
  var heldOriginalIds = ["protected-closure-number-coercion", "protected-closure-too-few", "protected-closure-too-many", "private-closure-too-many"];
  function execute() {
    const { LexicalBase, LexicalChild, PublicTwin, bs, cs } = createHierarchy();
    const rows = [];
    function rec(id, fn) {
      events2 = [];
      try {
        rows.push({ id, value: fn(), events: [...events2] });
      } catch (e) {
        rows.push({ id, error: { name: e.name, errorID: e.errorID }, events: [...events2] });
      }
    }
    rec("private-base-child-storage", () => {
      const x = new LexicalChild();
      return [x.privateState(), x.childPrivateState(), x.setPrivate(11), x.privateState(), x.childPrivateState()];
    });
    rec("private-peer-instance", () => {
      const a = new LexicalChild("a"), b = new LexicalChild("b");
      b.setPrivate(42);
      return [a.peerPrivate(b), b.childPrivateState()];
    });
    rec("private-public-same-name", () => {
      const x = new PublicTwin();
      return [x.privateState(), x.secret, x.stamp(), x.setPrivate(12), x.secret, x.privateState()];
    });
    rec("private-closure-stability", () => {
      const x = new LexicalChild(), y = new LexicalChild("other");
      return [x.privateClosure() === x.privateClosure(), x.childPrivateClosure() === x.childPrivateClosure(), x.privateClosure() === x.childPrivateClosure(), x.privateClosure() === y.privateClosure(), x.privateClosure()(), x.childPrivateClosure()()];
    });
    rec("private-closure-receiver", () => {
      const x = new LexicalChild("x"), y = new LexicalChild("y"), f = x.privateClosure();
      return [f.call(y), f.apply(null, [])];
    });
    rec("private-public-closure-distinct", () => {
      const x = new PublicTwin();
      return [x.privateClosure() === as3GetProperty(x, "stamp"), x.privateClosure()(), x.stamp()];
    });
    rec("protected-override-dispatch", () => {
      const x = new LexicalChild();
      return [x.invokeProtected(2), x.protectedState()];
    });
    rec("protected-closure-dispatch", () => {
      const x = new LexicalChild();
      return [x.protectedClosure() === x.childProtectedClosure(), x.protectedClosure()(2), x.protectedState()];
    });
    rec("protected-closure-receiver", () => {
      const x = new LexicalChild("x"), y = new LexicalChild("y"), f = x.protectedClosure();
      return [f.call(y, 2), x.protectedState(), y.protectedState()];
    });
    rec("protected-direct-super", () => {
      const x = new LexicalChild();
      return [x.directSuper(2), x.invokeProtected(2), x.protectedState()];
    });
    rec("protected-super-closure", () => {
      const x = new LexicalChild();
      return [x.superClosure() === x.superClosure(), x.superClosure() === x.protectedClosure(), x.superClosure()(2), x.protectedState()];
    });
    rec("protected-peer-child-typed", () => {
      const x = new LexicalChild(), y = new LexicalChild("y");
      y.accessProtected(8);
      return x.peerProtected(y);
    });
    rec("protected-accessor-override", () => {
      const x = new LexicalChild();
      return [x.accessProtected(3), x.protectedState()];
    });
    rec("protected-accessor-super", () => {
      const x = new LexicalChild();
      return [x.superScale(3), x.protectedState()];
    });
    rec("protected-accessor-coercion", () => {
      const x = new LexicalChild();
      return [x.accessProtected(hook2("set")), x.protectedState()];
    });
    rec("protected-accessor-throw", () => {
      const x = new LexicalChild();
      x.accessProtected(hook2("bad", true));
      return x.protectedState();
    });
    rec("public-accessor-protected-override", () => {
      const x = new LexicalChild();
      as3SetProperty(x, "changeFactor", 3);
      return [as3GetProperty(x, "changeFactor"), x.protectedState()];
    });
    rec("public-accessor-assignment-rhs", () => {
      const x = new LexicalChild(), h = hook2("rhs"), v = as3SetProperty(x, "changeFactor", h);
      return [v === h, as3GetProperty(x, "changeFactor")];
    });
    rec("private-assignment-coercion", () => {
      const x = new LexicalBase();
      return [x.setPrivate(hook2("private")), x.privateState()];
    });
    rec("static-private-and-protected", () => [LexicalBase.baseStatic(), LexicalChild.childStatic(), LexicalBase.baseStatic(), LexicalChild.childStatic()]);
    rec("sealed-private-read", () => as3GetProperty(new LexicalChild(), "secret"));
    rec("sealed-protected-read", () => as3GetProperty(new LexicalChild(), "amount"));
    rec("sealed-private-write", () => {
      const x = new LexicalChild();
      as3SetProperty(x, "secret", 99);
      return x.privateState();
    });
    rec("sealed-protected-write", () => {
      const x = new LexicalChild();
      as3SetProperty(x, "amount", 99);
      return x.protectedState();
    });
    rec("sealed-private-call", () => {
      const x = new LexicalChild();
      return as3GetProperty(x, "stamp")();
    });
    rec("sealed-protected-call", () => {
      const x = new LexicalChild();
      return as3GetProperty(x, "updateTweens")(2);
    });
    rec("sealed-protected-getter", () => as3GetProperty(new LexicalChild(), "scale"));
    rec("sealed-protected-setter", () => {
      as3SetProperty(new LexicalChild(), "scale", 2);
      return 1;
    });
    rec("private-string-key-inside-class", () => new LexicalChild().lexicalString("secret"));
    rec("protected-string-key-inside-class", () => new LexicalChild().lexicalString("amount"));
    rec("private-members-public-in", () => {
      const x = new LexicalChild();
      return ["secret", "amount", "stamp", "updateTweens", "changeFactor"].map((k) => as3HasProperty(k, x));
    });
    rec("private-members-public-delete", () => {
      const x = new LexicalChild();
      return ["secret", "amount", "stamp", "updateTweens"].map((k) => as3DeleteProperty(x, k));
    });
    rec("private-public-string-key-inside-base", () => {
      const x = new PublicTwin();
      return [x.lexicalString("secret"), x.secret];
    });
    rec("private-key-alias-object", () => new LexicalChild().lexicalAlias("secret"));
    rec("private-key-nested-function", () => new LexicalChild().nestedLexical()("secret"));
    rec("private-key-explicit-public-qname", () => new LexicalChild().publicQName("secret"));
    rec("private-public-key-explicit-public-qname", () => new PublicTwin().publicQName("secret"));
    rec("sealed-missing-public-delete", () => as3DeleteProperty(new LexicalChild(), "noSuchMember"));
    rec("private-static-callback-identity", () => {
      const a = LexicalBase.baseEventClosure(), b = LexicalChild.childEventClosure();
      return [a === LexicalBase.baseEventClosure(), b === LexicalChild.childEventClosure(), a === b, a("a"), b("b")];
    });
    rec("private-static-callback-transfer", () => {
      const callback = { onEvent: LexicalBase.baseEventClosure() };
      return [callback.onEvent("property"), callback.onEvent.call({}, "call"), callback.onEvent.apply(null, ["apply"])];
    });
    rec("child-dynamic-base-protected", () => as3GetLexicalProperty(cs, new LexicalBase(), "amount"));
    rec("child-dynamic-base-private", () => as3GetLexicalProperty(cs, new LexicalBase(), "secret"));
    rec("child-dynamic-child-private", () => as3GetLexicalProperty(cs, new LexicalChild(), "secret"));
    rec("child-dynamic-base-protected-write", () => {
      const b = new LexicalBase();
      return [as3SetLexicalProperty(cs, b, "amount", 5), b.protectedState()];
    });
    rec("base-dynamic-child-private-write", () => {
      const x = new LexicalChild();
      return [as3SetLexicalProperty(bs, x, "secret", 7), x.privateState(), x.childPrivateState()];
    });
    rec("base-dynamic-public-private-write", () => {
      const x = new PublicTwin();
      return [as3SetLexicalProperty(bs, x, "secret", 7), x.privateState(), x.secret];
    });
    return rows;
  }
  function invariants() {
    const names = [];
    const check = (name2, fn) => {
      if (!fn()) throw new Error("Guard failed: " + name2);
      names.push(name2);
    };
    const rejects = (name2, fn, match = "AS3_LEXICAL_UNSUPPORTED") => check(name2, () => {
      try {
        fn();
        return false;
      } catch (e) {
        return typeof match === "number" ? e.errorID === match : String(e.message).includes(match);
      }
    });
    const h = createHierarchy(), x = new h.LexicalChild("old"), b = new h.LexicalBase("base");
    const privateCap = h.b("secret"), childCap = h.c("secret"), methodCap = h.b("stamp");
    check("private-fields-distinct", () => as3GetLexicalMember(x, privateCap) === 10 && as3GetLexicalMember(x, childCap) === 20);
    check("method-closure-common-authority", () => isAS3MethodClosure(as3GetLexicalMember(x, methodCap)) && getAS3FunctionParameterCount(as3GetLexicalMember(x, methodCap)) === 0);
    check("super-closure-common-authority", () => isAS3MethodClosure(x.superClosure()) && getAS3FunctionParameterCount(x.superClosure()) === 1);
    check("static-closure-common-authority", () => isAS3MethodClosure(h.LexicalBase.baseEventClosure()) && getAS3FunctionParameterCount(h.LexicalBase.baseEventClosure()) === 1);
    rejects("scope-spelling-not-authority", () => resolveAS3LexicalMember({ name: "probe::LexicalBase" }, "secret", "private"));
    rejects("access-spelling-not-authority", () => as3GetLexicalMember(x, { name: "secret" }));
    rejects("prototype-copy-not-entry", () => as3GetLexicalMember(Object.create(h.LexicalChild.prototype), privateCap), 1069);
    rejects("plain-object-not-entry", () => as3SetLexicalMember({ secret: 9 }, privateCap, 1), 1056);
    rejects("outside-closed-hierarchy-dynamic-lookup-held", () => as3GetLexicalProperty(h.bs, {}, "secret"), "dynamic lexical lookup requires entered source receiver");
    rejects("foreign-constructor-not-generation", () => as3GetLexicalMember(function() {
    }, h.b("marker", "private", true)), 1069);
    rejects("child-private-wrong-receiver", () => as3GetLexicalMember(b, childCap), 1069);
    rejects("child-protected-wrong-receiver", () => as3GetLexicalMember(b, h.c("amount", "protected")), 1069);
    rejects("private-not-inherited", () => resolveAS3LexicalMember(h.ts, "secret", "private"));
    check("accessor-capability-published", () => !!resolveAS3LexicalMember(h.cs, "scale", "protected"));
    rejects("method-assignment-not-admitted", () => as3SetLexicalMember(x, methodCap, () => 5));
    rejects("static-super-not-admitted", () => resolveAS3LexicalMember(h.cs, "ticks", "protected", true, true));
    rejects("null-read-keeps-1009", () => as3GetLexicalMember(null, privateCap), 1009);
    rejects("undefined-write-keeps-1010", () => as3SetLexicalMember(void 0, privateCap, 1), 1010);
    check("initialize-does-not-reset", () => {
      as3SetLexicalMember(x, privateCap, 55);
      initializeAS3LexicalInstance(h.cs, x);
      return as3GetLexicalMember(x, privateCap) === 55 && as3GetLexicalMember(x, childCap) === 20;
    });
    events2 = [];
    const value = hook2("field");
    check("assignment-returns-original-rhs", () => as3SetLexicalMember(x, privateCap, value) === value && as3GetLexicalMember(x, privateCap) === 3 && events2.join(",") === "field:valueOf");
    const saved = as3GetLexicalMember(x, privateCap);
    events2 = [];
    rejects("throwing-coercion-preserves-slot", () => as3SetLexicalMember(x, privateCap, hook2("throw", true)), 7001);
    check("failed-write-unchanged", () => as3GetLexicalMember(x, privateCap) === saved && events2.join(",") === "throw:valueOf");
    events2 = [];
    check("dynamic-key-coerced-once", () => as3GetLexicalProperty(h.bs, x, { toString() {
      add2("key");
      return "secret";
    } }) === 3 && events2.join(",") === "key");
    let evaluated = false;
    rejects("lookup-failure-precedes-arguments", () => as3CallLexicalMember({}, methodCap, () => {
      evaluated = true;
      return [];
    }), 1069);
    check("failed-lookup-does-not-evaluate-args", () => !evaluated);
    const oldPrivate = x.privateClosure(), oldSuper = x.superClosure();
    const retry = createHierarchy();
    const y = new retry.LexicalChild("new");
    check("retry-scope-is-source-identity", () => retry.bs === h.bs && retry.cs === h.cs);
    check("retry-fields-same-declaration-independent-storage", () => as3GetLexicalMember(y, privateCap) === 10 && as3GetLexicalMember(x, privateCap) === 3);
    check("retry-source-closures-distinct", () => oldPrivate !== y.privateClosure() && oldSuper !== y.superClosure());
    const originalPrototype = Object.getPrototypeOf(x);
    Object.setPrototypeOf(x, retry.LexicalChild.prototype);
    check("mutated-native-prototype-cannot-reselect-generation", () => as3GetLexicalMember(x, privateCap) === 3 && as3GetLexicalMember(x, methodCap) === oldPrivate);
    Object.setPrototypeOf(x, originalPrototype);
    const otherBase = declareAS3ReferenceType("probe::LexicalBase"), otherChild = declareAS3ReferenceType("probe::LexicalChild", otherBase.type), otherTwin = declareAS3ReferenceType("probe::PublicTwin", otherBase.type);
    const foreign = createHierarchy([otherBase, otherChild, otherTwin]);
    rejects("same-spelled-source-domain-is-foreign", () => as3GetLexicalMember(new foreign.LexicalChild(), privateCap), 1069);
    rejects("duplicate-generation-registration", () => registerAS3LexicalMembers(h.LexicalBase, null, baseSpecs));
    rejects("unknown-class-registration", () => registerAS3LexicalMembers(class Unknown {
    }, null, []));
    class MetadataOnly {
    }
    ;
    registerFlashTypeMetadata(MetadataOnly, metadata_default[0]);
    rejects("reflection-alone-cannot-publish-lexical-authority", () => registerAS3LexicalMembers(MetadataOnly, null, baseSpecs));
    const raw = Object.create(h.LexicalBase.prototype);
    h.bg.enterInstance(raw);
    rejects("field-read-before-initialization", () => as3GetLexicalMember(raw, privateCap));
    initializeAS3LexicalInstance(h.bs, raw);
    check("Number-default-before-authored-initializer", () => Number.isNaN(as3GetLexicalMember(raw, privateCap)));
    const beforeMutation = new h.LexicalChild("captured");
    const method2 = h.LexicalBase.prototype._stamp;
    h.LexicalBase.prototype._stamp = function() {
      throw new Error("host-replacement");
    };
    check("method-descriptor-is-captured-before-host-mutation", () => beforeMutation.privateClosure()() === "captured:base:10");
    h.LexicalBase.prototype._stamp = method2;
    rejects("duplicate-private-trait-rejected", () => createHierarchy(void 0, [...baseSpecs, baseSpecs[0]]), "duplicate lexical declaration");
    rejects("missing-own-method-key-rejected", () => createHierarchy(void 0, baseSpecs.map((s) => s.name === "stamp" ? { ...s, key: "missing" } : s)), "exact own source method");
    rejects("same-declaration-schema-change-rejected", () => createHierarchy(void 0, baseSpecs.map((s) => s.name === "secret" ? { ...s, type: "String" } : s)), "source declaration changed");
    rejects("lexical-accessor-registration-held", () => createHierarchy(void 0, baseSpecs.map((s) => s.kind === "accessor" ? { name: "scale", visibility: "protected", kind: "accessor" } : s)), "accessor/signature admission pending");
    const fresh = () => {
      const a = declareAS3ReferenceType("probe::LexicalBase");
      return [a, declareAS3ReferenceType("probe::LexicalChild", a.type), declareAS3ReferenceType("probe::PublicTwin", a.type)];
    };
    rejects("protected-method-field-conflict-rejected", () => createHierarchy(fresh(), baseSpecs, childSpecs.map((s) => s.name === "updateTweens" ? { name: s.name, visibility: "protected", kind: "variable", type: "Number" } : s)), "protected override/field conflict");
    rejects("public-protected-conflict-rejected", () => createHierarchy(fresh(), [...baseSpecs, { name: "label", visibility: "protected", kind: "variable", type: "String" }]), "public/protected declaration conflict");
    const beforeWrite = x.privateState();
    rejects("explicit-public-QName-cannot-write-private", () => as3SetLexicalProperty(h.bs, x, new QName("", "secret"), 99), 1056);
    check("failed-public-QName-write-preserves-private", () => as3GetLexicalMember(x, privateCap) === beforeWrite[0]);
    rejects("forged-QName-not-authority", () => as3GetLexicalProperty(h.bs, x, Object.create(QName.prototype)), 1034);
    rejects("nonpublic-QName-remains-unsupported", () => as3GetLexicalProperty(h.bs, x, new QName("private", "secret")), "namespaced property keys are unsupported");
    check("private-storage-nonenumerable", () => Object.keys(x).join(",") === "label");
    check("public-surface-does-not-leak-native-method-keys", () => !as3HasProperty("_stamp", x) && !as3HasProperty("secret", x));
    check("fixture-accessor-bodies-execute", () => x.accessProtected(2) === 40);
    return names;
  }
  return __toCommonJS(native_exports);
})();
