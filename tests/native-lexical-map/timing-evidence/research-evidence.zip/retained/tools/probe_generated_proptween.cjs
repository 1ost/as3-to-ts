const fs=require('fs'),path=require('path'),cp=require('child_process'),crypto=require('crypto'),assert=require('node:assert/strict');
const here=__dirname,root=path.resolve(here,'../..'),compiler=path.resolve(root,'../as3-to-ts-op2'),engine=path.join(root,'as3-to-layaair-porting-kit/.local/provider-validation/LayaAir');
const tools=require('module').createRequire(path.join(root,'game-client-laya/package.json')),{build}=tools('esbuild'),{chromium}=tools('playwright');
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'),read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const lock=read(path.join(root,'as3-to-layaair-porting-kit/config/tools.lock.json'));
for(const [repo,pin]of [[engine,lock.providers.layaair.commit],[compiler,lock.providers.transpiler.commit]]){assert.equal(cp.execFileSync('git',['-C',repo,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),pin);assert.equal(cp.execFileSync('git',['-C',repo,'diff','--name-only','HEAD'],{encoding:'utf8'}).trim(),'');}
const qname='com.greensock.core.PropTween',sourcePath=path.join(root,'game-client-flash/src/com/greensock/core/PropTween.as'),source=fs.readFileSync(sourcePath,'utf8');
const verified=JSON.parse(cp.execFileSync(process.env.PYTHON||'python',[path.join(root,'as3-to-layaair-porting-kit/tools/verify_timing_metadata.py')],{encoding:'utf8'}));
const metadata=read(verified.output);assert.equal(metadata.classes[qname].sourceSha256,sha(sourcePath));
const outputRoot=path.join(root,'as3-to-layaair-porting-kit/.local/generated-proptween');fs.mkdirSync(outputRoot,{recursive:true});
const run=fs.mkdtempSync(path.join(outputRoot,'run-')),generated=path.join(run,'PropTween.ts');
const parse=require(path.join(compiler,'lib/parse')),emit=require(path.join(compiler,'lib/emit'));
fs.writeFileSync(generated,emit(parse(sourcePath,source),source,{customVisitors:[],definitionsByNamespace:{'com.greensock.core':['PropTween']},nativeClassInitialization:{classes:{[qname]:'lazy'}},nativeCallableClasses:{[qname]:source},nativeCallableMethodBindingModule:'@laya/flash/utils/AS3MethodBinding',nativeCallableCoercionModule:'@laya/flash/utils/AS3Coercion',nativeCallableStringModule:'@laya/flash/utils/AS3String',nativeCallableMetadata:{module:'@fixture/source-metadata',classes:{[qname]:metadata.classes[qname]}}}));
const provider=[['AS3DeclarationType',['declareAS3ReferenceType']],['AS3Type',['as3CoerceReference','registerAS3Class']],['AS3Property',['as3SetProperty','registerAS3PropertyTraits']],['AS3Class',['registerAS3Constructor']],['FlashTypeMetadata',['registerFlashTypeMetadata']]].map(([file,names])=>'export {'+names.join(',')+'} from '+JSON.stringify(path.join(engine,'src/layaAir/flash/utils',file).replaceAll('\\','/'))+';').join('\n');
const providerFile=path.join(run,'common-source-metadata.ts');fs.writeFileSync(providerFile,provider);
const bridge=path.join(run,'fixture-class-read.ts');fs.writeFileSync(bridge,'import {PropTween as Binding} from "./PropTween";\nimport {readNativeClass} from '+JSON.stringify(path.join(compiler,'utils/nativeClass').replaceAll('\\','/'))+';\nexport type PropTween=Binding;\nexport const PropTween=readNativeClass(Binding);\n');
const plugin={name:'exact-generated-leaf',setup(b){
 b.onResolve({filter:/PropTween$/},args=>args.importer.includes('game-client-laya')?{path:bridge}:undefined);
 b.onResolve({filter:/^@fixture\/source-metadata$/},()=>({path:'source-metadata',namespace:'common-reexports'}));
 b.onLoad({filter:/.*/,namespace:'common-reexports'},()=>({contents:provider,loader:'ts',resolveDir:root}));
 b.onResolve({filter:/^@laya\/flash\//},args=>({path:path.join(engine,'src/layaAir/flash',args.path.slice('@laya/flash/'.length)+'.ts')}));
 b.onResolve({filter:/^\.\/(?:nativeClass|callableClass|classBound|bound)$/},args=>args.importer===generated?{path:path.join(compiler,'utils',args.path.slice(2)+'.ts')}:undefined);
}};
(async()=>{const browser=await chromium.launch({headless:true});const reports=[];try{
for(const name of ['greensock-proptween','greensock-proptween-properties']){
 const fixture=path.join(root,'game-client-laya/tests',name,'fixture.ts'),evidence=path.join(root,'game-client-laya/tests',name,'evidence'),expected=read(path.join(evidence,'flash.json'));
 const receiptPath=path.join(evidence,'provenance.json'),receipt=read(receiptPath);
 assert.equal(sha(receiptPath),name==='greensock-proptween'?'919046019bf9794f8877eab3862930f534a65643da9a2cf4bb9fdecbdcbf5cff':'f6a7d1c866d03d0a0df28e93f2290e1ac3996728a7445a0b8b58b49706bf4166');
 for(const row of receipt.hashes){
  if(/mxmlc\.jar$|playerglobal\.swc$|electron\.exe$|pepflashplayer\.dll$/.test(row.path))continue;
  let file=path.resolve(root,row.path);
  if(name==='greensock-proptween-properties'&&row.path.includes('/sources/'))file=path.join(evidence,'sources',row.path.split('/sources/')[1]);
  else if(/\/(flash\.json|oracle\.swf)$/.test(row.path))file=path.join(evidence,path.basename(row.path));
  assert.equal(sha(file),row.sha256,row.path);
 }
 assert.equal(expected.failure,'');assert.equal(expected.rows.length,name==='greensock-proptween'?33:64);
 const ts=require(path.join(engine,'node_modules/typescript')),options={target:ts.ScriptTarget.ES2021,module:ts.ModuleKind.CommonJS,moduleResolution:ts.ModuleResolutionKind.NodeJs,strict:true,strictNullChecks:false,noEmit:true,experimentalDecorators:true};
 const host=ts.createCompilerHost(options);host.resolveModuleNames=(names,containing)=>names.map(n=>{
  let exact;
  if(n==='@fixture/source-metadata')exact=providerFile;
  else if(n.startsWith('@laya/flash/'))exact=path.join(engine,'src/layaAir/flash',n.slice('@laya/flash/'.length)+'.ts');
  else if(containing===fixture&&/PropTween$/.test(n))exact=bridge;
  else if(containing===generated&&/^\.\/(nativeClass|callableClass|classBound|bound)$/.test(n))exact=path.join(compiler,'utils',n.slice(2)+'.ts');
  return exact?{resolvedFileName:exact,extension:ts.Extension.Ts}:ts.resolveModuleName(n,containing,options,host).resolvedModule;
 });
 const program=ts.createProgram([fixture],options,host),diagnostics=ts.getPreEmitDiagnostics(program).map(d=>({code:d.code,file:d.file?.fileName,message:ts.flattenDiagnosticMessageText(d.messageText,'\n')}));
 fs.writeFileSync(path.join(run,name+'-types.json'),JSON.stringify({diagnostics,files:program.getSourceFiles().length,strict:true,strictNullChecks:false},null,2));assert.deepEqual(diagnostics,[]);
 const bundle=await build({entryPoints:[fixture],bundle:true,write:false,format:'iife',globalName:'Fixture',platform:'browser',target:'chrome120',plugins:[plugin],metafile:true});
 const code=bundle.outputFiles[0].text;fs.writeFileSync(path.join(run,name+'.js'),code);
 const page=await browser.newPage(),errors=[];page.on('pageerror',e=>errors.push(String(e)));let actual,failure;
 try{await page.addScriptTag({content:code});actual=await page.evaluate(()=>Fixture.run());}catch(e){failure=String(e);}
 const differences=[];if(actual)for(let i=0;i<Math.max(actual.rows.length,expected.rows.length);i++)try{assert.deepEqual(actual.rows[i],expected.rows[i]);}catch{differences.push({i,actual:actual.rows[i],expected:expected.rows[i]});}
 const result={name,actual,expectedRows:expected.rows.length,differences,errors,failure,bundleSHA256:sha(path.join(run,name+'.js')),actualProviderTypeDiagnostics:diagnostics.length,typeSourceFiles:program.getSourceFiles().length,typeScriptVersion:ts.version,strictNullChecks:false,originalReceiptSHA256:sha(receiptPath),fixtureSHA256:sha(fixture),sources:Object.keys(bundle.metafile.inputs).filter(p=>!p.startsWith('common-reexports:')).map(p=>({path:path.resolve(p),sha256:sha(path.resolve(p))})),ok:!!actual&&!differences.length&&!errors.length&&!failure};reports.push(result);await page.close();
}
}finally{await browser.close();}
const report={scope:'Fresh unchanged maintained PropTween leaf emission against existing fixtures; fixture-only native Class read and common reexports, no application replacement or full timing admission',compilerCommit:lock.providers.transpiler.commit,engineCommit:lock.providers.layaair.commit,sourceSHA256:sha(sourcePath),generatedSHA256:sha(generated),metadataPath:verified.output,metadataSHA256:sha(verified.output),probeSHA256:sha(__filename),fixtureBridgeSHA256:sha(bridge),commonReexportsSHA256:sha(providerFile),compilerModules:Object.keys(require.cache).filter(p=>p.startsWith(path.join(compiler,'lib')+path.sep)).map(p=>({path:path.relative(compiler,p),sha256:sha(p)})),reports,ok:reports.every(x=>x.ok)};
fs.writeFileSync(path.join(run,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({run,ok:report.ok,fixtures:reports.map(x=>({name:x.name,rows:x.expectedRows,differences:x.differences.length,errors:x.errors,failure:x.failure}))}));if(!report.ok)process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1;});
