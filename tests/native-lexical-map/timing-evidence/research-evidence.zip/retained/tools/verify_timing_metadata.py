"""Authenticate and project original timing reflection; never imply native readiness."""
import hashlib
import json
import tempfile
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KIT = ROOT / 'as3-to-layaair-porting-kit'
sys.path.insert(0, str(KIT / 'vendor'))
from bleach_portkit.as3_parser import parse_as3_file
EVIDENCE = ROOT / 'game-client-laya/tests/greensock-timing-roots/metadata-evidence'
RECEIPT_SHA256 = 'cb460fd363a4f277b2dc31d436c7257a43c3a0896f8bd5aac05d9fe05253e2a6'
EXPECTED = {'com.greensock.core.PropTween', 'com.greensock.plugins.TweenPlugin',
            'com.greensock.core.TweenCore', 'com.greensock.core.SimpleTimeline',
            'com.greensock.TweenLite'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def surface(node, owner, field_owners):
    """Retain Flash order; this projection follows existing metadata input fields."""
    result = {key: [] for key in ('variables', 'constants', 'methods', 'accessors')}
    traits = []
    lists = {'variable': 'variables', 'constant': 'constants',
             'method': 'methods', 'accessor': 'accessors'}
    for member in node:
        if member.tag not in lists:
            continue
        declared_by = (field_owners[(member.tag, member.attrib['name'])]
                       if member.tag in ('variable', 'constant')
                       else member.get('declaredBy', owner))
        item = {'name': member.attrib['name'], 'declaredBy': declared_by}
        if member.get('uri') is not None:
            item['uri'] = member.get('uri')
        if member.tag in ('variable', 'constant'):
            item['type'] = member.attrib['type']
        elif member.tag == 'method':
            item['parameterCount'] = len(member.findall('parameter'))
        else:
            item['access'] = member.attrib['access']
        result[lists[member.tag]].append(item)
        if item['declaredBy'] == owner and not item.get('uri'):
            trait = {'name': item['name'], 'kind': member.tag}
            if member.tag != 'method':
                trait['type'] = member.attrib['type']
            traits.append(trait)
    return result, traits


def load_source_declarations(evidence, root, names):
    declarations = {}
    for qname in names:
        relative = Path(qname.replace('.', '/') + '.as')
        retained = evidence / 'sources/original' / relative
        maintained = root / 'game-client-flash/src' / relative
        if sha(retained) != sha(maintained):
            raise ValueError(f'Maintained source differs from captured source: {qname}')
        parsed = parse_as3_file(retained, repository_root=evidence,
                                module='timing-metadata', source_root='sources/original',
                                target_source_root='unused')
        if len(parsed) != 1 or parsed[0].kind != 'class':
            raise ValueError(f'Exactly one source class required: {qname}')
        source = parsed[0]
        if source.package + '.' + source.name != qname:
            raise ValueError(f'Source identity mismatch: {qname}')
        if source.include_directives or source.include_parse_error:
            raise ValueError(f'Unresolved source composition: {qname}')
        declarations[qname] = source
    return declarations


def source_type_matches(source, spelling, reflected):
    """Only compare an exact source spelling/import with an authenticated XML name."""
    target = reflected.replace('::', '.')
    if spelling == target:
        return True
    if '.' in spelling:
        return False
    candidates = {source.package + '.' + spelling}
    candidates.update(value for value in source.imports if value.rsplit('.', 1)[-1] == spelling)
    candidates.update(package + '.' + spelling for package in source.wildcard_imports)
    return target in candidates


def reconcile_field_owners(nodes, declarations):
    """Raw describeType variables omit declaredBy, even for inherited storage.

    Prove ownership using the exact source ancestry and the complete public field
    set. Refuse ambiguous/shadowed fields rather than treating inventory as proof.
    No inherited members are deleted or reordered in the reflected surface.
    """
    result = {}
    for owner, (cls, inst) in nodes.items():
        qname = owner.replace('::', '.')
        chain, seen = [], set()
        current = qname
        while current != 'Object':
            if current in seen or current not in declarations:
                raise ValueError(f'Unresolved/cyclic source ancestry: {current}')
            seen.add(current)
            source = declarations[current]
            raw_name = current.rsplit('.', 1)[0] + '::' + current.rsplit('.', 1)[1]
            if raw_name not in nodes:
                raise ValueError(f'Missing ancestor reflection: {raw_name}')
            base = nodes[raw_name][1].attrib['base']
            if not source_type_matches(source, source.base_type or 'Object', base):
                raise ValueError(f'Source/reflection ancestry mismatch: {current}')
            chain.append((raw_name, source))
            current = base.replace('::', '.')
        for side, node in [('statics', cls), ('instance', inst)]:
            wanted = {}
            for declaring, source in (chain[:1] if side == 'statics' else chain):
                for field in source.fields:
                    if field.static != (side == 'statics') or field.visibility != 'public':
                        continue
                    if field.namespace_qualifier:
                        raise ValueError('Custom namespace field ownership is not admitted')
                    key = ('constant' if field.constant else 'variable', field.name)
                    if key in wanted or any(name == field.name for _, name in wanted):
                        raise ValueError(f'Ambiguous public field ownership: {owner}.{field.name}')
                    wanted[key] = (declaring, source, field)
            actual = {}
            for member in node:
                if member.tag not in ('variable', 'constant'):
                    continue
                key = (member.tag, member.attrib['name'])
                if key in actual or key not in wanted or member.get('uri'):
                    raise ValueError(f'Unproved reflected field: {owner}.{key}')
                declaring, source, field = wanted[key]
                if (not source_type_matches(source, field.type_name, member.attrib['type'])
                        or member.get('declaredBy', declaring) != declaring):
                    raise ValueError(f'Source/reflection field mismatch: {owner}.{key}')
                actual[key] = declaring
            if actual.keys() != wanted.keys():
                raise ValueError(f'Incomplete reflected public fields: {owner} {side}')
            result[(owner, side)] = actual
    return result


def verify():
    lock = json.loads((KIT / 'config/tools.lock.json').read_text(encoding='utf8'))
    parser_inputs = lock['toolkit_snapshot']['files']
    for item in parser_inputs:
        if sha(KIT / item['path']) != item['sha256']:
            raise ValueError(f"Pinned source parser changed: {item['path']}")
    receipt = EVIDENCE / 'provenance.json'
    if sha(receipt) != RECEIPT_SHA256:
        raise ValueError('Changed original timing metadata receipt')
    manifest = json.loads(receipt.read_text(encoding='utf8'))
    for item in manifest['files']:
        relative = Path(item['path'])
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('Nonportable retained evidence path')
        source = EVIDENCE / relative
        if not source.exists():
            source = EVIDENCE / 'sources' / relative
        if sha(source) != item['sha256']:
            raise ValueError(f'Changed original evidence: {relative}')
    raw = json.loads((EVIDENCE / 'flash.json').read_text(encoding='utf8'))
    if len(raw['rows']) != 5 or not all(row['instanceOfSource'] for row in raw['rows']):
        raise ValueError('Original source instantiation evidence is incomplete')
    if len(raw['reflection']) != 5 or len(raw['instances']) != 5:
        raise ValueError('Expected both reflection surfaces for all five classes')
    classes, nodes = {}, {}
    for class_xml, instance_xml in zip(raw['reflection'], raw['instances']):
        cls, inst = ET.fromstring(class_xml), ET.fromstring(instance_xml)
        name = cls.attrib['name']
        if name != inst.attrib['name']:
            raise ValueError('Mismatched Class and instance reflection')
        qname = name.replace('::', '.')
        if qname not in EXPECTED or name in nodes:
            raise ValueError('Unexpected or duplicate timing declaration')
        nodes[name] = (cls, inst)
    declarations = load_source_declarations(EVIDENCE, ROOT, EXPECTED)
    owners = reconcile_field_owners(nodes, declarations)
    for name, (cls, inst) in nodes.items():
        qname = name.replace('::', '.')
        retained = EVIDENCE / 'sources/original' / Path(qname.replace('.', '/') + '.as')
        statics, static_traits = surface(cls, name, owners[(name, 'statics')])
        instance, instance_traits = surface(inst, name, owners[(name, 'instance')])
        classes[qname] = {
            'sourceSha256': sha(retained),
            'metadata': {'name': name, 'base': inst.attrib['base'],
                         'isDynamic': inst.attrib['isDynamic'] == 'true',
                         'isFinal': inst.attrib['isFinal'] == 'true',
                         'instance': instance, 'statics': statics},
            'instanceTraits': instance_traits, 'staticTraits': static_traits}
    return {'scope': 'Original reflection projection only; runtime/source dispatch not admitted',
            'receiptSHA256': RECEIPT_SHA256, 'parserInputs': parser_inputs,
            'nativeReady': False, 'classes': classes}


if __name__ == '__main__':
    result = verify()
    folder = ROOT / 'as3-to-layaair-porting-kit/.local/timing-metadata'
    folder.mkdir(parents=True, exist_ok=True)
    output = Path(tempfile.mkdtemp(prefix='run-', dir=folder)) / 'metadata.json'
    output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf8')
    print(json.dumps({'output': str(output), 'classes': len(result['classes']), 'nativeReady': False}))
