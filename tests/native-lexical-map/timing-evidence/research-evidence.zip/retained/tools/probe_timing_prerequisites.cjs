// Structural prerequisite probe only; original source is never rewritten.
const fs=require('fs'),path=require('path'),cp=require('child_process'),crypto=require('crypto');
const metadataMode='native-metadata-structural';
const lexicalMode='native-lexical-structural';
const typedLocalMode='native-typed-locals-structural';
const modes=['legacy-structural','native-callable-structural','native-dictionary-bound-structural','native-constructor-providers-structural',metadataMode,lexicalMode];
const usesMetadata=mode=>mode===metadataMode||mode===lexicalMode||mode===typedLocalMode;
const usesLexical=mode=>mode===lexicalMode||mode===typedLocalMode;
function selectedModes(args){
 if(args.some(arg=>arg!=='--typed-locals'))throw Error('Unknown timing probe option; supported: --typed-locals');
 return args.includes('--typed-locals')?[...modes,typedLocalMode]:[...modes];
}
const metadataReceipt='cb460fd363a4f277b2dc31d436c7257a43c3a0896f8bd5aac05d9fe05253e2a6';
function metadataOptions(document,inputs){
 if(document.nativeReady!==false||document.receiptSHA256!==metadataReceipt)throw Error('Original metadata authority mismatch');
 if(inputs.length!==5)throw Error('Complete five-source metadata composition required');
 const names=inputs.map(input=>input.qname).sort(),actual=Object.keys(document.classes||{}).sort();
 if(JSON.stringify(names)!==JSON.stringify(actual))throw Error('Complete five-source metadata composition required');
 for(const input of inputs)if(document.classes[input.qname].sourceSha256!==input.sha256)throw Error('Metadata source changed: '+input.qname);
 return {module:'./AS3MethodBinding',classes:document.classes};
}
function emissionOptions(mode,sources,definitionsByNamespace,nativeMetadata){
 if(![...modes,typedLocalMode].includes(mode))throw Error('Unknown timing probe mode');
 const options={customVisitors:[],definitionsByNamespace,lineSeparator:'\n',useNamespaces:false};
 if(mode!=='legacy-structural')Object.assign(options,{nativeClassInitialization:{classes:Object.fromEntries(Object.keys(sources).map(n=>[n,'lazy']))},nativeCallableClasses:sources,nativeCallableMethodBindingModule:'./AS3MethodBinding',nativeCallableCoercionModule:'./AS3MethodBinding'});
 if(mode==='native-dictionary-bound-structural'||mode==='native-constructor-providers-structural'||usesMetadata(mode)){
  options.nativeClassInitialization.classes['flash.utils.Dictionary']='ready';
  options.definitionsByNamespace={...definitionsByNamespace,'flash.utils':['Dictionary']};
 }
 if(mode==='native-constructor-providers-structural'||usesMetadata(mode)){
  options.nativeCallableStringModule='./AS3String';
  options.nativeArrayCreationModule='./AS3ArrayCreation';
 }
 if(usesMetadata(mode)){
  if(!nativeMetadata)throw Error('Authenticated full timing metadata required');
  options.nativeCallableMetadata=nativeMetadata;
  if(usesLexical(mode))options.nativeLexicalMembersModule='./AS3LexicalMembers';
 }
 if(mode===typedLocalMode){
  options.nativeTypedLocals=true;
  options.nativeCallableCoercionModule='./AS3Coercion';
  options.nativeTypedLocalAdditionModule='./AS3Addition';
 }
 return options;
}
function main(){
const activeModes=selectedModes(process.argv.slice(2));
const here=__dirname,root=path.resolve(here,'../..'),compiler=path.resolve(root,'../as3-to-ts-op2'),engine=path.join(root,'as3-to-layaair-porting-kit/.local/provider-validation/LayaAir');
const parse=require(path.join(compiler,'lib/parse')),emit=require(path.join(compiler,'lib/emit')),ts=require(path.join(engine,'node_modules/typescript'));
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'),git=(repo,...args)=>cp.execFileSync('git',['-C',repo,...args],{encoding:'utf8'}).trim();
const lock=JSON.parse(fs.readFileSync(path.join(root,'as3-to-layaair-porting-kit/config/tools.lock.json')));
for(const [repo,pin]of [[compiler,lock.providers.transpiler.commit],[engine,lock.providers.layaair.commit]]){if(git(repo,'rev-parse','HEAD')!==pin||git(repo,'diff','--name-only','HEAD'))throw Error('Pinned clean inputs required');}
const receiptPath=path.join(root,'game-client-laya/tests/greensock-timing-roots/evidence/provenance.json');
if(sha(receiptPath)!=='f06b488feb0414e5df69ad8eafee8ac78af83e5acb285c512f98085f10e4c9f5')throw Error('Original receipt changed');
const inputs=JSON.parse(fs.readFileSync(receiptPath)).hashes.filter(x=>x.path.startsWith('game-client-flash/src/com/greensock/'));
if(inputs.length!==5)throw Error('Expected five original source files');
const sources={},definitionsByNamespace={};
for(const input of inputs){const p=path.join(root,input.path);if(sha(p)!==input.sha256)throw Error('Original source changed');const source=fs.readFileSync(p,'utf8'),pkg=/package\s+([\w.]+)/.exec(source)[1],name=/public\s+(?:final\s+)?class\s+(\w+)/.exec(source)[1];sources[pkg+'.'+name]=source;(definitionsByNamespace[pkg]??=[]).push(name);input.qname=pkg+'.'+name;}
const outputRoot=path.join(root,'as3-to-layaair-porting-kit/.local/timing-source-probe');fs.mkdirSync(outputRoot,{recursive:true});
// This exact common provider publishes its original Class identity. This binding
// does not admit Dictionary enumeration, source subclasses, or the timing cycle.
const dictionaryPath='src/layaAir/flash/utils/Dictionary.ts';
const providerBindings={'flash.utils.Dictionary':{state:'ready',export:'Dictionary',path:dictionaryPath,engineCommit:git(engine,'rev-parse','HEAD'),sha256:sha(path.join(engine,dictionaryPath))}};
const output=fs.mkdtempSync(path.join(outputRoot,'run-')),rows=[];
const verifier=path.join(here,'verify_timing_metadata.py'),python=process.env.PYTHON||'python';
const verification=cp.spawnSync(python,[verifier],{cwd:root,encoding:'utf8',windowsHide:true});
const metadata={status:'authentication-rejected',verifier:path.relative(root,verifier).split(path.sep).join('/'),verifierSHA256:sha(verifier),command:[python,verifier],exitCode:verification.status,stdout:verification.stdout||'',stderr:verification.stderr||''};
let nativeMetadata;
try{
 if(verification.error)throw verification.error;
 if(verification.status!==0)throw Error('Original metadata verifier failed');
 const result=JSON.parse(verification.stdout),documentPath=result.output;
 const bytes=fs.readFileSync(documentPath),document=JSON.parse(bytes);
 // Retain the exact projection even when composition is rejected. No class is
 // dropped to make eager compiler validation proceed further.
 const retained=path.join(output,'metadata.json');fs.writeFileSync(retained,bytes);
 metadata.output=path.relative(root,retained).split(path.sep).join('/');metadata.outputSHA256=sha(retained);
 nativeMetadata=metadataOptions(document,inputs);metadata.status='authenticated';metadata.receiptSHA256=document.receiptSHA256;
}catch(error){metadata.error=String(error);}
for(const mode of activeModes)for(const input of inputs){const source=sources[input.qname],p=path.join(output,mode+'-'+input.qname+'.ts');const row={mode,qname:input.qname,sourcePath:input.path,sourceSHA256:input.sha256,metadataConfigured:usesMetadata(mode)&&!!nativeMetadata,lexicalConfigured:usesLexical(mode),typedLocalsConfigured:mode===typedLocalMode};
 try{
 if(usesMetadata(mode)&&!nativeMetadata){row.status='metadata-authentication-rejected';row.error=metadata.error;rows.push(row);continue;}
 const options=emissionOptions(mode,sources,definitionsByNamespace,nativeMetadata);
 const optionsPath=path.join(output,mode+'-'+input.qname+'.options.json');
 fs.writeFileSync(optionsPath,JSON.stringify(options,null,2)+'\n');
 row.options=path.relative(root,optionsPath).split(path.sep).join('/');row.optionsSHA256=sha(optionsPath);
 const generated=emit(parse(input.path,source),source,options);fs.writeFileSync(p,generated);const tree=ts.createSourceFile(p,generated,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);row.syntaxDiagnostics=tree.parseDiagnostics.map(d=>({code:d.code,message:ts.flattenDiagnosticMessageText(d.messageText,'\n')}));row.status=row.syntaxDiagnostics.length?'syntax-error':'syntax-pass';row.output=path.relative(root,p).split(path.sep).join('/');row.outputSHA256=sha(p);
 }catch(error){row.status='emission-rejected';row.error=String(error);row.stack=error.stack;}
 rows.push(row);
}
const commonModules=['AS3String','AS3ArrayCreation'].map(name=>({module:'./'+name,path:'src/layaAir/flash/utils/'+name+'.ts',sha256:sha(path.join(engine,'src/layaAir/flash/utils',name+'.ts'))}));
const lexicalModules=[...commonModules,{module:'./AS3LexicalMembers',path:'src/layaAir/flash/utils/AS3LexicalMembers.ts',sha256:sha(path.join(engine,'src/layaAir/flash/utils/AS3LexicalMembers.ts'))}];
const typedModeReport=activeModes.includes(typedLocalMode);
const typedModules=typedModeReport?['AS3Coercion','AS3Addition'].map(name=>({module:'./'+name,path:'src/layaAir/flash/utils/'+name+'.ts',sha256:sha(path.join(engine,'src/layaAir/flash/utils',name+'.ts'))})):[];
const report={modes:activeModes,scope:'Complete maintained five-source timing group structural emission only; no fabricated Flash class binding, runtime execution or dependency admission',compilerCommit:git(compiler,'rev-parse','HEAD'),engineCommit:git(engine,'rev-parse','HEAD'),originalReceiptSHA256:sha(receiptPath),inputs,definitionsByNamespace,rows,ready:false,sourceOperationsMetadataConfigured:!!nativeMetadata,metadataByMode:{[metadataMode]:metadata,[lexicalMode]:metadata,...(typedModeReport?{[typedLocalMode]:metadata}:{})},providerBindingsByMode:{'native-dictionary-bound-structural':providerBindings,'native-constructor-providers-structural':providerBindings,[metadataMode]:providerBindings,[lexicalMode]:providerBindings,...(typedModeReport?{[typedLocalMode]:providerBindings}:{})},commonModulesByMode:{'native-constructor-providers-structural':commonModules,[metadataMode]:commonModules,[lexicalMode]:lexicalModules,...(typedModeReport?{[typedLocalMode]:[...lexicalModules,...typedModules]}:{})},syntaxChecker:{version:ts.version,sha256:sha(path.join(engine,'node_modules/typescript/lib/typescript.js'))},compilerModules:Object.keys(require.cache).filter(p=>p.startsWith(path.join(compiler,'lib')+path.sep)).map(p=>({path:path.relative(compiler,p).split(path.sep).join('/'),sha256:sha(p)})),probeSHA256:sha(__filename)};
fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({output,rows:rows.map(({mode,qname,status,error})=>({mode,qname,status,error}))},null,2));
if(rows.some(row=>row.status!=='syntax-pass'))process.exitCode=1;
}
module.exports={metadataOptions,emissionOptions,selectedModes,modes,metadataMode,lexicalMode,typedLocalMode,usesMetadata,usesLexical};
if(require.main===module)main();
